#pragma once

class DownStaircase {
public:
    int x, y;

    DownStaircase(int x = 0, int y = 0) : x(x), y(y) {}
};