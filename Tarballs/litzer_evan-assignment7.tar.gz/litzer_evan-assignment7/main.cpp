#include "Dungeon.h"

int main(int argc, char* argv[]) {
    Dungeon d;
    d.runGameLoop(argc, argv);
    return 0;
}
