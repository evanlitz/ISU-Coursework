#pragma once

class UpStaircase {
public:
    int x, y;

    UpStaircase(int x = 0, int y = 0) : x(x), y(y) {}
};