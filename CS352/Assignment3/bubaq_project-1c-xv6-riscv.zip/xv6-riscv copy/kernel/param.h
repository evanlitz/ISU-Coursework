#define NPROC        64  // maximum number of processes
#define NCPU          8  // maximum number of CPUs
#define NOFILE       16  // open files per process
#define NFILE       100  // open files per system
#define NINODE       50  // maximum number of active i-nodes
#define NDEV         10  // maximum major device number
#define ROOTDEV       1  // device number of file system root disk
#define MAXARG       32  // max exec arguments
#define MAXOPBLOCKS  10  // max # of blocks any FS op writes
#define LOGBLOCKS    (MAXOPBLOCKS*3)  // max data blocks in on-disk log
#define NBUF         (MAXOPBLOCKS*3)  // size of disk block cache
#define FSSIZE       2000  // size of file system in blocks
#define MAXPATH      128   // maximum file path name
#define USERSTACK    1     // user stack pages



#define SCHED_RR     0     // Indicates the normal round robin scheduler is chosen.
#define SCHED_RRSP   1     // Indicates the round robin strict priority scheduler is chosen. 
#define SCHED_MLFQ   2     // Indicates that the multi-level feedback queue scheduler is chosen.
#ifndef SCHEDULER          // Define scheduler
// #define SCHEDULER SCHED_RR 
// #define SCHEDULER SCHED_RRSP
#define SCHEDULER SCHED_MLFQ
#endif
/*
    ABOVE IS THE SWITCH FOR THE DIFFERENT SCHEDULERS TO BE ENABLED. CURRENTLY THE MLFQ SCHEDULER IS ENABLED.
    TO ENABLE ANOTHER ONE, COMMENT OUT THE MLFQ LINE AND THEN UNCOMMENT ONE OF THE SCHEDULERS.

    DO NOT HAVE MULTIPLE OF THESE LINES UNCOMMENTED AT ONCE, OR ELSE CODE WILL NOT WORK PROPERLY.


*/