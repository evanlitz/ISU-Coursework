#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

#define Q2_QUANTA 1     // The highest queue level (Q2) for the MLFQ. Nice value < -10 start here, quanta = 1 tick
#define Q1_QUANTA 10    // The middle queue level (Q1) for the MLFQ. -10 < Nice value < 10 starts here, quanta = 10 tick
#define Q0_QUANTA 15    // The lowest queue level (Q0) for the MLFQ. Nice value > 10 start here, quanta = 15 ticks

#define BOOST_INTERVAL 60   // The interval for the priority boost in ticks. Currently set to 60.

int between_ticks = 0;      // The counter for the interval timer

int logging_enabled = 0;    // The boolean switch for logging being enabled or disabled. 1 = enabled, 0 = disabled.

static inline int starting_level_from_nice(int nice) {    // The starting queue level for the MLFQ that is determined by the nice level.
  if (nice <= -10) return 2;                              // Helper function for MLFQ
  if (nice <= 10) return 1;
  return 0;
}

#if SCHEDULER == SCHED_RRSP     // Statically define RRSP scheduler if switch for it enabled.
static void scheduler_rrsp(void);
#endif

#if SCHEDULER == SCHED_MLFQ // Statically define MLFQ scheduler if switch for it enabled.
static void scheduler_mlfq(void);
#endif

#if SCHEDULER == SCHED_RR // Statically define RR scheduler if switch for it enabled.
static void normal_scheduler(void);
#endif

struct cpu cpus[NCPU];

struct proc proc[NPROC];

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for(p = proc; p < &proc[NPROC]; p++) {
      initlock(&p->lock, "proc");
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;
  
  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;
  p->nice = 0;              // Defaultly set the nice values to 0 unless otherwise defined.
  p->qlevel = starting_level_from_nice(p->nice);     // Determine the starting level for the nice values.
  p->qruntime = 0;          // The qruntime set to 0 for default
  p->demote = 0;            // The demote amount for the process.

  // Allocate a trapframe page.
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}



// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;
  if(p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if(pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
              (uint64)trampoline, PTE_R | PTE_X) < 0){
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
              (uint64)(p->trapframe), PTE_R | PTE_W) < 0){
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;
  
  p->cwd = namei("/");

  p->state = RUNNABLE;

  release(&p->lock);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if(n > 0){
    if(sz + n > TRAPFRAME) {
      return -1;
    }
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if(n < 0){
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
kfork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy user memory from parent to child.
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for(i = 0; i < NOFILE; i++)
    if(p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  release(&np->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  acquire(&np->lock);
  np->state = RUNNABLE;
  release(&np->lock);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for(pp = proc; pp < &proc[NPROC]; pp++){
    if(pp->parent == p){
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
kexit(int status)
{
  struct proc *p = myproc();

  if(p == initproc)
    panic("init exiting");

  // Close all open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd]){
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);
  
  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
kwait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(pp = proc; pp < &proc[NPROC]; pp++){
      if(pp->parent == p){
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if(pp->state == ZOMBIE){
          // Found one.
          pid = pp->pid;
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
                                  sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || killed(p)){
      release(&wait_lock);
      return -1;
    }
    
    // Wait for a child to exit.
    sleep(p, &wait_lock);  //DOC: wait-sleep
  }
}

// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run.
//  - swtch to start running that process.
//  - eventually that process transfers control
//    via swtch back to the scheduler.


void
scheduler(void)     // This function calls each scheduler when the switch in param.
{
  #if SCHEDULER == SCHED_RR
    normal_scheduler();
  #elif SCHEDULER ==  SCHED_RRSP
    scheduler_rrsp();
  #elif SCHEDULER == SCHED_MLFQ
    scheduler_mlfq();
  #else
  # error "Scheduler is not set right."
  #endif  

  for(;;);
}

#if SCHEDULER == SCHED_RR
static void
normal_scheduler(void)      // This is the normal round robin scheduler that the xv6 files already has pre-initialized.
{
  struct proc *p;
  struct cpu *c = mycpu();

  c->proc = 0;
  for(;;){
    // The most recent process to run may have had interrupts
    // turned off; enable them to avoid a deadlock if all
    // processes are waiting. Then turn them back off
    // to avoid a possible race between an interrupt
    // and wfi.
    intr_on();
    intr_off();

    int found = 0;
    for(p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if(p->state == RUNNABLE) {
        // Switch to chosen process.  It is the process's job
        // to release its lock and then reacquire it
        // before jumping back to us.
        p->state = RUNNING;

        if (logging_enabled) {            // This is the logging I did for this scheduler. Similar to the other schedulers.
          struct proc *old = c->proc;     
          struct proc *newp = p;
          printf("[LOG] ctx switch: CPU %d: %s(%d) -> %s(%d)\n",      //Format is observable in the experiment files.
                cpuid(),
                old ? old->name : "none",
                old ? old->pid  : -1,
                newp ? newp->name : "none",
                newp ? newp->pid  : -1);
        }
        c->proc = p;
        swtch(&c->context, &p->context);

        // Process is done running for now.
        // It should have changed its p->state before coming back.
        c->proc = 0;
        found = 1;
      }
      release(&p->lock);
    }
    if(found == 0) {
      // nothing to run; stop running on this core until an interrupt.
      asm volatile("wfi");
    }
  }
}
#endif

#if SCHEDULER == SCHED_RRSP

static inline int rrsp_priority(struct proc *p) {       // This is the priority helper function for the rrsp scheduler. The assignment is 20 - nice value for the priority.
  return 20 - p->nice;   
}

static void scheduler_rrsp(void)    // The function for the RRSP scheduler.
{
  struct cpu *c = mycpu();
  c->proc = 0;

  for (;;) {
    intr_on();        // This enables the interrupts. ;-;

    struct proc *best = 0;    //The pointer to the process with the best priority value.
    int best_pri = -1;        // Initialize the counter variable for the above methodology.

    // Scan the entire process table and look for the highest-priority and runnable process. Thes
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if (p->state == RUNNABLE) {
        int pri = rrsp_priority(p);
        // Choose the process with the highest priority. 
        if (!best || pri > best_pri) {
          if (best) release(&best->lock);     // Drop the mutex lock on the previous process that had the previous best priority and then switch to the new best one.
          best = p;   
          best_pri = pri;
          continue;         // Keep the best locked and run or replace later.
        }
      }
      release(&p->lock);    // The process did not have the best priority, so the lock gets released.
    }

    if (best) {
      // Still hold the best lock here.
      best->state = RUNNING ;
      if (logging_enabled) {        // Same logging methodology as before with other schedulers. Same format.
        struct proc *old = c->proc;
        struct proc *newp = best;
        printf("[LOG] ctx switch: CPU %d: %s(%d) -> %s(%d)\n",
               cpuid(),
               old ? old->name : "none",
               old ? old->pid  : -1,
               newp ? newp->name : "none",
               newp ? newp->pid  : -1);
      }
      c->proc = best;
      // Context switch into the best priority process, it willrun until it stops, sleeps, or is interrupted.
      swtch(&c->context, &best->context);
      // Return from the best process, lock is already released.
      c->proc = 0;
      release(&best->lock); 
    }
    else {
      // GPT helped here. Go to low power mode if nothing is found, then wait for interrupt.
      asm volatile("wfi");
    }
  }
}
#endif

#if SCHEDULER == SCHED_MLFQ
// Priority boost all of the processes back to a queue based on their nice values, and reset their pre queue runtime and state.
static void mlfq_boost_all(void) {
  for (struct proc *p = proc ; p < &proc[NPROC]; p++)
  {
    acquire(&p->lock);
    if (p->state != UNUSED) {
      p ->qlevel = starting_level_from_nice(p->nice);  // Recalculate the base level from the nice value
      p->qruntime = 0 ;                                // Reset the per-level runtime
      p->demote = 0 ;                                 // No demotion happens, reset it to 0.
    }
    release(&p->lock);
  }
}


// MLFQ scheduler as instructed in the assignment with the three quantum levels that range from high to low priority.
// Run the first runnable process in the highest non-empty level.
static void scheduler_mlfq(void)
{
  struct cpu *c = mycpu();
  c->proc = 0;

  for (;;) {      //interrupt
    intr_on() ;

    if (between_ticks >= BOOST_INTERVAL) {    //Run the boost function if the ticks counter goes past the interval.
      mlfq_boost_all();
      between_ticks = 0;
    }


  // If no process is found at one level, go down a level and try again. If no runnable in any level, the interrupt for loop will execute.
  for (int lvl = 2 ; lvl >= 0 ; lvl--)  // Check all of the priority queues from level 2 to 0.
  {
    struct proc *chosen = 0;
    
    for (struct proc *p = proc ; p < &proc[NPROC]; p++)   // Scan the process table to find a runnable process in this level.
    {
      acquire(&p->lock);
      if (p->state == RUNNABLE && p->qlevel == lvl) {
        chosen = p;
        chosen->state = RUNNING;
        // Keep chosen process locked and release all of the other locks.
        break ;
      }
      release(&p->lock);    // Release the lock if not runnable and the level does not equal the current one.
    }

    if (chosen) {         // Log the chosen process using the same methodology as before.
        if (logging_enabled) {
          struct proc *old = c->proc;
          struct proc *newp = chosen;
          printf("[LOG] ctx switch: CPU %d: %s(%d) -> %s(%d)\n",
               cpuid(),
               old ? old->name : "none",
               old ? old->pid  : -1,
               newp ? newp->name : "none",
               newp ? newp->pid  : -1);
      }
      
      c->proc = chosen;
      swtch(&c->context, &chosen->context);     //Switch to the chosen process and it will run for however many ticks.


      // The chosen process will have either yielded for another process, slept itself (IO), or been killed.
      // The tich time counter is updated by the timer.
      if (chosen->demote) {
        // Move the process down one level if demote value is right.
        if (chosen->qlevel > 0) chosen->qlevel--;
        chosen->qruntime = 0;
        chosen->demote = 0;
      }
      c->proc = 0;
      release(&chosen->lock);
      // After running one process from the level, restart from the top.
      break;
    }
  }
}
}
#endif
// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&p->lock))
    panic("sched p->lock");
  if(mycpu()->noff != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched RUNNING");
  if(intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();

  // Still holding p->lock from scheduler.
  release(&p->lock);

  if (first) {
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);

    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    if (p->trapframe->a0 == -1) {
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64))trampoline_userret)(satp);
}

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  // Must acquire p->lock in order to
  // change p->state and then call sched.
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
  release(lk);

  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  release(&p->lock);
  acquire(lk);
}

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
        p->state = RUNNABLE;
      }
      release(&p->lock);
    }
  }
}

int
knice(int pid, int inc)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->pid == pid) {
      // Update nice value
      int newnice = p->nice + inc;

      // Optional: clamp to some range, e.g. [-20, 20]
      if (newnice < -20) newnice = -20;
      if (newnice > 20)  newnice = 20;

      p->nice = newnice;

      // Rule 6 from the project spec: whenever nice changes,
      // reset its queue level to the starting queue and reset runtime.
      p->qlevel   = starting_level_from_nice(p->nice);
      p->qruntime = 0;
      p->demote   = 0;

      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1; // pid not found
}


// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING){
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;
  
  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if(user_dst){
    return copyout(p->pagetable, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if(user_src){
    return copyin(p->pagetable, dst, src, len);
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [USED]      "used",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
  for(p = proc; p < &proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printf("%d %s %s", p->pid, state, p->name);
    printf("\n");
  }
}
