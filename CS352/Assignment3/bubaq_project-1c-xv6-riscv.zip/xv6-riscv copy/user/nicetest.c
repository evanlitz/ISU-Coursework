// Experiment 2: Show how RR, RRSP, and MLFQ treat different nice values.

#include "kernel/types.h"
#include "user/user.h"

static void
cpu_hog(void)   
{
  volatile unsigned x = 0;
  for (long i = 0; i < 300000000L; i++)
    x += i;
  printf("child %d done\n", getpid());
}

int
main(void)
{
  int parent = getpid();
  printf("nicetest: parent %d starting\n", parent);

  // Turn on kernel scheduler logging (like in fairtest.c).
  startLogging();

  for (int i = 0; i < 4; i++) {
    int pid = fork();
    if (pid < 0) {
      printf("nicetest: fork failed\n");
      while (wait(0) > 0) { }
      stopLogging();
      exit(1);
    }

    if (pid == 0) {
      // Child
      int n;

      // First two children -> nice = 5 (lower priority)
      // Last two children  -> nice = -5 (higher priority)
      if (i < 2)
        n = 5;
      else
        n = -5;

      int self = getpid();
      printf("nicetest: child pid=%d setting nice inc=%d\n", self, n);

      if (nice(self, n) < 0) {
        printf("nicetest: child pid=%d nice() failed\n", self);
        exit(1);
      }

      cpu_hog(); // CPU-bound work so scheduler behavior is visible
      exit(0);
    }
    // parent continues to fork remaining children
  }

  while (wait(0) > 0) { }

  stopLogging();
  printf("nicetest: parent %d, all children finished\n", parent);
  exit(0);
}
