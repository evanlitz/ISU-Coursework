#include "kernel/types.h"
#include "user/user.h"

static void cpu_hog(void) {   //Function that simulates the CPU bound behavior. Similar to the 1B function.
  volatile unsigned x = 0;
  for (long i = 0; i < 300000000L; i++) x += i;
  printf("child %d done\n", getpid());
}

int main(void) {
  startLogging();     // STart logging
  for (int i = 0; i < 4; i++) {
    int pid = fork();   // create child process
    if (pid == 0) { // child
      printf("child %d started\n", getpid());
      cpu_hog();    // take up CPU time
      exit(0);    // Exit
    }
  }
  while (wait(0) > 0) {/* join all */}
  stopLogging();    // Stop logging
  printf("parent %d: all children finished\n", getpid());
  exit(0);
}
