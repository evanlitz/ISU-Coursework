// Creates 4 children:
//   - two CPU-bound (busy loop)
//   - two IO-bound (sleep(1) in a loop)
// Used to see how different schedulers treat CPU vs IO bound tasks.

#include "kernel/types.h"
#include "user/user.h"

static void
cpu_bound(void)
{
  volatile unsigned x = 0;
  for (long i = 0; i < 300000000L; i++)
    x += i;
}

static void
io_bound(void)
{
  // IO-ish behavior: repeatedly sleep to yield CPU
  for (int i = 0; i < 100; i++) {
    sleep(1);   // give up CPU frequently
  }
}

int
main(void)
{
  int parent = getpid();      //assign process id of parent.
  printf("ioboundtest: parent %d starting\n", parent);

  startLogging(); // Turn on logging

  for (int i = 0; i < 4; i++) {   //Create the processes with fork (child processes)
    int pid = fork();
    if (pid < 0) {
      printf("ioboundtest: fork failed\n");
      while (wait(0) > 0) { }
      stopLogging();
      exit(1);
    }

    if (pid == 0) {
      int me = getpid();

      if (i < 2) {
        // First two children: CPU-bound
        printf("ioboundtest: CPU-bound child pid=%d starting\n", me);
        cpu_bound();
        printf("ioboundtest: CPU-bound child pid=%d done\n", me);
      } else {
        // Last two children: IO-bound
        printf("ioboundtest: IO-bound child pid=%d starting\n", me);
        io_bound();
        printf("ioboundtest: IO-bound child pid=%d done\n", me);
      }

      exit(0);
    }
    // parent continues loop to fork remaining children
  }

  // Parent waits for all 4 children
  while (wait(0) > 0) { }

  stopLogging();    //stop logging
  printf("ioboundtest: parent %d, all children finished\n", parent);
  exit(0);
}
