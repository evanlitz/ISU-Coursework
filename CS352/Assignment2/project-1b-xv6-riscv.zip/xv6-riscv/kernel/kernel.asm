
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	33010113          	addi	sp,sp,816 # 8000a330 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdb1c7>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e2a78793          	addi	a5,a5,-470 # 80000eae <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	2d0020ef          	jal	800023ea <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	00012517          	auipc	a0,0x12
    80000196:	19e50513          	addi	a0,a0,414 # 80012330 <cons>
    8000019a:	28f000ef          	jal	80000c28 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	00012497          	auipc	s1,0x12
    800001a2:	19248493          	addi	s1,s1,402 # 80012330 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	00012917          	auipc	s2,0x12
    800001aa:	22290913          	addi	s2,s2,546 # 800123c8 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	04b010ef          	jal	80001a08 <myproc>
    800001c2:	0c0020ef          	jal	80002282 <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	67b010ef          	jal	80002046 <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	00012717          	auipc	a4,0x12
    800001e2:	15270713          	addi	a4,a4,338 # 80012330 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	190020ef          	jal	800023a0 <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	00012517          	auipc	a0,0x12
    8000022c:	10850513          	addi	a0,a0,264 # 80012330 <cons>
    80000230:	28d000ef          	jal	80000cbc <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	00012717          	auipc	a4,0x12
    80000252:	16f72d23          	sw	a5,378(a4) # 800123c8 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	00012517          	auipc	a0,0x12
    80000268:	0cc50513          	addi	a0,a0,204 # 80012330 <cons>
    8000026c:	251000ef          	jal	80000cbc <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	00012517          	auipc	a0,0x12
    800002bc:	07850513          	addi	a0,a0,120 # 80012330 <cons>
    800002c0:	169000ef          	jal	80000c28 <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	15a020ef          	jal	80002434 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	00012517          	auipc	a0,0x12
    800002e2:	05250513          	addi	a0,a0,82 # 80012330 <cons>
    800002e6:	1d7000ef          	jal	80000cbc <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	00012717          	auipc	a4,0x12
    80000300:	03470713          	addi	a4,a4,52 # 80012330 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	00012717          	auipc	a4,0x12
    80000326:	00e70713          	addi	a4,a4,14 # 80012330 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	00012717          	auipc	a4,0x12
    80000350:	07c72703          	lw	a4,124(a4) # 800123c8 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	00012717          	auipc	a4,0x12
    80000366:	fce70713          	addi	a4,a4,-50 # 80012330 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	00012497          	auipc	s1,0x12
    80000376:	fbe48493          	addi	s1,s1,-66 # 80012330 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	00012717          	auipc	a4,0x12
    800003b8:	f7c70713          	addi	a4,a4,-132 # 80012330 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	00012717          	auipc	a4,0x12
    800003ce:	00f72323          	sw	a5,6(a4) # 800123d0 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	00012797          	auipc	a5,0x12
    800003ec:	f4878793          	addi	a5,a5,-184 # 80012330 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	00012797          	auipc	a5,0x12
    8000040e:	fcc7a123          	sw	a2,-62(a5) # 800123cc <cons+0x9c>
        wakeup(&cons.r);
    80000412:	00012517          	auipc	a0,0x12
    80000416:	fb650513          	addi	a0,a0,-74 # 800123c8 <cons+0x98>
    8000041a:	479010ef          	jal	80002092 <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00007597          	auipc	a1,0x7
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80007000 <etext>
    80000430:	00012517          	auipc	a0,0x12
    80000434:	f0050513          	addi	a0,a0,-256 # 80012330 <cons>
    80000438:	766000ef          	jal	80000b9e <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	00022797          	auipc	a5,0x22
    80000444:	06078793          	addi	a5,a5,96 # 800224a0 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007817          	auipc	a6,0x7
    80000482:	2f280813          	addi	a6,a6,754 # 80007770 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	0000a797          	auipc	a5,0xa
    8000051c:	ddc7a783          	lw	a5,-548(a5) # 8000a2f4 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	00012517          	auipc	a0,0x12
    80000562:	e7a50513          	addi	a0,a0,-390 # 800123d8 <pr>
    80000566:	6c2000ef          	jal	80000c28 <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00007c97          	auipc	s9,0x7
    800006d6:	09ec8c93          	addi	s9,s9,158 # 80007770 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00007a17          	auipc	s4,0x7
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80007008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	0000a797          	auipc	a5,0xa
    8000075e:	b9a7a783          	lw	a5,-1126(a5) # 8000a2f4 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
    release(&pr.lock);

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
    release(&pr.lock);
    80000784:	00012517          	auipc	a0,0x12
    80000788:	c5450513          	addi	a0,a0,-940 # 800123d8 <pr>
    8000078c:	530000ef          	jal	80000cbc <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	0000a797          	auipc	a5,0xa
    80000838:	ac97a023          	sw	s1,-1344(a5) # 8000a2f4 <panicking>
  printf("panic: ");
    8000083c:	00006517          	auipc	a0,0x6
    80000840:	7dc50513          	addi	a0,a0,2012 # 80007018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7d650513          	addi	a0,a0,2006 # 80007020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	0000a797          	auipc	a5,0xa
    8000085a:	a897ad23          	sw	s1,-1382(a5) # 8000a2f0 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00006597          	auipc	a1,0x6
    8000086c:	7c058593          	addi	a1,a1,1984 # 80007028 <etext+0x28>
    80000870:	00012517          	auipc	a0,0x12
    80000874:	b6850513          	addi	a0,a0,-1176 # 800123d8 <pr>
    80000878:	326000ef          	jal	80000b9e <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00006597          	auipc	a1,0x6
    800008c2:	77258593          	addi	a1,a1,1906 # 80007030 <etext+0x30>
    800008c6:	00012517          	auipc	a0,0x12
    800008ca:	b2a50513          	addi	a0,a0,-1238 # 800123f0 <tx_lock>
    800008ce:	2d0000ef          	jal	80000b9e <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	00012517          	auipc	a0,0x12
    800008ee:	b0650513          	addi	a0,a0,-1274 # 800123f0 <tx_lock>
    800008f2:	336000ef          	jal	80000c28 <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	0000a497          	auipc	s1,0xa
    8000090c:	9f448493          	addi	s1,s1,-1548 # 8000a2fc <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	00012997          	auipc	s3,0x12
    80000914:	ae098993          	addi	s3,s3,-1312 # 800123f0 <tx_lock>
    80000918:	0000a917          	auipc	s2,0xa
    8000091c:	9e090913          	addi	s2,s2,-1568 # 8000a2f8 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	71a010ef          	jal	80002046 <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	00012517          	auipc	a0,0x12
    8000095a:	a9a50513          	addi	a0,a0,-1382 # 800123f0 <tx_lock>
    8000095e:	35e000ef          	jal	80000cbc <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	0000a797          	auipc	a5,0xa
    8000097e:	97a7a783          	lw	a5,-1670(a5) # 8000a2f4 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	0000a797          	auipc	a5,0xa
    80000988:	96c7a783          	lw	a5,-1684(a5) # 8000a2f0 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	0000a797          	auipc	a5,0xa
    800009ae:	94a7a783          	lw	a5,-1718(a5) # 8000a2f4 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	226000ef          	jal	80000be4 <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	2a6000ef          	jal	80000c6c <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	00012517          	auipc	a0,0x12
    80000a0a:	9ea50513          	addi	a0,a0,-1558 # 800123f0 <tx_lock>
    80000a0e:	21a000ef          	jal	80000c28 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	00012517          	auipc	a0,0x12
    80000a24:	9d050513          	addi	a0,a0,-1584 # 800123f0 <tx_lock>
    80000a28:	294000ef          	jal	80000cbc <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	0000a797          	auipc	a5,0xa
    80000a40:	8c07a023          	sw	zero,-1856(a5) # 8000a2fc <tx_busy>
    wakeup(&tx_chan);
    80000a44:	0000a517          	auipc	a0,0xa
    80000a48:	8b450513          	addi	a0,a0,-1868 # 8000a2f8 <tx_chan>
    80000a4c:	646010ef          	jal	80002092 <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	e04a                	sd	s2,0(sp)
    80000a66:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a68:	00023797          	auipc	a5,0x23
    80000a6c:	bd078793          	addi	a5,a5,-1072 # 80023638 <end>
    80000a70:	00f53733          	sltu	a4,a0,a5
    80000a74:	47c5                	li	a5,17
    80000a76:	07ee                	slli	a5,a5,0x1b
    80000a78:	17fd                	addi	a5,a5,-1
    80000a7a:	00a7b7b3          	sltu	a5,a5,a0
    80000a7e:	8fd9                	or	a5,a5,a4
    80000a80:	ef95                	bnez	a5,80000abc <kfree+0x60>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	03451793          	slli	a5,a0,0x34
    80000a88:	eb95                	bnez	a5,80000abc <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a8a:	6605                	lui	a2,0x1
    80000a8c:	4585                	li	a1,1
    80000a8e:	26a000ef          	jal	80000cf8 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a92:	00012917          	auipc	s2,0x12
    80000a96:	97690913          	addi	s2,s2,-1674 # 80012408 <kmem>
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	18c000ef          	jal	80000c28 <acquire>
  r->next = kmem.freelist;
    80000aa0:	01893783          	ld	a5,24(s2)
    80000aa4:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000aa6:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000aaa:	854a                	mv	a0,s2
    80000aac:	210000ef          	jal	80000cbc <release>
}
    80000ab0:	60e2                	ld	ra,24(sp)
    80000ab2:	6442                	ld	s0,16(sp)
    80000ab4:	64a2                	ld	s1,8(sp)
    80000ab6:	6902                	ld	s2,0(sp)
    80000ab8:	6105                	addi	sp,sp,32
    80000aba:	8082                	ret
    panic("kfree");
    80000abc:	00006517          	auipc	a0,0x6
    80000ac0:	57c50513          	addi	a0,a0,1404 # 80007038 <etext+0x38>
    80000ac4:	d61ff0ef          	jal	80000824 <panic>

0000000080000ac8 <freerange>:
{
    80000ac8:	7179                	addi	sp,sp,-48
    80000aca:	f406                	sd	ra,40(sp)
    80000acc:	f022                	sd	s0,32(sp)
    80000ace:	ec26                	sd	s1,24(sp)
    80000ad0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ad2:	6785                	lui	a5,0x1
    80000ad4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad8:	00e504b3          	add	s1,a0,a4
    80000adc:	777d                	lui	a4,0xfffff
    80000ade:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae0:	94be                	add	s1,s1,a5
    80000ae2:	0295e263          	bltu	a1,s1,80000b06 <freerange+0x3e>
    80000ae6:	e84a                	sd	s2,16(sp)
    80000ae8:	e44e                	sd	s3,8(sp)
    80000aea:	e052                	sd	s4,0(sp)
    80000aec:	892e                	mv	s2,a1
    kfree(p);
    80000aee:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af0:	89be                	mv	s3,a5
    kfree(p);
    80000af2:	01448533          	add	a0,s1,s4
    80000af6:	f67ff0ef          	jal	80000a5c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000afa:	94ce                	add	s1,s1,s3
    80000afc:	fe997be3          	bgeu	s2,s1,80000af2 <freerange+0x2a>
    80000b00:	6942                	ld	s2,16(sp)
    80000b02:	69a2                	ld	s3,8(sp)
    80000b04:	6a02                	ld	s4,0(sp)
}
    80000b06:	70a2                	ld	ra,40(sp)
    80000b08:	7402                	ld	s0,32(sp)
    80000b0a:	64e2                	ld	s1,24(sp)
    80000b0c:	6145                	addi	sp,sp,48
    80000b0e:	8082                	ret

0000000080000b10 <kinit>:
{
    80000b10:	1141                	addi	sp,sp,-16
    80000b12:	e406                	sd	ra,8(sp)
    80000b14:	e022                	sd	s0,0(sp)
    80000b16:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b18:	00006597          	auipc	a1,0x6
    80000b1c:	52858593          	addi	a1,a1,1320 # 80007040 <etext+0x40>
    80000b20:	00012517          	auipc	a0,0x12
    80000b24:	8e850513          	addi	a0,a0,-1816 # 80012408 <kmem>
    80000b28:	076000ef          	jal	80000b9e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00023517          	auipc	a0,0x23
    80000b34:	b0850513          	addi	a0,a0,-1272 # 80023638 <end>
    80000b38:	f91ff0ef          	jal	80000ac8 <freerange>
}
    80000b3c:	60a2                	ld	ra,8(sp)
    80000b3e:	6402                	ld	s0,0(sp)
    80000b40:	0141                	addi	sp,sp,16
    80000b42:	8082                	ret

0000000080000b44 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b44:	1101                	addi	sp,sp,-32
    80000b46:	ec06                	sd	ra,24(sp)
    80000b48:	e822                	sd	s0,16(sp)
    80000b4a:	e426                	sd	s1,8(sp)
    80000b4c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4e:	00012517          	auipc	a0,0x12
    80000b52:	8ba50513          	addi	a0,a0,-1862 # 80012408 <kmem>
    80000b56:	0d2000ef          	jal	80000c28 <acquire>
  r = kmem.freelist;
    80000b5a:	00012497          	auipc	s1,0x12
    80000b5e:	8c64b483          	ld	s1,-1850(s1) # 80012420 <kmem+0x18>
  if(r)
    80000b62:	c49d                	beqz	s1,80000b90 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b64:	609c                	ld	a5,0(s1)
    80000b66:	00012717          	auipc	a4,0x12
    80000b6a:	8af73d23          	sd	a5,-1862(a4) # 80012420 <kmem+0x18>
  release(&kmem.lock);
    80000b6e:	00012517          	auipc	a0,0x12
    80000b72:	89a50513          	addi	a0,a0,-1894 # 80012408 <kmem>
    80000b76:	146000ef          	jal	80000cbc <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	178000ef          	jal	80000cf8 <memset>
  return (void*)r;
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	00012517          	auipc	a0,0x12
    80000b94:	87850513          	addi	a0,a0,-1928 # 80012408 <kmem>
    80000b98:	124000ef          	jal	80000cbc <release>
  if(r)
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x40>

0000000080000b9e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b9e:	1141                	addi	sp,sp,-16
    80000ba0:	e406                	sd	ra,8(sp)
    80000ba2:	e022                	sd	s0,0(sp)
    80000ba4:	0800                	addi	s0,sp,16
  lk->name = name;
    80000ba6:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000ba8:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bac:	00053823          	sd	zero,16(a0)
}
    80000bb0:	60a2                	ld	ra,8(sp)
    80000bb2:	6402                	ld	s0,0(sp)
    80000bb4:	0141                	addi	sp,sp,16
    80000bb6:	8082                	ret

0000000080000bb8 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bb8:	411c                	lw	a5,0(a0)
    80000bba:	e399                	bnez	a5,80000bc0 <holding+0x8>
    80000bbc:	4501                	li	a0,0
  return r;
}
    80000bbe:	8082                	ret
{
    80000bc0:	1101                	addi	sp,sp,-32
    80000bc2:	ec06                	sd	ra,24(sp)
    80000bc4:	e822                	sd	s0,16(sp)
    80000bc6:	e426                	sd	s1,8(sp)
    80000bc8:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bca:	691c                	ld	a5,16(a0)
    80000bcc:	84be                	mv	s1,a5
    80000bce:	61b000ef          	jal	800019e8 <mycpu>
    80000bd2:	40a48533          	sub	a0,s1,a0
    80000bd6:	00153513          	seqz	a0,a0
}
    80000bda:	60e2                	ld	ra,24(sp)
    80000bdc:	6442                	ld	s0,16(sp)
    80000bde:	64a2                	ld	s1,8(sp)
    80000be0:	6105                	addi	sp,sp,32
    80000be2:	8082                	ret

0000000080000be4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000be4:	1101                	addi	sp,sp,-32
    80000be6:	ec06                	sd	ra,24(sp)
    80000be8:	e822                	sd	s0,16(sp)
    80000bea:	e426                	sd	s1,8(sp)
    80000bec:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bee:	100027f3          	csrr	a5,sstatus
    80000bf2:	84be                	mv	s1,a5
    80000bf4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bf8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bfa:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000bfe:	5eb000ef          	jal	800019e8 <mycpu>
    80000c02:	5d3c                	lw	a5,120(a0)
    80000c04:	cb99                	beqz	a5,80000c1a <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c06:	5e3000ef          	jal	800019e8 <mycpu>
    80000c0a:	5d3c                	lw	a5,120(a0)
    80000c0c:	2785                	addiw	a5,a5,1
    80000c0e:	dd3c                	sw	a5,120(a0)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    mycpu()->intena = old;
    80000c1a:	5cf000ef          	jal	800019e8 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c1e:	0014d793          	srli	a5,s1,0x1
    80000c22:	8b85                	andi	a5,a5,1
    80000c24:	dd7c                	sw	a5,124(a0)
    80000c26:	b7c5                	j	80000c06 <push_off+0x22>

0000000080000c28 <acquire>:
{
    80000c28:	1101                	addi	sp,sp,-32
    80000c2a:	ec06                	sd	ra,24(sp)
    80000c2c:	e822                	sd	s0,16(sp)
    80000c2e:	e426                	sd	s1,8(sp)
    80000c30:	1000                	addi	s0,sp,32
    80000c32:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c34:	fb1ff0ef          	jal	80000be4 <push_off>
  if(holding(lk))
    80000c38:	8526                	mv	a0,s1
    80000c3a:	f7fff0ef          	jal	80000bb8 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c3e:	4705                	li	a4,1
  if(holding(lk))
    80000c40:	e105                	bnez	a0,80000c60 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c42:	87ba                	mv	a5,a4
    80000c44:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c48:	2781                	sext.w	a5,a5
    80000c4a:	ffe5                	bnez	a5,80000c42 <acquire+0x1a>
  __sync_synchronize();
    80000c4c:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c50:	599000ef          	jal	800019e8 <mycpu>
    80000c54:	e888                	sd	a0,16(s1)
}
    80000c56:	60e2                	ld	ra,24(sp)
    80000c58:	6442                	ld	s0,16(sp)
    80000c5a:	64a2                	ld	s1,8(sp)
    80000c5c:	6105                	addi	sp,sp,32
    80000c5e:	8082                	ret
    panic("acquire");
    80000c60:	00006517          	auipc	a0,0x6
    80000c64:	3e850513          	addi	a0,a0,1000 # 80007048 <etext+0x48>
    80000c68:	bbdff0ef          	jal	80000824 <panic>

0000000080000c6c <pop_off>:

void
pop_off(void)
{
    80000c6c:	1141                	addi	sp,sp,-16
    80000c6e:	e406                	sd	ra,8(sp)
    80000c70:	e022                	sd	s0,0(sp)
    80000c72:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c74:	575000ef          	jal	800019e8 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c7c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c7e:	e39d                	bnez	a5,80000ca4 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c80:	5d3c                	lw	a5,120(a0)
    80000c82:	02f05763          	blez	a5,80000cb0 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000c86:	37fd                	addiw	a5,a5,-1
    80000c88:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c8a:	eb89                	bnez	a5,80000c9c <pop_off+0x30>
    80000c8c:	5d7c                	lw	a5,124(a0)
    80000c8e:	c799                	beqz	a5,80000c9c <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c90:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c94:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c98:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c9c:	60a2                	ld	ra,8(sp)
    80000c9e:	6402                	ld	s0,0(sp)
    80000ca0:	0141                	addi	sp,sp,16
    80000ca2:	8082                	ret
    panic("pop_off - interruptible");
    80000ca4:	00006517          	auipc	a0,0x6
    80000ca8:	3ac50513          	addi	a0,a0,940 # 80007050 <etext+0x50>
    80000cac:	b79ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000cb0:	00006517          	auipc	a0,0x6
    80000cb4:	3b850513          	addi	a0,a0,952 # 80007068 <etext+0x68>
    80000cb8:	b6dff0ef          	jal	80000824 <panic>

0000000080000cbc <release>:
{
    80000cbc:	1101                	addi	sp,sp,-32
    80000cbe:	ec06                	sd	ra,24(sp)
    80000cc0:	e822                	sd	s0,16(sp)
    80000cc2:	e426                	sd	s1,8(sp)
    80000cc4:	1000                	addi	s0,sp,32
    80000cc6:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cc8:	ef1ff0ef          	jal	80000bb8 <holding>
    80000ccc:	c105                	beqz	a0,80000cec <release+0x30>
  lk->cpu = 0;
    80000cce:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cd2:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000cd6:	0310000f          	fence	rw,w
    80000cda:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cde:	f8fff0ef          	jal	80000c6c <pop_off>
}
    80000ce2:	60e2                	ld	ra,24(sp)
    80000ce4:	6442                	ld	s0,16(sp)
    80000ce6:	64a2                	ld	s1,8(sp)
    80000ce8:	6105                	addi	sp,sp,32
    80000cea:	8082                	ret
    panic("release");
    80000cec:	00006517          	auipc	a0,0x6
    80000cf0:	38450513          	addi	a0,a0,900 # 80007070 <etext+0x70>
    80000cf4:	b31ff0ef          	jal	80000824 <panic>

0000000080000cf8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cf8:	1141                	addi	sp,sp,-16
    80000cfa:	e406                	sd	ra,8(sp)
    80000cfc:	e022                	sd	s0,0(sp)
    80000cfe:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d00:	ca19                	beqz	a2,80000d16 <memset+0x1e>
    80000d02:	87aa                	mv	a5,a0
    80000d04:	1602                	slli	a2,a2,0x20
    80000d06:	9201                	srli	a2,a2,0x20
    80000d08:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d0c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d10:	0785                	addi	a5,a5,1
    80000d12:	fee79de3          	bne	a5,a4,80000d0c <memset+0x14>
  }
  return dst;
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret

0000000080000d1e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e406                	sd	ra,8(sp)
    80000d22:	e022                	sd	s0,0(sp)
    80000d24:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d26:	c61d                	beqz	a2,80000d54 <memcmp+0x36>
    80000d28:	1602                	slli	a2,a2,0x20
    80000d2a:	9201                	srli	a2,a2,0x20
    80000d2c:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d30:	00054783          	lbu	a5,0(a0)
    80000d34:	0005c703          	lbu	a4,0(a1)
    80000d38:	00e79863          	bne	a5,a4,80000d48 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d3c:	0505                	addi	a0,a0,1
    80000d3e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d40:	fed518e3          	bne	a0,a3,80000d30 <memcmp+0x12>
  }

  return 0;
    80000d44:	4501                	li	a0,0
    80000d46:	a019                	j	80000d4c <memcmp+0x2e>
      return *s1 - *s2;
    80000d48:	40e7853b          	subw	a0,a5,a4
}
    80000d4c:	60a2                	ld	ra,8(sp)
    80000d4e:	6402                	ld	s0,0(sp)
    80000d50:	0141                	addi	sp,sp,16
    80000d52:	8082                	ret
  return 0;
    80000d54:	4501                	li	a0,0
    80000d56:	bfdd                	j	80000d4c <memcmp+0x2e>

0000000080000d58 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d58:	1141                	addi	sp,sp,-16
    80000d5a:	e406                	sd	ra,8(sp)
    80000d5c:	e022                	sd	s0,0(sp)
    80000d5e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d60:	c205                	beqz	a2,80000d80 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d62:	02a5e363          	bltu	a1,a0,80000d88 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d66:	1602                	slli	a2,a2,0x20
    80000d68:	9201                	srli	a2,a2,0x20
    80000d6a:	00c587b3          	add	a5,a1,a2
{
    80000d6e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	0705                	addi	a4,a4,1
    80000d74:	fff5c683          	lbu	a3,-1(a1)
    80000d78:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d7c:	feb79ae3          	bne	a5,a1,80000d70 <memmove+0x18>

  return dst;
}
    80000d80:	60a2                	ld	ra,8(sp)
    80000d82:	6402                	ld	s0,0(sp)
    80000d84:	0141                	addi	sp,sp,16
    80000d86:	8082                	ret
  if(s < d && s + n > d){
    80000d88:	02061693          	slli	a3,a2,0x20
    80000d8c:	9281                	srli	a3,a3,0x20
    80000d8e:	00d58733          	add	a4,a1,a3
    80000d92:	fce57ae3          	bgeu	a0,a4,80000d66 <memmove+0xe>
    d += n;
    80000d96:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d98:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d9c:	1782                	slli	a5,a5,0x20
    80000d9e:	9381                	srli	a5,a5,0x20
    80000da0:	fff7c793          	not	a5,a5
    80000da4:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000da6:	177d                	addi	a4,a4,-1
    80000da8:	16fd                	addi	a3,a3,-1
    80000daa:	00074603          	lbu	a2,0(a4)
    80000dae:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000db2:	fee79ae3          	bne	a5,a4,80000da6 <memmove+0x4e>
    80000db6:	b7e9                	j	80000d80 <memmove+0x28>

0000000080000db8 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000db8:	1141                	addi	sp,sp,-16
    80000dba:	e406                	sd	ra,8(sp)
    80000dbc:	e022                	sd	s0,0(sp)
    80000dbe:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dc0:	f99ff0ef          	jal	80000d58 <memmove>
}
    80000dc4:	60a2                	ld	ra,8(sp)
    80000dc6:	6402                	ld	s0,0(sp)
    80000dc8:	0141                	addi	sp,sp,16
    80000dca:	8082                	ret

0000000080000dcc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000dcc:	1141                	addi	sp,sp,-16
    80000dce:	e406                	sd	ra,8(sp)
    80000dd0:	e022                	sd	s0,0(sp)
    80000dd2:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dd4:	ce11                	beqz	a2,80000df0 <strncmp+0x24>
    80000dd6:	00054783          	lbu	a5,0(a0)
    80000dda:	cf89                	beqz	a5,80000df4 <strncmp+0x28>
    80000ddc:	0005c703          	lbu	a4,0(a1)
    80000de0:	00f71a63          	bne	a4,a5,80000df4 <strncmp+0x28>
    n--, p++, q++;
    80000de4:	367d                	addiw	a2,a2,-1
    80000de6:	0505                	addi	a0,a0,1
    80000de8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dea:	f675                	bnez	a2,80000dd6 <strncmp+0xa>
  if(n == 0)
    return 0;
    80000dec:	4501                	li	a0,0
    80000dee:	a801                	j	80000dfe <strncmp+0x32>
    80000df0:	4501                	li	a0,0
    80000df2:	a031                	j	80000dfe <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000df4:	00054503          	lbu	a0,0(a0)
    80000df8:	0005c783          	lbu	a5,0(a1)
    80000dfc:	9d1d                	subw	a0,a0,a5
}
    80000dfe:	60a2                	ld	ra,8(sp)
    80000e00:	6402                	ld	s0,0(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e406                	sd	ra,8(sp)
    80000e0a:	e022                	sd	s0,0(sp)
    80000e0c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e0e:	87aa                	mv	a5,a0
    80000e10:	a011                	j	80000e14 <strncpy+0xe>
    80000e12:	8636                	mv	a2,a3
    80000e14:	02c05863          	blez	a2,80000e44 <strncpy+0x3e>
    80000e18:	fff6069b          	addiw	a3,a2,-1
    80000e1c:	8836                	mv	a6,a3
    80000e1e:	0785                	addi	a5,a5,1
    80000e20:	0005c703          	lbu	a4,0(a1)
    80000e24:	fee78fa3          	sb	a4,-1(a5)
    80000e28:	0585                	addi	a1,a1,1
    80000e2a:	f765                	bnez	a4,80000e12 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e2c:	873e                	mv	a4,a5
    80000e2e:	01005b63          	blez	a6,80000e44 <strncpy+0x3e>
    80000e32:	9fb1                	addw	a5,a5,a2
    80000e34:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e36:	0705                	addi	a4,a4,1
    80000e38:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e3c:	40e786bb          	subw	a3,a5,a4
    80000e40:	fed04be3          	bgtz	a3,80000e36 <strncpy+0x30>
  return os;
}
    80000e44:	60a2                	ld	ra,8(sp)
    80000e46:	6402                	ld	s0,0(sp)
    80000e48:	0141                	addi	sp,sp,16
    80000e4a:	8082                	ret

0000000080000e4c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e4c:	1141                	addi	sp,sp,-16
    80000e4e:	e406                	sd	ra,8(sp)
    80000e50:	e022                	sd	s0,0(sp)
    80000e52:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e54:	02c05363          	blez	a2,80000e7a <safestrcpy+0x2e>
    80000e58:	fff6069b          	addiw	a3,a2,-1
    80000e5c:	1682                	slli	a3,a3,0x20
    80000e5e:	9281                	srli	a3,a3,0x20
    80000e60:	96ae                	add	a3,a3,a1
    80000e62:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e64:	00d58963          	beq	a1,a3,80000e76 <safestrcpy+0x2a>
    80000e68:	0585                	addi	a1,a1,1
    80000e6a:	0785                	addi	a5,a5,1
    80000e6c:	fff5c703          	lbu	a4,-1(a1)
    80000e70:	fee78fa3          	sb	a4,-1(a5)
    80000e74:	fb65                	bnez	a4,80000e64 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e76:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e7a:	60a2                	ld	ra,8(sp)
    80000e7c:	6402                	ld	s0,0(sp)
    80000e7e:	0141                	addi	sp,sp,16
    80000e80:	8082                	ret

0000000080000e82 <strlen>:

int
strlen(const char *s)
{
    80000e82:	1141                	addi	sp,sp,-16
    80000e84:	e406                	sd	ra,8(sp)
    80000e86:	e022                	sd	s0,0(sp)
    80000e88:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e8a:	00054783          	lbu	a5,0(a0)
    80000e8e:	cf91                	beqz	a5,80000eaa <strlen+0x28>
    80000e90:	00150793          	addi	a5,a0,1
    80000e94:	86be                	mv	a3,a5
    80000e96:	0785                	addi	a5,a5,1
    80000e98:	fff7c703          	lbu	a4,-1(a5)
    80000e9c:	ff65                	bnez	a4,80000e94 <strlen+0x12>
    80000e9e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ea2:	60a2                	ld	ra,8(sp)
    80000ea4:	6402                	ld	s0,0(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret
  for(n = 0; s[n]; n++)
    80000eaa:	4501                	li	a0,0
    80000eac:	bfdd                	j	80000ea2 <strlen+0x20>

0000000080000eae <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000eae:	1141                	addi	sp,sp,-16
    80000eb0:	e406                	sd	ra,8(sp)
    80000eb2:	e022                	sd	s0,0(sp)
    80000eb4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000eb6:	31f000ef          	jal	800019d4 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000eba:	00009717          	auipc	a4,0x9
    80000ebe:	44670713          	addi	a4,a4,1094 # 8000a300 <started>
  if(cpuid() == 0){
    80000ec2:	c51d                	beqz	a0,80000ef0 <main+0x42>
    while(started == 0)
    80000ec4:	431c                	lw	a5,0(a4)
    80000ec6:	2781                	sext.w	a5,a5
    80000ec8:	dff5                	beqz	a5,80000ec4 <main+0x16>
      ;
    __sync_synchronize();
    80000eca:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ece:	307000ef          	jal	800019d4 <cpuid>
    80000ed2:	85aa                	mv	a1,a0
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	1c450513          	addi	a0,a0,452 # 80007098 <etext+0x98>
    80000edc:	e1eff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000ee0:	080000ef          	jal	80000f60 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ee4:	682010ef          	jal	80002566 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ee8:	6a0040ef          	jal	80005588 <plicinithart>
  }

  scheduler();        
    80000eec:	79b000ef          	jal	80001e86 <scheduler>
    consoleinit();
    80000ef0:	d30ff0ef          	jal	80000420 <consoleinit>
    printfinit();
    80000ef4:	96dff0ef          	jal	80000860 <printfinit>
    printf("\n");
    80000ef8:	00006517          	auipc	a0,0x6
    80000efc:	18050513          	addi	a0,a0,384 # 80007078 <etext+0x78>
    80000f00:	dfaff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000f04:	00006517          	auipc	a0,0x6
    80000f08:	17c50513          	addi	a0,a0,380 # 80007080 <etext+0x80>
    80000f0c:	deeff0ef          	jal	800004fa <printf>
    printf("\n");
    80000f10:	00006517          	auipc	a0,0x6
    80000f14:	16850513          	addi	a0,a0,360 # 80007078 <etext+0x78>
    80000f18:	de2ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000f1c:	bf5ff0ef          	jal	80000b10 <kinit>
    kvminit();       // create kernel page table
    80000f20:	2cc000ef          	jal	800011ec <kvminit>
    kvminithart();   // turn on paging
    80000f24:	03c000ef          	jal	80000f60 <kvminithart>
    procinit();      // process table
    80000f28:	1f7000ef          	jal	8000191e <procinit>
    trapinit();      // trap vectors
    80000f2c:	616010ef          	jal	80002542 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f30:	636010ef          	jal	80002566 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f34:	63a040ef          	jal	8000556e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f38:	650040ef          	jal	80005588 <plicinithart>
    binit();         // buffer cache
    80000f3c:	4c3010ef          	jal	80002bfe <binit>
    iinit();         // inode table
    80000f40:	214020ef          	jal	80003154 <iinit>
    fileinit();      // file table
    80000f44:	140030ef          	jal	80004084 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f48:	730040ef          	jal	80005678 <virtio_disk_init>
    userinit();      // first user process
    80000f4c:	58f000ef          	jal	80001cda <userinit>
    __sync_synchronize();
    80000f50:	0330000f          	fence	rw,rw
    started = 1;
    80000f54:	4785                	li	a5,1
    80000f56:	00009717          	auipc	a4,0x9
    80000f5a:	3af72523          	sw	a5,938(a4) # 8000a300 <started>
    80000f5e:	b779                	j	80000eec <main+0x3e>

0000000080000f60 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f60:	1141                	addi	sp,sp,-16
    80000f62:	e406                	sd	ra,8(sp)
    80000f64:	e022                	sd	s0,0(sp)
    80000f66:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f68:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f6c:	00009797          	auipc	a5,0x9
    80000f70:	39c7b783          	ld	a5,924(a5) # 8000a308 <kernel_pagetable>
    80000f74:	83b1                	srli	a5,a5,0xc
    80000f76:	577d                	li	a4,-1
    80000f78:	177e                	slli	a4,a4,0x3f
    80000f7a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f7c:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f80:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f84:	60a2                	ld	ra,8(sp)
    80000f86:	6402                	ld	s0,0(sp)
    80000f88:	0141                	addi	sp,sp,16
    80000f8a:	8082                	ret

0000000080000f8c <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f8c:	7139                	addi	sp,sp,-64
    80000f8e:	fc06                	sd	ra,56(sp)
    80000f90:	f822                	sd	s0,48(sp)
    80000f92:	f426                	sd	s1,40(sp)
    80000f94:	f04a                	sd	s2,32(sp)
    80000f96:	ec4e                	sd	s3,24(sp)
    80000f98:	e852                	sd	s4,16(sp)
    80000f9a:	e456                	sd	s5,8(sp)
    80000f9c:	e05a                	sd	s6,0(sp)
    80000f9e:	0080                	addi	s0,sp,64
    80000fa0:	84aa                	mv	s1,a0
    80000fa2:	89ae                	mv	s3,a1
    80000fa4:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fa6:	57fd                	li	a5,-1
    80000fa8:	83e9                	srli	a5,a5,0x1a
    80000faa:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fac:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fae:	04b7e263          	bltu	a5,a1,80000ff2 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fb2:	0149d933          	srl	s2,s3,s4
    80000fb6:	1ff97913          	andi	s2,s2,511
    80000fba:	090e                	slli	s2,s2,0x3
    80000fbc:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fbe:	00093483          	ld	s1,0(s2)
    80000fc2:	0014f793          	andi	a5,s1,1
    80000fc6:	cf85                	beqz	a5,80000ffe <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fc8:	80a9                	srli	s1,s1,0xa
    80000fca:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000fcc:	3a5d                	addiw	s4,s4,-9
    80000fce:	ff5a12e3          	bne	s4,s5,80000fb2 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000fd2:	00c9d513          	srli	a0,s3,0xc
    80000fd6:	1ff57513          	andi	a0,a0,511
    80000fda:	050e                	slli	a0,a0,0x3
    80000fdc:	9526                	add	a0,a0,s1
}
    80000fde:	70e2                	ld	ra,56(sp)
    80000fe0:	7442                	ld	s0,48(sp)
    80000fe2:	74a2                	ld	s1,40(sp)
    80000fe4:	7902                	ld	s2,32(sp)
    80000fe6:	69e2                	ld	s3,24(sp)
    80000fe8:	6a42                	ld	s4,16(sp)
    80000fea:	6aa2                	ld	s5,8(sp)
    80000fec:	6b02                	ld	s6,0(sp)
    80000fee:	6121                	addi	sp,sp,64
    80000ff0:	8082                	ret
    panic("walk");
    80000ff2:	00006517          	auipc	a0,0x6
    80000ff6:	0be50513          	addi	a0,a0,190 # 800070b0 <etext+0xb0>
    80000ffa:	82bff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000ffe:	020b0263          	beqz	s6,80001022 <walk+0x96>
    80001002:	b43ff0ef          	jal	80000b44 <kalloc>
    80001006:	84aa                	mv	s1,a0
    80001008:	d979                	beqz	a0,80000fde <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    8000100a:	6605                	lui	a2,0x1
    8000100c:	4581                	li	a1,0
    8000100e:	cebff0ef          	jal	80000cf8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001012:	00c4d793          	srli	a5,s1,0xc
    80001016:	07aa                	slli	a5,a5,0xa
    80001018:	0017e793          	ori	a5,a5,1
    8000101c:	00f93023          	sd	a5,0(s2)
    80001020:	b775                	j	80000fcc <walk+0x40>
        return 0;
    80001022:	4501                	li	a0,0
    80001024:	bf6d                	j	80000fde <walk+0x52>

0000000080001026 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001026:	57fd                	li	a5,-1
    80001028:	83e9                	srli	a5,a5,0x1a
    8000102a:	00b7f463          	bgeu	a5,a1,80001032 <walkaddr+0xc>
    return 0;
    8000102e:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001030:	8082                	ret
{
    80001032:	1141                	addi	sp,sp,-16
    80001034:	e406                	sd	ra,8(sp)
    80001036:	e022                	sd	s0,0(sp)
    80001038:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000103a:	4601                	li	a2,0
    8000103c:	f51ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    80001040:	c901                	beqz	a0,80001050 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    80001042:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001044:	0117f693          	andi	a3,a5,17
    80001048:	4745                	li	a4,17
    return 0;
    8000104a:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    8000104c:	00e68663          	beq	a3,a4,80001058 <walkaddr+0x32>
}
    80001050:	60a2                	ld	ra,8(sp)
    80001052:	6402                	ld	s0,0(sp)
    80001054:	0141                	addi	sp,sp,16
    80001056:	8082                	ret
  pa = PTE2PA(*pte);
    80001058:	83a9                	srli	a5,a5,0xa
    8000105a:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000105e:	bfcd                	j	80001050 <walkaddr+0x2a>

0000000080001060 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001060:	715d                	addi	sp,sp,-80
    80001062:	e486                	sd	ra,72(sp)
    80001064:	e0a2                	sd	s0,64(sp)
    80001066:	fc26                	sd	s1,56(sp)
    80001068:	f84a                	sd	s2,48(sp)
    8000106a:	f44e                	sd	s3,40(sp)
    8000106c:	f052                	sd	s4,32(sp)
    8000106e:	ec56                	sd	s5,24(sp)
    80001070:	e85a                	sd	s6,16(sp)
    80001072:	e45e                	sd	s7,8(sp)
    80001074:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001076:	03459793          	slli	a5,a1,0x34
    8000107a:	eba1                	bnez	a5,800010ca <mappages+0x6a>
    8000107c:	8a2a                	mv	s4,a0
    8000107e:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001080:	03461793          	slli	a5,a2,0x34
    80001084:	eba9                	bnez	a5,800010d6 <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    80001086:	ce31                	beqz	a2,800010e2 <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001088:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    8000108c:	80060613          	addi	a2,a2,-2048
    80001090:	00b60933          	add	s2,a2,a1
  a = va;
    80001094:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    80001096:	4b05                	li	s6,1
    80001098:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000109c:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    8000109e:	865a                	mv	a2,s6
    800010a0:	85a6                	mv	a1,s1
    800010a2:	8552                	mv	a0,s4
    800010a4:	ee9ff0ef          	jal	80000f8c <walk>
    800010a8:	c929                	beqz	a0,800010fa <mappages+0x9a>
    if(*pte & PTE_V)
    800010aa:	611c                	ld	a5,0(a0)
    800010ac:	8b85                	andi	a5,a5,1
    800010ae:	e3a1                	bnez	a5,800010ee <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010b0:	013487b3          	add	a5,s1,s3
    800010b4:	83b1                	srli	a5,a5,0xc
    800010b6:	07aa                	slli	a5,a5,0xa
    800010b8:	0157e7b3          	or	a5,a5,s5
    800010bc:	0017e793          	ori	a5,a5,1
    800010c0:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010c2:	05248863          	beq	s1,s2,80001112 <mappages+0xb2>
    a += PGSIZE;
    800010c6:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c8:	bfd9                	j	8000109e <mappages+0x3e>
    panic("mappages: va not aligned");
    800010ca:	00006517          	auipc	a0,0x6
    800010ce:	fee50513          	addi	a0,a0,-18 # 800070b8 <etext+0xb8>
    800010d2:	f52ff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    800010d6:	00006517          	auipc	a0,0x6
    800010da:	00250513          	addi	a0,a0,2 # 800070d8 <etext+0xd8>
    800010de:	f46ff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    800010e2:	00006517          	auipc	a0,0x6
    800010e6:	01650513          	addi	a0,a0,22 # 800070f8 <etext+0xf8>
    800010ea:	f3aff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    800010ee:	00006517          	auipc	a0,0x6
    800010f2:	01a50513          	addi	a0,a0,26 # 80007108 <etext+0x108>
    800010f6:	f2eff0ef          	jal	80000824 <panic>
      return -1;
    800010fa:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010fc:	60a6                	ld	ra,72(sp)
    800010fe:	6406                	ld	s0,64(sp)
    80001100:	74e2                	ld	s1,56(sp)
    80001102:	7942                	ld	s2,48(sp)
    80001104:	79a2                	ld	s3,40(sp)
    80001106:	7a02                	ld	s4,32(sp)
    80001108:	6ae2                	ld	s5,24(sp)
    8000110a:	6b42                	ld	s6,16(sp)
    8000110c:	6ba2                	ld	s7,8(sp)
    8000110e:	6161                	addi	sp,sp,80
    80001110:	8082                	ret
  return 0;
    80001112:	4501                	li	a0,0
    80001114:	b7e5                	j	800010fc <mappages+0x9c>

0000000080001116 <kvmmap>:
{
    80001116:	1141                	addi	sp,sp,-16
    80001118:	e406                	sd	ra,8(sp)
    8000111a:	e022                	sd	s0,0(sp)
    8000111c:	0800                	addi	s0,sp,16
    8000111e:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001120:	86b2                	mv	a3,a2
    80001122:	863e                	mv	a2,a5
    80001124:	f3dff0ef          	jal	80001060 <mappages>
    80001128:	e509                	bnez	a0,80001132 <kvmmap+0x1c>
}
    8000112a:	60a2                	ld	ra,8(sp)
    8000112c:	6402                	ld	s0,0(sp)
    8000112e:	0141                	addi	sp,sp,16
    80001130:	8082                	ret
    panic("kvmmap");
    80001132:	00006517          	auipc	a0,0x6
    80001136:	fe650513          	addi	a0,a0,-26 # 80007118 <etext+0x118>
    8000113a:	eeaff0ef          	jal	80000824 <panic>

000000008000113e <kvmmake>:
{
    8000113e:	1101                	addi	sp,sp,-32
    80001140:	ec06                	sd	ra,24(sp)
    80001142:	e822                	sd	s0,16(sp)
    80001144:	e426                	sd	s1,8(sp)
    80001146:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001148:	9fdff0ef          	jal	80000b44 <kalloc>
    8000114c:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000114e:	6605                	lui	a2,0x1
    80001150:	4581                	li	a1,0
    80001152:	ba7ff0ef          	jal	80000cf8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001156:	4719                	li	a4,6
    80001158:	6685                	lui	a3,0x1
    8000115a:	10000637          	lui	a2,0x10000
    8000115e:	85b2                	mv	a1,a2
    80001160:	8526                	mv	a0,s1
    80001162:	fb5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001166:	4719                	li	a4,6
    80001168:	6685                	lui	a3,0x1
    8000116a:	10001637          	lui	a2,0x10001
    8000116e:	85b2                	mv	a1,a2
    80001170:	8526                	mv	a0,s1
    80001172:	fa5ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001176:	4719                	li	a4,6
    80001178:	040006b7          	lui	a3,0x4000
    8000117c:	0c000637          	lui	a2,0xc000
    80001180:	85b2                	mv	a1,a2
    80001182:	8526                	mv	a0,s1
    80001184:	f93ff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001188:	4729                	li	a4,10
    8000118a:	80006697          	auipc	a3,0x80006
    8000118e:	e7668693          	addi	a3,a3,-394 # 7000 <_entry-0x7fff9000>
    80001192:	4605                	li	a2,1
    80001194:	067e                	slli	a2,a2,0x1f
    80001196:	85b2                	mv	a1,a2
    80001198:	8526                	mv	a0,s1
    8000119a:	f7dff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000119e:	4719                	li	a4,6
    800011a0:	00006697          	auipc	a3,0x6
    800011a4:	e6068693          	addi	a3,a3,-416 # 80007000 <etext>
    800011a8:	47c5                	li	a5,17
    800011aa:	07ee                	slli	a5,a5,0x1b
    800011ac:	40d786b3          	sub	a3,a5,a3
    800011b0:	00006617          	auipc	a2,0x6
    800011b4:	e5060613          	addi	a2,a2,-432 # 80007000 <etext>
    800011b8:	85b2                	mv	a1,a2
    800011ba:	8526                	mv	a0,s1
    800011bc:	f5bff0ef          	jal	80001116 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011c0:	4729                	li	a4,10
    800011c2:	6685                	lui	a3,0x1
    800011c4:	00005617          	auipc	a2,0x5
    800011c8:	e3c60613          	addi	a2,a2,-452 # 80006000 <_trampoline>
    800011cc:	040005b7          	lui	a1,0x4000
    800011d0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011d2:	05b2                	slli	a1,a1,0xc
    800011d4:	8526                	mv	a0,s1
    800011d6:	f41ff0ef          	jal	80001116 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011da:	8526                	mv	a0,s1
    800011dc:	5c4000ef          	jal	800017a0 <proc_mapstacks>
}
    800011e0:	8526                	mv	a0,s1
    800011e2:	60e2                	ld	ra,24(sp)
    800011e4:	6442                	ld	s0,16(sp)
    800011e6:	64a2                	ld	s1,8(sp)
    800011e8:	6105                	addi	sp,sp,32
    800011ea:	8082                	ret

00000000800011ec <kvminit>:
{
    800011ec:	1141                	addi	sp,sp,-16
    800011ee:	e406                	sd	ra,8(sp)
    800011f0:	e022                	sd	s0,0(sp)
    800011f2:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011f4:	f4bff0ef          	jal	8000113e <kvmmake>
    800011f8:	00009797          	auipc	a5,0x9
    800011fc:	10a7b823          	sd	a0,272(a5) # 8000a308 <kernel_pagetable>
}
    80001200:	60a2                	ld	ra,8(sp)
    80001202:	6402                	ld	s0,0(sp)
    80001204:	0141                	addi	sp,sp,16
    80001206:	8082                	ret

0000000080001208 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001208:	1101                	addi	sp,sp,-32
    8000120a:	ec06                	sd	ra,24(sp)
    8000120c:	e822                	sd	s0,16(sp)
    8000120e:	e426                	sd	s1,8(sp)
    80001210:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001212:	933ff0ef          	jal	80000b44 <kalloc>
    80001216:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001218:	c509                	beqz	a0,80001222 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000121a:	6605                	lui	a2,0x1
    8000121c:	4581                	li	a1,0
    8000121e:	adbff0ef          	jal	80000cf8 <memset>
  return pagetable;
}
    80001222:	8526                	mv	a0,s1
    80001224:	60e2                	ld	ra,24(sp)
    80001226:	6442                	ld	s0,16(sp)
    80001228:	64a2                	ld	s1,8(sp)
    8000122a:	6105                	addi	sp,sp,32
    8000122c:	8082                	ret

000000008000122e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000122e:	7139                	addi	sp,sp,-64
    80001230:	fc06                	sd	ra,56(sp)
    80001232:	f822                	sd	s0,48(sp)
    80001234:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001236:	03459793          	slli	a5,a1,0x34
    8000123a:	e38d                	bnez	a5,8000125c <uvmunmap+0x2e>
    8000123c:	f04a                	sd	s2,32(sp)
    8000123e:	ec4e                	sd	s3,24(sp)
    80001240:	e852                	sd	s4,16(sp)
    80001242:	e456                	sd	s5,8(sp)
    80001244:	e05a                	sd	s6,0(sp)
    80001246:	8a2a                	mv	s4,a0
    80001248:	892e                	mv	s2,a1
    8000124a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000124c:	0632                	slli	a2,a2,0xc
    8000124e:	00b609b3          	add	s3,a2,a1
    80001252:	6b05                	lui	s6,0x1
    80001254:	0535f963          	bgeu	a1,s3,800012a6 <uvmunmap+0x78>
    80001258:	f426                	sd	s1,40(sp)
    8000125a:	a015                	j	8000127e <uvmunmap+0x50>
    8000125c:	f426                	sd	s1,40(sp)
    8000125e:	f04a                	sd	s2,32(sp)
    80001260:	ec4e                	sd	s3,24(sp)
    80001262:	e852                	sd	s4,16(sp)
    80001264:	e456                	sd	s5,8(sp)
    80001266:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001268:	00006517          	auipc	a0,0x6
    8000126c:	eb850513          	addi	a0,a0,-328 # 80007120 <etext+0x120>
    80001270:	db4ff0ef          	jal	80000824 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001274:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001278:	995a                	add	s2,s2,s6
    8000127a:	03397563          	bgeu	s2,s3,800012a4 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000127e:	4601                	li	a2,0
    80001280:	85ca                	mv	a1,s2
    80001282:	8552                	mv	a0,s4
    80001284:	d09ff0ef          	jal	80000f8c <walk>
    80001288:	84aa                	mv	s1,a0
    8000128a:	d57d                	beqz	a0,80001278 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    8000128c:	611c                	ld	a5,0(a0)
    8000128e:	0017f713          	andi	a4,a5,1
    80001292:	d37d                	beqz	a4,80001278 <uvmunmap+0x4a>
    if(do_free){
    80001294:	fe0a80e3          	beqz	s5,80001274 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001298:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    8000129a:	00c79513          	slli	a0,a5,0xc
    8000129e:	fbeff0ef          	jal	80000a5c <kfree>
    800012a2:	bfc9                	j	80001274 <uvmunmap+0x46>
    800012a4:	74a2                	ld	s1,40(sp)
    800012a6:	7902                	ld	s2,32(sp)
    800012a8:	69e2                	ld	s3,24(sp)
    800012aa:	6a42                	ld	s4,16(sp)
    800012ac:	6aa2                	ld	s5,8(sp)
    800012ae:	6b02                	ld	s6,0(sp)
  }
}
    800012b0:	70e2                	ld	ra,56(sp)
    800012b2:	7442                	ld	s0,48(sp)
    800012b4:	6121                	addi	sp,sp,64
    800012b6:	8082                	ret

00000000800012b8 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012b8:	1101                	addi	sp,sp,-32
    800012ba:	ec06                	sd	ra,24(sp)
    800012bc:	e822                	sd	s0,16(sp)
    800012be:	e426                	sd	s1,8(sp)
    800012c0:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800012c2:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800012c4:	00b67d63          	bgeu	a2,a1,800012de <uvmdealloc+0x26>
    800012c8:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800012ca:	6785                	lui	a5,0x1
    800012cc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012ce:	00f60733          	add	a4,a2,a5
    800012d2:	76fd                	lui	a3,0xfffff
    800012d4:	8f75                	and	a4,a4,a3
    800012d6:	97ae                	add	a5,a5,a1
    800012d8:	8ff5                	and	a5,a5,a3
    800012da:	00f76863          	bltu	a4,a5,800012ea <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012de:	8526                	mv	a0,s1
    800012e0:	60e2                	ld	ra,24(sp)
    800012e2:	6442                	ld	s0,16(sp)
    800012e4:	64a2                	ld	s1,8(sp)
    800012e6:	6105                	addi	sp,sp,32
    800012e8:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012ea:	8f99                	sub	a5,a5,a4
    800012ec:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012ee:	4685                	li	a3,1
    800012f0:	0007861b          	sext.w	a2,a5
    800012f4:	85ba                	mv	a1,a4
    800012f6:	f39ff0ef          	jal	8000122e <uvmunmap>
    800012fa:	b7d5                	j	800012de <uvmdealloc+0x26>

00000000800012fc <uvmalloc>:
  if(newsz < oldsz)
    800012fc:	0ab66163          	bltu	a2,a1,8000139e <uvmalloc+0xa2>
{
    80001300:	715d                	addi	sp,sp,-80
    80001302:	e486                	sd	ra,72(sp)
    80001304:	e0a2                	sd	s0,64(sp)
    80001306:	f84a                	sd	s2,48(sp)
    80001308:	f052                	sd	s4,32(sp)
    8000130a:	ec56                	sd	s5,24(sp)
    8000130c:	e45e                	sd	s7,8(sp)
    8000130e:	0880                	addi	s0,sp,80
    80001310:	8aaa                	mv	s5,a0
    80001312:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001314:	6785                	lui	a5,0x1
    80001316:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001318:	95be                	add	a1,a1,a5
    8000131a:	77fd                	lui	a5,0xfffff
    8000131c:	00f5f933          	and	s2,a1,a5
    80001320:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001322:	08c97063          	bgeu	s2,a2,800013a2 <uvmalloc+0xa6>
    80001326:	fc26                	sd	s1,56(sp)
    80001328:	f44e                	sd	s3,40(sp)
    8000132a:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    8000132c:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000132e:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001332:	813ff0ef          	jal	80000b44 <kalloc>
    80001336:	84aa                	mv	s1,a0
    if(mem == 0){
    80001338:	c50d                	beqz	a0,80001362 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    8000133a:	864e                	mv	a2,s3
    8000133c:	4581                	li	a1,0
    8000133e:	9bbff0ef          	jal	80000cf8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001342:	875a                	mv	a4,s6
    80001344:	86a6                	mv	a3,s1
    80001346:	864e                	mv	a2,s3
    80001348:	85ca                	mv	a1,s2
    8000134a:	8556                	mv	a0,s5
    8000134c:	d15ff0ef          	jal	80001060 <mappages>
    80001350:	e915                	bnez	a0,80001384 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001352:	994e                	add	s2,s2,s3
    80001354:	fd496fe3          	bltu	s2,s4,80001332 <uvmalloc+0x36>
  return newsz;
    80001358:	8552                	mv	a0,s4
    8000135a:	74e2                	ld	s1,56(sp)
    8000135c:	79a2                	ld	s3,40(sp)
    8000135e:	6b42                	ld	s6,16(sp)
    80001360:	a811                	j	80001374 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001362:	865e                	mv	a2,s7
    80001364:	85ca                	mv	a1,s2
    80001366:	8556                	mv	a0,s5
    80001368:	f51ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    8000136c:	4501                	li	a0,0
    8000136e:	74e2                	ld	s1,56(sp)
    80001370:	79a2                	ld	s3,40(sp)
    80001372:	6b42                	ld	s6,16(sp)
}
    80001374:	60a6                	ld	ra,72(sp)
    80001376:	6406                	ld	s0,64(sp)
    80001378:	7942                	ld	s2,48(sp)
    8000137a:	7a02                	ld	s4,32(sp)
    8000137c:	6ae2                	ld	s5,24(sp)
    8000137e:	6ba2                	ld	s7,8(sp)
    80001380:	6161                	addi	sp,sp,80
    80001382:	8082                	ret
      kfree(mem);
    80001384:	8526                	mv	a0,s1
    80001386:	ed6ff0ef          	jal	80000a5c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000138a:	865e                	mv	a2,s7
    8000138c:	85ca                	mv	a1,s2
    8000138e:	8556                	mv	a0,s5
    80001390:	f29ff0ef          	jal	800012b8 <uvmdealloc>
      return 0;
    80001394:	4501                	li	a0,0
    80001396:	74e2                	ld	s1,56(sp)
    80001398:	79a2                	ld	s3,40(sp)
    8000139a:	6b42                	ld	s6,16(sp)
    8000139c:	bfe1                	j	80001374 <uvmalloc+0x78>
    return oldsz;
    8000139e:	852e                	mv	a0,a1
}
    800013a0:	8082                	ret
  return newsz;
    800013a2:	8532                	mv	a0,a2
    800013a4:	bfc1                	j	80001374 <uvmalloc+0x78>

00000000800013a6 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013a6:	7179                	addi	sp,sp,-48
    800013a8:	f406                	sd	ra,40(sp)
    800013aa:	f022                	sd	s0,32(sp)
    800013ac:	ec26                	sd	s1,24(sp)
    800013ae:	e84a                	sd	s2,16(sp)
    800013b0:	e44e                	sd	s3,8(sp)
    800013b2:	1800                	addi	s0,sp,48
    800013b4:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013b6:	84aa                	mv	s1,a0
    800013b8:	6905                	lui	s2,0x1
    800013ba:	992a                	add	s2,s2,a0
    800013bc:	a811                	j	800013d0 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800013be:	00006517          	auipc	a0,0x6
    800013c2:	d7a50513          	addi	a0,a0,-646 # 80007138 <etext+0x138>
    800013c6:	c5eff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    800013ca:	04a1                	addi	s1,s1,8
    800013cc:	03248163          	beq	s1,s2,800013ee <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013d0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013d2:	0017f713          	andi	a4,a5,1
    800013d6:	db75                	beqz	a4,800013ca <freewalk+0x24>
    800013d8:	00e7f713          	andi	a4,a5,14
    800013dc:	f36d                	bnez	a4,800013be <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800013de:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013e0:	00c79513          	slli	a0,a5,0xc
    800013e4:	fc3ff0ef          	jal	800013a6 <freewalk>
      pagetable[i] = 0;
    800013e8:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013ec:	bff9                	j	800013ca <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800013ee:	854e                	mv	a0,s3
    800013f0:	e6cff0ef          	jal	80000a5c <kfree>
}
    800013f4:	70a2                	ld	ra,40(sp)
    800013f6:	7402                	ld	s0,32(sp)
    800013f8:	64e2                	ld	s1,24(sp)
    800013fa:	6942                	ld	s2,16(sp)
    800013fc:	69a2                	ld	s3,8(sp)
    800013fe:	6145                	addi	sp,sp,48
    80001400:	8082                	ret

0000000080001402 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001402:	1101                	addi	sp,sp,-32
    80001404:	ec06                	sd	ra,24(sp)
    80001406:	e822                	sd	s0,16(sp)
    80001408:	e426                	sd	s1,8(sp)
    8000140a:	1000                	addi	s0,sp,32
    8000140c:	84aa                	mv	s1,a0
  if(sz > 0)
    8000140e:	e989                	bnez	a1,80001420 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001410:	8526                	mv	a0,s1
    80001412:	f95ff0ef          	jal	800013a6 <freewalk>
}
    80001416:	60e2                	ld	ra,24(sp)
    80001418:	6442                	ld	s0,16(sp)
    8000141a:	64a2                	ld	s1,8(sp)
    8000141c:	6105                	addi	sp,sp,32
    8000141e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001420:	6785                	lui	a5,0x1
    80001422:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001424:	95be                	add	a1,a1,a5
    80001426:	4685                	li	a3,1
    80001428:	00c5d613          	srli	a2,a1,0xc
    8000142c:	4581                	li	a1,0
    8000142e:	e01ff0ef          	jal	8000122e <uvmunmap>
    80001432:	bff9                	j	80001410 <uvmfree+0xe>

0000000080001434 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001434:	ca59                	beqz	a2,800014ca <uvmcopy+0x96>
{
    80001436:	715d                	addi	sp,sp,-80
    80001438:	e486                	sd	ra,72(sp)
    8000143a:	e0a2                	sd	s0,64(sp)
    8000143c:	fc26                	sd	s1,56(sp)
    8000143e:	f84a                	sd	s2,48(sp)
    80001440:	f44e                	sd	s3,40(sp)
    80001442:	f052                	sd	s4,32(sp)
    80001444:	ec56                	sd	s5,24(sp)
    80001446:	e85a                	sd	s6,16(sp)
    80001448:	e45e                	sd	s7,8(sp)
    8000144a:	0880                	addi	s0,sp,80
    8000144c:	8b2a                	mv	s6,a0
    8000144e:	8bae                	mv	s7,a1
    80001450:	8ab2                	mv	s5,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001452:	4481                	li	s1,0
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001454:	6a05                	lui	s4,0x1
    80001456:	a021                	j	8000145e <uvmcopy+0x2a>
  for(i = 0; i < sz; i += PGSIZE){
    80001458:	94d2                	add	s1,s1,s4
    8000145a:	0554fc63          	bgeu	s1,s5,800014b2 <uvmcopy+0x7e>
    if((pte = walk(old, i, 0)) == 0)
    8000145e:	4601                	li	a2,0
    80001460:	85a6                	mv	a1,s1
    80001462:	855a                	mv	a0,s6
    80001464:	b29ff0ef          	jal	80000f8c <walk>
    80001468:	d965                	beqz	a0,80001458 <uvmcopy+0x24>
    if((*pte & PTE_V) == 0)
    8000146a:	00053983          	ld	s3,0(a0)
    8000146e:	0019f793          	andi	a5,s3,1
    80001472:	d3fd                	beqz	a5,80001458 <uvmcopy+0x24>
    if((mem = kalloc()) == 0)
    80001474:	ed0ff0ef          	jal	80000b44 <kalloc>
    80001478:	892a                	mv	s2,a0
    8000147a:	c11d                	beqz	a0,800014a0 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    8000147c:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80001480:	8652                	mv	a2,s4
    80001482:	05b2                	slli	a1,a1,0xc
    80001484:	8d5ff0ef          	jal	80000d58 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001488:	3ff9f713          	andi	a4,s3,1023
    8000148c:	86ca                	mv	a3,s2
    8000148e:	8652                	mv	a2,s4
    80001490:	85a6                	mv	a1,s1
    80001492:	855e                	mv	a0,s7
    80001494:	bcdff0ef          	jal	80001060 <mappages>
    80001498:	d161                	beqz	a0,80001458 <uvmcopy+0x24>
      kfree(mem);
    8000149a:	854a                	mv	a0,s2
    8000149c:	dc0ff0ef          	jal	80000a5c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014a0:	4685                	li	a3,1
    800014a2:	00c4d613          	srli	a2,s1,0xc
    800014a6:	4581                	li	a1,0
    800014a8:	855e                	mv	a0,s7
    800014aa:	d85ff0ef          	jal	8000122e <uvmunmap>
  return -1;
    800014ae:	557d                	li	a0,-1
    800014b0:	a011                	j	800014b4 <uvmcopy+0x80>
  return 0;
    800014b2:	4501                	li	a0,0
}
    800014b4:	60a6                	ld	ra,72(sp)
    800014b6:	6406                	ld	s0,64(sp)
    800014b8:	74e2                	ld	s1,56(sp)
    800014ba:	7942                	ld	s2,48(sp)
    800014bc:	79a2                	ld	s3,40(sp)
    800014be:	7a02                	ld	s4,32(sp)
    800014c0:	6ae2                	ld	s5,24(sp)
    800014c2:	6b42                	ld	s6,16(sp)
    800014c4:	6ba2                	ld	s7,8(sp)
    800014c6:	6161                	addi	sp,sp,80
    800014c8:	8082                	ret
  return 0;
    800014ca:	4501                	li	a0,0
}
    800014cc:	8082                	ret

00000000800014ce <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014ce:	1141                	addi	sp,sp,-16
    800014d0:	e406                	sd	ra,8(sp)
    800014d2:	e022                	sd	s0,0(sp)
    800014d4:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014d6:	4601                	li	a2,0
    800014d8:	ab5ff0ef          	jal	80000f8c <walk>
  if(pte == 0)
    800014dc:	c901                	beqz	a0,800014ec <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014de:	611c                	ld	a5,0(a0)
    800014e0:	9bbd                	andi	a5,a5,-17
    800014e2:	e11c                	sd	a5,0(a0)
}
    800014e4:	60a2                	ld	ra,8(sp)
    800014e6:	6402                	ld	s0,0(sp)
    800014e8:	0141                	addi	sp,sp,16
    800014ea:	8082                	ret
    panic("uvmclear");
    800014ec:	00006517          	auipc	a0,0x6
    800014f0:	c5c50513          	addi	a0,a0,-932 # 80007148 <etext+0x148>
    800014f4:	b30ff0ef          	jal	80000824 <panic>

00000000800014f8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800014f8:	cac5                	beqz	a3,800015a8 <copyinstr+0xb0>
{
    800014fa:	715d                	addi	sp,sp,-80
    800014fc:	e486                	sd	ra,72(sp)
    800014fe:	e0a2                	sd	s0,64(sp)
    80001500:	fc26                	sd	s1,56(sp)
    80001502:	f84a                	sd	s2,48(sp)
    80001504:	f44e                	sd	s3,40(sp)
    80001506:	f052                	sd	s4,32(sp)
    80001508:	ec56                	sd	s5,24(sp)
    8000150a:	e85a                	sd	s6,16(sp)
    8000150c:	e45e                	sd	s7,8(sp)
    8000150e:	0880                	addi	s0,sp,80
    80001510:	8aaa                	mv	s5,a0
    80001512:	84ae                	mv	s1,a1
    80001514:	8bb2                	mv	s7,a2
    80001516:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001518:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000151a:	6a05                	lui	s4,0x1
    8000151c:	a82d                	j	80001556 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000151e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001522:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001524:	0017c793          	xori	a5,a5,1
    80001528:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000152c:	60a6                	ld	ra,72(sp)
    8000152e:	6406                	ld	s0,64(sp)
    80001530:	74e2                	ld	s1,56(sp)
    80001532:	7942                	ld	s2,48(sp)
    80001534:	79a2                	ld	s3,40(sp)
    80001536:	7a02                	ld	s4,32(sp)
    80001538:	6ae2                	ld	s5,24(sp)
    8000153a:	6b42                	ld	s6,16(sp)
    8000153c:	6ba2                	ld	s7,8(sp)
    8000153e:	6161                	addi	sp,sp,80
    80001540:	8082                	ret
    80001542:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001546:	9726                	add	a4,a4,s1
      --max;
    80001548:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000154c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001550:	04e58463          	beq	a1,a4,80001598 <copyinstr+0xa0>
{
    80001554:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001556:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000155a:	85ca                	mv	a1,s2
    8000155c:	8556                	mv	a0,s5
    8000155e:	ac9ff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0)
    80001562:	cd0d                	beqz	a0,8000159c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001564:	417906b3          	sub	a3,s2,s7
    80001568:	96d2                	add	a3,a3,s4
    if(n > max)
    8000156a:	00d9f363          	bgeu	s3,a3,80001570 <copyinstr+0x78>
    8000156e:	86ce                	mv	a3,s3
    while(n > 0){
    80001570:	ca85                	beqz	a3,800015a0 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001572:	01750633          	add	a2,a0,s7
    80001576:	41260633          	sub	a2,a2,s2
    8000157a:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000157c:	8e05                	sub	a2,a2,s1
    while(n > 0){
    8000157e:	96a6                	add	a3,a3,s1
    80001580:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001582:	00f60733          	add	a4,a2,a5
    80001586:	00074703          	lbu	a4,0(a4)
    8000158a:	db51                	beqz	a4,8000151e <copyinstr+0x26>
        *dst = *p;
    8000158c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001590:	0785                	addi	a5,a5,1
    while(n > 0){
    80001592:	fed797e3          	bne	a5,a3,80001580 <copyinstr+0x88>
    80001596:	b775                	j	80001542 <copyinstr+0x4a>
    80001598:	4781                	li	a5,0
    8000159a:	b769                	j	80001524 <copyinstr+0x2c>
      return -1;
    8000159c:	557d                	li	a0,-1
    8000159e:	b779                	j	8000152c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    800015a0:	6b85                	lui	s7,0x1
    800015a2:	9bca                	add	s7,s7,s2
    800015a4:	87a6                	mv	a5,s1
    800015a6:	b77d                	j	80001554 <copyinstr+0x5c>
  int got_null = 0;
    800015a8:	4781                	li	a5,0
  if(got_null){
    800015aa:	0017c793          	xori	a5,a5,1
    800015ae:	40f0053b          	negw	a0,a5
}
    800015b2:	8082                	ret

00000000800015b4 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800015b4:	1141                	addi	sp,sp,-16
    800015b6:	e406                	sd	ra,8(sp)
    800015b8:	e022                	sd	s0,0(sp)
    800015ba:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800015bc:	4601                	li	a2,0
    800015be:	9cfff0ef          	jal	80000f8c <walk>
  if (pte == 0) {
    800015c2:	c119                	beqz	a0,800015c8 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V){
    800015c4:	6108                	ld	a0,0(a0)
    800015c6:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800015c8:	60a2                	ld	ra,8(sp)
    800015ca:	6402                	ld	s0,0(sp)
    800015cc:	0141                	addi	sp,sp,16
    800015ce:	8082                	ret

00000000800015d0 <vmfault>:
{
    800015d0:	7179                	addi	sp,sp,-48
    800015d2:	f406                	sd	ra,40(sp)
    800015d4:	f022                	sd	s0,32(sp)
    800015d6:	e84a                	sd	s2,16(sp)
    800015d8:	e44e                	sd	s3,8(sp)
    800015da:	1800                	addi	s0,sp,48
    800015dc:	89aa                	mv	s3,a0
    800015de:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800015e0:	428000ef          	jal	80001a08 <myproc>
  if (va >= p->sz)
    800015e4:	653c                	ld	a5,72(a0)
    800015e6:	00f96a63          	bltu	s2,a5,800015fa <vmfault+0x2a>
    return 0;
    800015ea:	4981                	li	s3,0
}
    800015ec:	854e                	mv	a0,s3
    800015ee:	70a2                	ld	ra,40(sp)
    800015f0:	7402                	ld	s0,32(sp)
    800015f2:	6942                	ld	s2,16(sp)
    800015f4:	69a2                	ld	s3,8(sp)
    800015f6:	6145                	addi	sp,sp,48
    800015f8:	8082                	ret
    800015fa:	ec26                	sd	s1,24(sp)
    800015fc:	e052                	sd	s4,0(sp)
    800015fe:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    80001600:	77fd                	lui	a5,0xfffff
    80001602:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    80001606:	85d2                	mv	a1,s4
    80001608:	854e                	mv	a0,s3
    8000160a:	fabff0ef          	jal	800015b4 <ismapped>
    return 0;
    8000160e:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001610:	c501                	beqz	a0,80001618 <vmfault+0x48>
    80001612:	64e2                	ld	s1,24(sp)
    80001614:	6a02                	ld	s4,0(sp)
    80001616:	bfd9                	j	800015ec <vmfault+0x1c>
  mem = (uint64) kalloc();
    80001618:	d2cff0ef          	jal	80000b44 <kalloc>
    8000161c:	892a                	mv	s2,a0
  if(mem == 0)
    8000161e:	c905                	beqz	a0,8000164e <vmfault+0x7e>
  mem = (uint64) kalloc();
    80001620:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    80001622:	6605                	lui	a2,0x1
    80001624:	4581                	li	a1,0
    80001626:	ed2ff0ef          	jal	80000cf8 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    8000162a:	4759                	li	a4,22
    8000162c:	86ca                	mv	a3,s2
    8000162e:	6605                	lui	a2,0x1
    80001630:	85d2                	mv	a1,s4
    80001632:	68a8                	ld	a0,80(s1)
    80001634:	a2dff0ef          	jal	80001060 <mappages>
    80001638:	e501                	bnez	a0,80001640 <vmfault+0x70>
    8000163a:	64e2                	ld	s1,24(sp)
    8000163c:	6a02                	ld	s4,0(sp)
    8000163e:	b77d                	j	800015ec <vmfault+0x1c>
    kfree((void *)mem);
    80001640:	854a                	mv	a0,s2
    80001642:	c1aff0ef          	jal	80000a5c <kfree>
    return 0;
    80001646:	4981                	li	s3,0
    80001648:	64e2                	ld	s1,24(sp)
    8000164a:	6a02                	ld	s4,0(sp)
    8000164c:	b745                	j	800015ec <vmfault+0x1c>
    8000164e:	64e2                	ld	s1,24(sp)
    80001650:	6a02                	ld	s4,0(sp)
    80001652:	bf69                	j	800015ec <vmfault+0x1c>

0000000080001654 <copyout>:
  while(len > 0){
    80001654:	cad1                	beqz	a3,800016e8 <copyout+0x94>
{
    80001656:	711d                	addi	sp,sp,-96
    80001658:	ec86                	sd	ra,88(sp)
    8000165a:	e8a2                	sd	s0,80(sp)
    8000165c:	e4a6                	sd	s1,72(sp)
    8000165e:	e0ca                	sd	s2,64(sp)
    80001660:	fc4e                	sd	s3,56(sp)
    80001662:	f852                	sd	s4,48(sp)
    80001664:	f456                	sd	s5,40(sp)
    80001666:	f05a                	sd	s6,32(sp)
    80001668:	ec5e                	sd	s7,24(sp)
    8000166a:	e862                	sd	s8,16(sp)
    8000166c:	e466                	sd	s9,8(sp)
    8000166e:	e06a                	sd	s10,0(sp)
    80001670:	1080                	addi	s0,sp,96
    80001672:	8baa                	mv	s7,a0
    80001674:	8a2e                	mv	s4,a1
    80001676:	8b32                	mv	s6,a2
    80001678:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    8000167a:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    8000167c:	5cfd                	li	s9,-1
    8000167e:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001682:	6c05                	lui	s8,0x1
    80001684:	a005                	j	800016a4 <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001686:	409a0533          	sub	a0,s4,s1
    8000168a:	0009061b          	sext.w	a2,s2
    8000168e:	85da                	mv	a1,s6
    80001690:	954e                	add	a0,a0,s3
    80001692:	ec6ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001696:	412a8ab3          	sub	s5,s5,s2
    src += n;
    8000169a:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000169c:	01848a33          	add	s4,s1,s8
  while(len > 0){
    800016a0:	040a8263          	beqz	s5,800016e4 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    800016a4:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    800016a8:	049ce263          	bltu	s9,s1,800016ec <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    800016ac:	85a6                	mv	a1,s1
    800016ae:	855e                	mv	a0,s7
    800016b0:	977ff0ef          	jal	80001026 <walkaddr>
    800016b4:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    800016b6:	e901                	bnez	a0,800016c6 <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016b8:	4601                	li	a2,0
    800016ba:	85a6                	mv	a1,s1
    800016bc:	855e                	mv	a0,s7
    800016be:	f13ff0ef          	jal	800015d0 <vmfault>
    800016c2:	89aa                	mv	s3,a0
    800016c4:	c139                	beqz	a0,8000170a <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    800016c6:	4601                	li	a2,0
    800016c8:	85a6                	mv	a1,s1
    800016ca:	855e                	mv	a0,s7
    800016cc:	8c1ff0ef          	jal	80000f8c <walk>
    if((*pte & PTE_W) == 0)
    800016d0:	611c                	ld	a5,0(a0)
    800016d2:	8b91                	andi	a5,a5,4
    800016d4:	cf8d                	beqz	a5,8000170e <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    800016d6:	41448933          	sub	s2,s1,s4
    800016da:	9962                	add	s2,s2,s8
    if(n > len)
    800016dc:	fb2af5e3          	bgeu	s5,s2,80001686 <copyout+0x32>
    800016e0:	8956                	mv	s2,s5
    800016e2:	b755                	j	80001686 <copyout+0x32>
  return 0;
    800016e4:	4501                	li	a0,0
    800016e6:	a021                	j	800016ee <copyout+0x9a>
    800016e8:	4501                	li	a0,0
}
    800016ea:	8082                	ret
      return -1;
    800016ec:	557d                	li	a0,-1
}
    800016ee:	60e6                	ld	ra,88(sp)
    800016f0:	6446                	ld	s0,80(sp)
    800016f2:	64a6                	ld	s1,72(sp)
    800016f4:	6906                	ld	s2,64(sp)
    800016f6:	79e2                	ld	s3,56(sp)
    800016f8:	7a42                	ld	s4,48(sp)
    800016fa:	7aa2                	ld	s5,40(sp)
    800016fc:	7b02                	ld	s6,32(sp)
    800016fe:	6be2                	ld	s7,24(sp)
    80001700:	6c42                	ld	s8,16(sp)
    80001702:	6ca2                	ld	s9,8(sp)
    80001704:	6d02                	ld	s10,0(sp)
    80001706:	6125                	addi	sp,sp,96
    80001708:	8082                	ret
        return -1;
    8000170a:	557d                	li	a0,-1
    8000170c:	b7cd                	j	800016ee <copyout+0x9a>
      return -1;
    8000170e:	557d                	li	a0,-1
    80001710:	bff9                	j	800016ee <copyout+0x9a>

0000000080001712 <copyin>:
  while(len > 0){
    80001712:	c6c9                	beqz	a3,8000179c <copyin+0x8a>
{
    80001714:	715d                	addi	sp,sp,-80
    80001716:	e486                	sd	ra,72(sp)
    80001718:	e0a2                	sd	s0,64(sp)
    8000171a:	fc26                	sd	s1,56(sp)
    8000171c:	f84a                	sd	s2,48(sp)
    8000171e:	f44e                	sd	s3,40(sp)
    80001720:	f052                	sd	s4,32(sp)
    80001722:	ec56                	sd	s5,24(sp)
    80001724:	e85a                	sd	s6,16(sp)
    80001726:	e45e                	sd	s7,8(sp)
    80001728:	e062                	sd	s8,0(sp)
    8000172a:	0880                	addi	s0,sp,80
    8000172c:	8baa                	mv	s7,a0
    8000172e:	8aae                	mv	s5,a1
    80001730:	8932                	mv	s2,a2
    80001732:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001734:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001736:	6b05                	lui	s6,0x1
    80001738:	a035                	j	80001764 <copyin+0x52>
    8000173a:	412984b3          	sub	s1,s3,s2
    8000173e:	94da                	add	s1,s1,s6
    if(n > len)
    80001740:	009a7363          	bgeu	s4,s1,80001746 <copyin+0x34>
    80001744:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001746:	413905b3          	sub	a1,s2,s3
    8000174a:	0004861b          	sext.w	a2,s1
    8000174e:	95aa                	add	a1,a1,a0
    80001750:	8556                	mv	a0,s5
    80001752:	e06ff0ef          	jal	80000d58 <memmove>
    len -= n;
    80001756:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000175a:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000175c:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001760:	020a0163          	beqz	s4,80001782 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001764:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001768:	85ce                	mv	a1,s3
    8000176a:	855e                	mv	a0,s7
    8000176c:	8bbff0ef          	jal	80001026 <walkaddr>
    if(pa0 == 0) {
    80001770:	f569                	bnez	a0,8000173a <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001772:	4601                	li	a2,0
    80001774:	85ce                	mv	a1,s3
    80001776:	855e                	mv	a0,s7
    80001778:	e59ff0ef          	jal	800015d0 <vmfault>
    8000177c:	fd5d                	bnez	a0,8000173a <copyin+0x28>
        return -1;
    8000177e:	557d                	li	a0,-1
    80001780:	a011                	j	80001784 <copyin+0x72>
  return 0;
    80001782:	4501                	li	a0,0
}
    80001784:	60a6                	ld	ra,72(sp)
    80001786:	6406                	ld	s0,64(sp)
    80001788:	74e2                	ld	s1,56(sp)
    8000178a:	7942                	ld	s2,48(sp)
    8000178c:	79a2                	ld	s3,40(sp)
    8000178e:	7a02                	ld	s4,32(sp)
    80001790:	6ae2                	ld	s5,24(sp)
    80001792:	6b42                	ld	s6,16(sp)
    80001794:	6ba2                	ld	s7,8(sp)
    80001796:	6c02                	ld	s8,0(sp)
    80001798:	6161                	addi	sp,sp,80
    8000179a:	8082                	ret
  return 0;
    8000179c:	4501                	li	a0,0
}
    8000179e:	8082                	ret

00000000800017a0 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017a0:	715d                	addi	sp,sp,-80
    800017a2:	e486                	sd	ra,72(sp)
    800017a4:	e0a2                	sd	s0,64(sp)
    800017a6:	fc26                	sd	s1,56(sp)
    800017a8:	f84a                	sd	s2,48(sp)
    800017aa:	f44e                	sd	s3,40(sp)
    800017ac:	f052                	sd	s4,32(sp)
    800017ae:	ec56                	sd	s5,24(sp)
    800017b0:	e85a                	sd	s6,16(sp)
    800017b2:	e45e                	sd	s7,8(sp)
    800017b4:	e062                	sd	s8,0(sp)
    800017b6:	0880                	addi	s0,sp,80
    800017b8:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ba:	00011497          	auipc	s1,0x11
    800017be:	09e48493          	addi	s1,s1,158 # 80012858 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017c2:	8c26                	mv	s8,s1
    800017c4:	000a57b7          	lui	a5,0xa5
    800017c8:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017cc:	07b2                	slli	a5,a5,0xc
    800017ce:	fa578793          	addi	a5,a5,-91
    800017d2:	4fa50937          	lui	s2,0x4fa50
    800017d6:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017da:	1902                	slli	s2,s2,0x20
    800017dc:	993e                	add	s2,s2,a5
    800017de:	040009b7          	lui	s3,0x4000
    800017e2:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017e4:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e6:	4b99                	li	s7,6
    800017e8:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ea:	00017a97          	auipc	s5,0x17
    800017ee:	a6ea8a93          	addi	s5,s5,-1426 # 80018258 <tickslock>
    char *pa = kalloc();
    800017f2:	b52ff0ef          	jal	80000b44 <kalloc>
    800017f6:	862a                	mv	a2,a0
    if(pa == 0)
    800017f8:	c121                	beqz	a0,80001838 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    800017fa:	418485b3          	sub	a1,s1,s8
    800017fe:	858d                	srai	a1,a1,0x3
    80001800:	032585b3          	mul	a1,a1,s2
    80001804:	05b6                	slli	a1,a1,0xd
    80001806:	6789                	lui	a5,0x2
    80001808:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000180a:	875e                	mv	a4,s7
    8000180c:	86da                	mv	a3,s6
    8000180e:	40b985b3          	sub	a1,s3,a1
    80001812:	8552                	mv	a0,s4
    80001814:	903ff0ef          	jal	80001116 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001818:	16848493          	addi	s1,s1,360
    8000181c:	fd549be3          	bne	s1,s5,800017f2 <proc_mapstacks+0x52>
  }
}
    80001820:	60a6                	ld	ra,72(sp)
    80001822:	6406                	ld	s0,64(sp)
    80001824:	74e2                	ld	s1,56(sp)
    80001826:	7942                	ld	s2,48(sp)
    80001828:	79a2                	ld	s3,40(sp)
    8000182a:	7a02                	ld	s4,32(sp)
    8000182c:	6ae2                	ld	s5,24(sp)
    8000182e:	6b42                	ld	s6,16(sp)
    80001830:	6ba2                	ld	s7,8(sp)
    80001832:	6c02                	ld	s8,0(sp)
    80001834:	6161                	addi	sp,sp,80
    80001836:	8082                	ret
      panic("kalloc");
    80001838:	00006517          	auipc	a0,0x6
    8000183c:	92050513          	addi	a0,a0,-1760 # 80007158 <etext+0x158>
    80001840:	fe5fe0ef          	jal	80000824 <panic>

0000000080001844 <sys_startLogging>:

uint64 sys_startLogging(void) {       //StartLogging system call function that first sets the logging variable to 1 and then prints out "Logging Started" before returning 0.
    80001844:	1141                	addi	sp,sp,-16
    80001846:	e406                	sd	ra,8(sp)
    80001848:	e022                	sd	s0,0(sp)
    8000184a:	0800                	addi	s0,sp,16
  logging = 1 ;
    8000184c:	4785                	li	a5,1
    8000184e:	00009717          	auipc	a4,0x9
    80001852:	acf72123          	sw	a5,-1342(a4) # 8000a310 <logging>
  printf("Logging Started\n");
    80001856:	00006517          	auipc	a0,0x6
    8000185a:	90a50513          	addi	a0,a0,-1782 # 80007160 <etext+0x160>
    8000185e:	c9dfe0ef          	jal	800004fa <printf>
  return 0;
}
    80001862:	4501                	li	a0,0
    80001864:	60a2                	ld	ra,8(sp)
    80001866:	6402                	ld	s0,0(sp)
    80001868:	0141                	addi	sp,sp,16
    8000186a:	8082                	ret

000000008000186c <sys_stopLogging>:

uint64 sys_stopLogging(void) {        //StopLogging system call function that sets the logging variable to 0 and then prints out "Logging Stopped" before returning 0.
    8000186c:	1141                	addi	sp,sp,-16
    8000186e:	e406                	sd	ra,8(sp)
    80001870:	e022                	sd	s0,0(sp)
    80001872:	0800                	addi	s0,sp,16
  logging = 0 ;
    80001874:	00009797          	auipc	a5,0x9
    80001878:	a807ae23          	sw	zero,-1380(a5) # 8000a310 <logging>
  printf("Logging Stopped\n");
    8000187c:	00006517          	auipc	a0,0x6
    80001880:	8fc50513          	addi	a0,a0,-1796 # 80007178 <etext+0x178>
    80001884:	c77fe0ef          	jal	800004fa <printf>
  return 0;
}
    80001888:	4501                	li	a0,0
    8000188a:	60a2                	ld	ra,8(sp)
    8000188c:	6402                	ld	s0,0(sp)
    8000188e:	0141                	addi	sp,sp,16
    80001890:	8082                	ret

0000000080001892 <sys_nice>:

uint64 sys_nice(void)                 //Nice system call function that declares process id and increment amount
{
    80001892:	7179                	addi	sp,sp,-48
    80001894:	f406                	sd	ra,40(sp)
    80001896:	f022                	sd	s0,32(sp)
    80001898:	ec26                	sd	s1,24(sp)
    8000189a:	1800                	addi	s0,sp,48
  int pid; //process id
  int inc; //amount to increment nice by
  argint(0, &pid);  // pull nth integer argument off stack and into kernel variable for both arguments.
    8000189c:	fdc40593          	addi	a1,s0,-36
    800018a0:	4501                	li	a0,0
    800018a2:	0b0010ef          	jal	80002952 <argint>
  argint(1, &inc);
    800018a6:	fd840593          	addi	a1,s0,-40
    800018aa:	4505                	li	a0,1
    800018ac:	0a6010ef          	jal	80002952 <argint>

  struct proc *p;
  for (p = proc; p < &proc[NPROC]; p++)   //Iterate over the process table to find the process control block whose pid matches.
  {
    if (p->pid == pid && p->state != UNUSED)    //pid is correct and the slot is active.
    800018b0:	fdc42783          	lw	a5,-36(s0)
  for (p = proc; p < &proc[NPROC]; p++)   //Iterate over the process table to find the process control block whose pid matches.
    800018b4:	00011497          	auipc	s1,0x11
    800018b8:	fa448493          	addi	s1,s1,-92 # 80012858 <proc>
    800018bc:	00017717          	auipc	a4,0x17
    800018c0:	99c70713          	addi	a4,a4,-1636 # 80018258 <tickslock>
    800018c4:	a821                	j	800018dc <sys_nice+0x4a>
        p->nice = -20 ;
      }

      if(logging)     //If logging is enabled, then print the update messafe for the nice value for the pid process
      {
        printf("nice set to %d for %d\n", p->nice, p->pid);
    800018c6:	00006517          	auipc	a0,0x6
    800018ca:	8ca50513          	addi	a0,a0,-1846 # 80007190 <etext+0x190>
    800018ce:	c2dfe0ef          	jal	800004fa <printf>
    800018d2:	a835                	j	8000190e <sys_nice+0x7c>
  for (p = proc; p < &proc[NPROC]; p++)   //Iterate over the process table to find the process control block whose pid matches.
    800018d4:	16848493          	addi	s1,s1,360
    800018d8:	04e48163          	beq	s1,a4,8000191a <sys_nice+0x88>
    if (p->pid == pid && p->state != UNUSED)    //pid is correct and the slot is active.
    800018dc:	5890                	lw	a2,48(s1)
    800018de:	fef61be3          	bne	a2,a5,800018d4 <sys_nice+0x42>
    800018e2:	4c94                	lw	a3,24(s1)
    800018e4:	dae5                	beqz	a3,800018d4 <sys_nice+0x42>
      p->nice += inc;   // Update the process's nice value and bound it to the -20, 19 range
    800018e6:	58d8                	lw	a4,52(s1)
    800018e8:	fd842783          	lw	a5,-40(s0)
    800018ec:	9fb9                	addw	a5,a5,a4
      if (p->nice > 19) {
    800018ee:	474d                	li	a4,19
        p->nice = -20 ;
    800018f0:	55b1                	li	a1,-20
      if (p->nice > 19) {
    800018f2:	00f74863          	blt	a4,a5,80001902 <sys_nice+0x70>
      if (p->nice > -20) {
    800018f6:	85be                	mv	a1,a5
    800018f8:	5731                	li	a4,-20
    800018fa:	00f75363          	bge	a4,a5,80001900 <sys_nice+0x6e>
    800018fe:	55b1                	li	a1,-20
    80001900:	2581                	sext.w	a1,a1
    80001902:	d8cc                	sw	a1,52(s1)
      if(logging)     //If logging is enabled, then print the update messafe for the nice value for the pid process
    80001904:	00009797          	auipc	a5,0x9
    80001908:	a0c7a783          	lw	a5,-1524(a5) # 8000a310 <logging>
    8000190c:	ffcd                	bnez	a5,800018c6 <sys_nice+0x34>
      }

      return p->nice; //Return the process's nice value on success
    8000190e:	58c8                	lw	a0,52(s1)
    }
  }

  return -1;          // Return -1 on failure
}
    80001910:	70a2                	ld	ra,40(sp)
    80001912:	7402                	ld	s0,32(sp)
    80001914:	64e2                	ld	s1,24(sp)
    80001916:	6145                	addi	sp,sp,48
    80001918:	8082                	ret
  return -1;          // Return -1 on failure
    8000191a:	557d                	li	a0,-1
    8000191c:	bfd5                	j	80001910 <sys_nice+0x7e>

000000008000191e <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000191e:	7139                	addi	sp,sp,-64
    80001920:	fc06                	sd	ra,56(sp)
    80001922:	f822                	sd	s0,48(sp)
    80001924:	f426                	sd	s1,40(sp)
    80001926:	f04a                	sd	s2,32(sp)
    80001928:	ec4e                	sd	s3,24(sp)
    8000192a:	e852                	sd	s4,16(sp)
    8000192c:	e456                	sd	s5,8(sp)
    8000192e:	e05a                	sd	s6,0(sp)
    80001930:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001932:	00006597          	auipc	a1,0x6
    80001936:	87658593          	addi	a1,a1,-1930 # 800071a8 <etext+0x1a8>
    8000193a:	00011517          	auipc	a0,0x11
    8000193e:	aee50513          	addi	a0,a0,-1298 # 80012428 <pid_lock>
    80001942:	a5cff0ef          	jal	80000b9e <initlock>
  initlock(&wait_lock, "wait_lock");
    80001946:	00006597          	auipc	a1,0x6
    8000194a:	86a58593          	addi	a1,a1,-1942 # 800071b0 <etext+0x1b0>
    8000194e:	00011517          	auipc	a0,0x11
    80001952:	af250513          	addi	a0,a0,-1294 # 80012440 <wait_lock>
    80001956:	a48ff0ef          	jal	80000b9e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000195a:	00011497          	auipc	s1,0x11
    8000195e:	efe48493          	addi	s1,s1,-258 # 80012858 <proc>
      initlock(&p->lock, "proc");
    80001962:	00006b17          	auipc	s6,0x6
    80001966:	85eb0b13          	addi	s6,s6,-1954 # 800071c0 <etext+0x1c0>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000196a:	8aa6                	mv	s5,s1
    8000196c:	000a57b7          	lui	a5,0xa5
    80001970:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80001974:	07b2                	slli	a5,a5,0xc
    80001976:	fa578793          	addi	a5,a5,-91
    8000197a:	4fa50937          	lui	s2,0x4fa50
    8000197e:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80001982:	1902                	slli	s2,s2,0x20
    80001984:	993e                	add	s2,s2,a5
    80001986:	040009b7          	lui	s3,0x4000
    8000198a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000198c:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000198e:	00017a17          	auipc	s4,0x17
    80001992:	8caa0a13          	addi	s4,s4,-1846 # 80018258 <tickslock>
      initlock(&p->lock, "proc");
    80001996:	85da                	mv	a1,s6
    80001998:	8526                	mv	a0,s1
    8000199a:	a04ff0ef          	jal	80000b9e <initlock>
      p->state = UNUSED;
    8000199e:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800019a2:	415487b3          	sub	a5,s1,s5
    800019a6:	878d                	srai	a5,a5,0x3
    800019a8:	032787b3          	mul	a5,a5,s2
    800019ac:	07b6                	slli	a5,a5,0xd
    800019ae:	6709                	lui	a4,0x2
    800019b0:	9fb9                	addw	a5,a5,a4
    800019b2:	40f987b3          	sub	a5,s3,a5
    800019b6:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800019b8:	16848493          	addi	s1,s1,360
    800019bc:	fd449de3          	bne	s1,s4,80001996 <procinit+0x78>
  }
}
    800019c0:	70e2                	ld	ra,56(sp)
    800019c2:	7442                	ld	s0,48(sp)
    800019c4:	74a2                	ld	s1,40(sp)
    800019c6:	7902                	ld	s2,32(sp)
    800019c8:	69e2                	ld	s3,24(sp)
    800019ca:	6a42                	ld	s4,16(sp)
    800019cc:	6aa2                	ld	s5,8(sp)
    800019ce:	6b02                	ld	s6,0(sp)
    800019d0:	6121                	addi	sp,sp,64
    800019d2:	8082                	ret

00000000800019d4 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800019d4:	1141                	addi	sp,sp,-16
    800019d6:	e406                	sd	ra,8(sp)
    800019d8:	e022                	sd	s0,0(sp)
    800019da:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800019dc:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800019de:	2501                	sext.w	a0,a0
    800019e0:	60a2                	ld	ra,8(sp)
    800019e2:	6402                	ld	s0,0(sp)
    800019e4:	0141                	addi	sp,sp,16
    800019e6:	8082                	ret

00000000800019e8 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800019e8:	1141                	addi	sp,sp,-16
    800019ea:	e406                	sd	ra,8(sp)
    800019ec:	e022                	sd	s0,0(sp)
    800019ee:	0800                	addi	s0,sp,16
    800019f0:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800019f2:	2781                	sext.w	a5,a5
    800019f4:	079e                	slli	a5,a5,0x7
  return c;
}
    800019f6:	00011517          	auipc	a0,0x11
    800019fa:	a6250513          	addi	a0,a0,-1438 # 80012458 <cpus>
    800019fe:	953e                	add	a0,a0,a5
    80001a00:	60a2                	ld	ra,8(sp)
    80001a02:	6402                	ld	s0,0(sp)
    80001a04:	0141                	addi	sp,sp,16
    80001a06:	8082                	ret

0000000080001a08 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001a08:	1101                	addi	sp,sp,-32
    80001a0a:	ec06                	sd	ra,24(sp)
    80001a0c:	e822                	sd	s0,16(sp)
    80001a0e:	e426                	sd	s1,8(sp)
    80001a10:	1000                	addi	s0,sp,32
  push_off();
    80001a12:	9d2ff0ef          	jal	80000be4 <push_off>
    80001a16:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001a18:	2781                	sext.w	a5,a5
    80001a1a:	079e                	slli	a5,a5,0x7
    80001a1c:	00011717          	auipc	a4,0x11
    80001a20:	a0c70713          	addi	a4,a4,-1524 # 80012428 <pid_lock>
    80001a24:	97ba                	add	a5,a5,a4
    80001a26:	7b9c                	ld	a5,48(a5)
    80001a28:	84be                	mv	s1,a5
  pop_off();
    80001a2a:	a42ff0ef          	jal	80000c6c <pop_off>
  return p;
}
    80001a2e:	8526                	mv	a0,s1
    80001a30:	60e2                	ld	ra,24(sp)
    80001a32:	6442                	ld	s0,16(sp)
    80001a34:	64a2                	ld	s1,8(sp)
    80001a36:	6105                	addi	sp,sp,32
    80001a38:	8082                	ret

0000000080001a3a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001a3a:	7179                	addi	sp,sp,-48
    80001a3c:	f406                	sd	ra,40(sp)
    80001a3e:	f022                	sd	s0,32(sp)
    80001a40:	ec26                	sd	s1,24(sp)
    80001a42:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001a44:	fc5ff0ef          	jal	80001a08 <myproc>
    80001a48:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001a4a:	a72ff0ef          	jal	80000cbc <release>

  if (first) {
    80001a4e:	00009797          	auipc	a5,0x9
    80001a52:	8927a783          	lw	a5,-1902(a5) # 8000a2e0 <first.1>
    80001a56:	cf95                	beqz	a5,80001a92 <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001a58:	4505                	li	a0,1
    80001a5a:	3b7010ef          	jal	80003610 <fsinit>

    first = 0;
    80001a5e:	00009797          	auipc	a5,0x9
    80001a62:	8807a123          	sw	zero,-1918(a5) # 8000a2e0 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    80001a66:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001a6a:	00005797          	auipc	a5,0x5
    80001a6e:	75e78793          	addi	a5,a5,1886 # 800071c8 <etext+0x1c8>
    80001a72:	fcf43823          	sd	a5,-48(s0)
    80001a76:	fc043c23          	sd	zero,-40(s0)
    80001a7a:	fd040593          	addi	a1,s0,-48
    80001a7e:	853e                	mv	a0,a5
    80001a80:	519020ef          	jal	80004798 <kexec>
    80001a84:	6cbc                	ld	a5,88(s1)
    80001a86:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001a88:	6cbc                	ld	a5,88(s1)
    80001a8a:	7bb8                	ld	a4,112(a5)
    80001a8c:	57fd                	li	a5,-1
    80001a8e:	02f70d63          	beq	a4,a5,80001ac8 <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001a92:	2f1000ef          	jal	80002582 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a96:	68a8                	ld	a0,80(s1)
    80001a98:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a9a:	04000737          	lui	a4,0x4000
    80001a9e:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001aa0:	0732                	slli	a4,a4,0xc
    80001aa2:	00004797          	auipc	a5,0x4
    80001aa6:	5fa78793          	addi	a5,a5,1530 # 8000609c <userret>
    80001aaa:	00004697          	auipc	a3,0x4
    80001aae:	55668693          	addi	a3,a3,1366 # 80006000 <_trampoline>
    80001ab2:	8f95                	sub	a5,a5,a3
    80001ab4:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001ab6:	577d                	li	a4,-1
    80001ab8:	177e                	slli	a4,a4,0x3f
    80001aba:	8d59                	or	a0,a0,a4
    80001abc:	9782                	jalr	a5
}
    80001abe:	70a2                	ld	ra,40(sp)
    80001ac0:	7402                	ld	s0,32(sp)
    80001ac2:	64e2                	ld	s1,24(sp)
    80001ac4:	6145                	addi	sp,sp,48
    80001ac6:	8082                	ret
      panic("exec");
    80001ac8:	00005517          	auipc	a0,0x5
    80001acc:	70850513          	addi	a0,a0,1800 # 800071d0 <etext+0x1d0>
    80001ad0:	d55fe0ef          	jal	80000824 <panic>

0000000080001ad4 <allocpid>:
{
    80001ad4:	1101                	addi	sp,sp,-32
    80001ad6:	ec06                	sd	ra,24(sp)
    80001ad8:	e822                	sd	s0,16(sp)
    80001ada:	e426                	sd	s1,8(sp)
    80001adc:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001ade:	00011517          	auipc	a0,0x11
    80001ae2:	94a50513          	addi	a0,a0,-1718 # 80012428 <pid_lock>
    80001ae6:	942ff0ef          	jal	80000c28 <acquire>
  pid = nextpid;
    80001aea:	00008797          	auipc	a5,0x8
    80001aee:	7fa78793          	addi	a5,a5,2042 # 8000a2e4 <nextpid>
    80001af2:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001af4:	0014871b          	addiw	a4,s1,1
    80001af8:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001afa:	00011517          	auipc	a0,0x11
    80001afe:	92e50513          	addi	a0,a0,-1746 # 80012428 <pid_lock>
    80001b02:	9baff0ef          	jal	80000cbc <release>
}
    80001b06:	8526                	mv	a0,s1
    80001b08:	60e2                	ld	ra,24(sp)
    80001b0a:	6442                	ld	s0,16(sp)
    80001b0c:	64a2                	ld	s1,8(sp)
    80001b0e:	6105                	addi	sp,sp,32
    80001b10:	8082                	ret

0000000080001b12 <proc_pagetable>:
{
    80001b12:	1101                	addi	sp,sp,-32
    80001b14:	ec06                	sd	ra,24(sp)
    80001b16:	e822                	sd	s0,16(sp)
    80001b18:	e426                	sd	s1,8(sp)
    80001b1a:	e04a                	sd	s2,0(sp)
    80001b1c:	1000                	addi	s0,sp,32
    80001b1e:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001b20:	ee8ff0ef          	jal	80001208 <uvmcreate>
    80001b24:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001b26:	cd05                	beqz	a0,80001b5e <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001b28:	4729                	li	a4,10
    80001b2a:	00004697          	auipc	a3,0x4
    80001b2e:	4d668693          	addi	a3,a3,1238 # 80006000 <_trampoline>
    80001b32:	6605                	lui	a2,0x1
    80001b34:	040005b7          	lui	a1,0x4000
    80001b38:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b3a:	05b2                	slli	a1,a1,0xc
    80001b3c:	d24ff0ef          	jal	80001060 <mappages>
    80001b40:	02054663          	bltz	a0,80001b6c <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001b44:	4719                	li	a4,6
    80001b46:	05893683          	ld	a3,88(s2)
    80001b4a:	6605                	lui	a2,0x1
    80001b4c:	020005b7          	lui	a1,0x2000
    80001b50:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b52:	05b6                	slli	a1,a1,0xd
    80001b54:	8526                	mv	a0,s1
    80001b56:	d0aff0ef          	jal	80001060 <mappages>
    80001b5a:	00054f63          	bltz	a0,80001b78 <proc_pagetable+0x66>
}
    80001b5e:	8526                	mv	a0,s1
    80001b60:	60e2                	ld	ra,24(sp)
    80001b62:	6442                	ld	s0,16(sp)
    80001b64:	64a2                	ld	s1,8(sp)
    80001b66:	6902                	ld	s2,0(sp)
    80001b68:	6105                	addi	sp,sp,32
    80001b6a:	8082                	ret
    uvmfree(pagetable, 0);
    80001b6c:	4581                	li	a1,0
    80001b6e:	8526                	mv	a0,s1
    80001b70:	893ff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001b74:	4481                	li	s1,0
    80001b76:	b7e5                	j	80001b5e <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b78:	4681                	li	a3,0
    80001b7a:	4605                	li	a2,1
    80001b7c:	040005b7          	lui	a1,0x4000
    80001b80:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b82:	05b2                	slli	a1,a1,0xc
    80001b84:	8526                	mv	a0,s1
    80001b86:	ea8ff0ef          	jal	8000122e <uvmunmap>
    uvmfree(pagetable, 0);
    80001b8a:	4581                	li	a1,0
    80001b8c:	8526                	mv	a0,s1
    80001b8e:	875ff0ef          	jal	80001402 <uvmfree>
    return 0;
    80001b92:	4481                	li	s1,0
    80001b94:	b7e9                	j	80001b5e <proc_pagetable+0x4c>

0000000080001b96 <proc_freepagetable>:
{
    80001b96:	1101                	addi	sp,sp,-32
    80001b98:	ec06                	sd	ra,24(sp)
    80001b9a:	e822                	sd	s0,16(sp)
    80001b9c:	e426                	sd	s1,8(sp)
    80001b9e:	e04a                	sd	s2,0(sp)
    80001ba0:	1000                	addi	s0,sp,32
    80001ba2:	84aa                	mv	s1,a0
    80001ba4:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ba6:	4681                	li	a3,0
    80001ba8:	4605                	li	a2,1
    80001baa:	040005b7          	lui	a1,0x4000
    80001bae:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001bb0:	05b2                	slli	a1,a1,0xc
    80001bb2:	e7cff0ef          	jal	8000122e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001bb6:	4681                	li	a3,0
    80001bb8:	4605                	li	a2,1
    80001bba:	020005b7          	lui	a1,0x2000
    80001bbe:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001bc0:	05b6                	slli	a1,a1,0xd
    80001bc2:	8526                	mv	a0,s1
    80001bc4:	e6aff0ef          	jal	8000122e <uvmunmap>
  uvmfree(pagetable, sz);
    80001bc8:	85ca                	mv	a1,s2
    80001bca:	8526                	mv	a0,s1
    80001bcc:	837ff0ef          	jal	80001402 <uvmfree>
}
    80001bd0:	60e2                	ld	ra,24(sp)
    80001bd2:	6442                	ld	s0,16(sp)
    80001bd4:	64a2                	ld	s1,8(sp)
    80001bd6:	6902                	ld	s2,0(sp)
    80001bd8:	6105                	addi	sp,sp,32
    80001bda:	8082                	ret

0000000080001bdc <freeproc>:
{
    80001bdc:	1101                	addi	sp,sp,-32
    80001bde:	ec06                	sd	ra,24(sp)
    80001be0:	e822                	sd	s0,16(sp)
    80001be2:	e426                	sd	s1,8(sp)
    80001be4:	1000                	addi	s0,sp,32
    80001be6:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001be8:	6d28                	ld	a0,88(a0)
    80001bea:	c119                	beqz	a0,80001bf0 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001bec:	e71fe0ef          	jal	80000a5c <kfree>
  p->trapframe = 0;
    80001bf0:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001bf4:	68a8                	ld	a0,80(s1)
    80001bf6:	c501                	beqz	a0,80001bfe <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001bf8:	64ac                	ld	a1,72(s1)
    80001bfa:	f9dff0ef          	jal	80001b96 <proc_freepagetable>
  p->pagetable = 0;
    80001bfe:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001c02:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001c06:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001c0a:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001c0e:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001c12:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001c16:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001c1a:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001c1e:	0004ac23          	sw	zero,24(s1)
  p->nice = 0;      // Initialize the nice value for the process as 0
    80001c22:	0204aa23          	sw	zero,52(s1)
}
    80001c26:	60e2                	ld	ra,24(sp)
    80001c28:	6442                	ld	s0,16(sp)
    80001c2a:	64a2                	ld	s1,8(sp)
    80001c2c:	6105                	addi	sp,sp,32
    80001c2e:	8082                	ret

0000000080001c30 <allocproc>:
{
    80001c30:	1101                	addi	sp,sp,-32
    80001c32:	ec06                	sd	ra,24(sp)
    80001c34:	e822                	sd	s0,16(sp)
    80001c36:	e426                	sd	s1,8(sp)
    80001c38:	e04a                	sd	s2,0(sp)
    80001c3a:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001c3c:	00011497          	auipc	s1,0x11
    80001c40:	c1c48493          	addi	s1,s1,-996 # 80012858 <proc>
    80001c44:	00016917          	auipc	s2,0x16
    80001c48:	61490913          	addi	s2,s2,1556 # 80018258 <tickslock>
    acquire(&p->lock);
    80001c4c:	8526                	mv	a0,s1
    80001c4e:	fdbfe0ef          	jal	80000c28 <acquire>
    if(p->state == UNUSED) {
    80001c52:	4c9c                	lw	a5,24(s1)
    80001c54:	cb91                	beqz	a5,80001c68 <allocproc+0x38>
      release(&p->lock);
    80001c56:	8526                	mv	a0,s1
    80001c58:	864ff0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001c5c:	16848493          	addi	s1,s1,360
    80001c60:	ff2496e3          	bne	s1,s2,80001c4c <allocproc+0x1c>
  return 0;
    80001c64:	4481                	li	s1,0
    80001c66:	a099                	j	80001cac <allocproc+0x7c>
  p->pid = allocpid();
    80001c68:	e6dff0ef          	jal	80001ad4 <allocpid>
    80001c6c:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001c6e:	4785                	li	a5,1
    80001c70:	cc9c                	sw	a5,24(s1)
  p->nice = 0 ;
    80001c72:	0204aa23          	sw	zero,52(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001c76:	ecffe0ef          	jal	80000b44 <kalloc>
    80001c7a:	892a                	mv	s2,a0
    80001c7c:	eca8                	sd	a0,88(s1)
    80001c7e:	cd15                	beqz	a0,80001cba <allocproc+0x8a>
  p->pagetable = proc_pagetable(p);
    80001c80:	8526                	mv	a0,s1
    80001c82:	e91ff0ef          	jal	80001b12 <proc_pagetable>
    80001c86:	892a                	mv	s2,a0
    80001c88:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001c8a:	c121                	beqz	a0,80001cca <allocproc+0x9a>
  memset(&p->context, 0, sizeof(p->context));
    80001c8c:	07000613          	li	a2,112
    80001c90:	4581                	li	a1,0
    80001c92:	06048513          	addi	a0,s1,96
    80001c96:	862ff0ef          	jal	80000cf8 <memset>
  p->context.ra = (uint64)forkret;
    80001c9a:	00000797          	auipc	a5,0x0
    80001c9e:	da078793          	addi	a5,a5,-608 # 80001a3a <forkret>
    80001ca2:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001ca4:	60bc                	ld	a5,64(s1)
    80001ca6:	6705                	lui	a4,0x1
    80001ca8:	97ba                	add	a5,a5,a4
    80001caa:	f4bc                	sd	a5,104(s1)
}
    80001cac:	8526                	mv	a0,s1
    80001cae:	60e2                	ld	ra,24(sp)
    80001cb0:	6442                	ld	s0,16(sp)
    80001cb2:	64a2                	ld	s1,8(sp)
    80001cb4:	6902                	ld	s2,0(sp)
    80001cb6:	6105                	addi	sp,sp,32
    80001cb8:	8082                	ret
    freeproc(p);
    80001cba:	8526                	mv	a0,s1
    80001cbc:	f21ff0ef          	jal	80001bdc <freeproc>
    release(&p->lock);
    80001cc0:	8526                	mv	a0,s1
    80001cc2:	ffbfe0ef          	jal	80000cbc <release>
    return 0;
    80001cc6:	84ca                	mv	s1,s2
    80001cc8:	b7d5                	j	80001cac <allocproc+0x7c>
    freeproc(p);
    80001cca:	8526                	mv	a0,s1
    80001ccc:	f11ff0ef          	jal	80001bdc <freeproc>
    release(&p->lock);
    80001cd0:	8526                	mv	a0,s1
    80001cd2:	febfe0ef          	jal	80000cbc <release>
    return 0;
    80001cd6:	84ca                	mv	s1,s2
    80001cd8:	bfd1                	j	80001cac <allocproc+0x7c>

0000000080001cda <userinit>:
{
    80001cda:	1101                	addi	sp,sp,-32
    80001cdc:	ec06                	sd	ra,24(sp)
    80001cde:	e822                	sd	s0,16(sp)
    80001ce0:	e426                	sd	s1,8(sp)
    80001ce2:	1000                	addi	s0,sp,32
  p = allocproc();
    80001ce4:	f4dff0ef          	jal	80001c30 <allocproc>
    80001ce8:	84aa                	mv	s1,a0
  initproc = p;
    80001cea:	00008797          	auipc	a5,0x8
    80001cee:	62a7b723          	sd	a0,1582(a5) # 8000a318 <initproc>
  p->cwd = namei("/");
    80001cf2:	00005517          	auipc	a0,0x5
    80001cf6:	4e650513          	addi	a0,a0,1254 # 800071d8 <etext+0x1d8>
    80001cfa:	651010ef          	jal	80003b4a <namei>
    80001cfe:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001d02:	478d                	li	a5,3
    80001d04:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001d06:	8526                	mv	a0,s1
    80001d08:	fb5fe0ef          	jal	80000cbc <release>
}
    80001d0c:	60e2                	ld	ra,24(sp)
    80001d0e:	6442                	ld	s0,16(sp)
    80001d10:	64a2                	ld	s1,8(sp)
    80001d12:	6105                	addi	sp,sp,32
    80001d14:	8082                	ret

0000000080001d16 <growproc>:
{
    80001d16:	1101                	addi	sp,sp,-32
    80001d18:	ec06                	sd	ra,24(sp)
    80001d1a:	e822                	sd	s0,16(sp)
    80001d1c:	e426                	sd	s1,8(sp)
    80001d1e:	e04a                	sd	s2,0(sp)
    80001d20:	1000                	addi	s0,sp,32
    80001d22:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001d24:	ce5ff0ef          	jal	80001a08 <myproc>
    80001d28:	892a                	mv	s2,a0
  sz = p->sz;
    80001d2a:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001d2c:	02905963          	blez	s1,80001d5e <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001d30:	00b48633          	add	a2,s1,a1
    80001d34:	020007b7          	lui	a5,0x2000
    80001d38:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001d3a:	07b6                	slli	a5,a5,0xd
    80001d3c:	02c7ea63          	bltu	a5,a2,80001d70 <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001d40:	4691                	li	a3,4
    80001d42:	6928                	ld	a0,80(a0)
    80001d44:	db8ff0ef          	jal	800012fc <uvmalloc>
    80001d48:	85aa                	mv	a1,a0
    80001d4a:	c50d                	beqz	a0,80001d74 <growproc+0x5e>
  p->sz = sz;
    80001d4c:	04b93423          	sd	a1,72(s2)
  return 0;
    80001d50:	4501                	li	a0,0
}
    80001d52:	60e2                	ld	ra,24(sp)
    80001d54:	6442                	ld	s0,16(sp)
    80001d56:	64a2                	ld	s1,8(sp)
    80001d58:	6902                	ld	s2,0(sp)
    80001d5a:	6105                	addi	sp,sp,32
    80001d5c:	8082                	ret
  } else if(n < 0){
    80001d5e:	fe04d7e3          	bgez	s1,80001d4c <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001d62:	00b48633          	add	a2,s1,a1
    80001d66:	6928                	ld	a0,80(a0)
    80001d68:	d50ff0ef          	jal	800012b8 <uvmdealloc>
    80001d6c:	85aa                	mv	a1,a0
    80001d6e:	bff9                	j	80001d4c <growproc+0x36>
      return -1;
    80001d70:	557d                	li	a0,-1
    80001d72:	b7c5                	j	80001d52 <growproc+0x3c>
      return -1;
    80001d74:	557d                	li	a0,-1
    80001d76:	bff1                	j	80001d52 <growproc+0x3c>

0000000080001d78 <kfork>:
{
    80001d78:	7139                	addi	sp,sp,-64
    80001d7a:	fc06                	sd	ra,56(sp)
    80001d7c:	f822                	sd	s0,48(sp)
    80001d7e:	f426                	sd	s1,40(sp)
    80001d80:	e456                	sd	s5,8(sp)
    80001d82:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001d84:	c85ff0ef          	jal	80001a08 <myproc>
    80001d88:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001d8a:	ea7ff0ef          	jal	80001c30 <allocproc>
    80001d8e:	0e050a63          	beqz	a0,80001e82 <kfork+0x10a>
    80001d92:	e852                	sd	s4,16(sp)
    80001d94:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001d96:	048ab603          	ld	a2,72(s5)
    80001d9a:	692c                	ld	a1,80(a0)
    80001d9c:	050ab503          	ld	a0,80(s5)
    80001da0:	e94ff0ef          	jal	80001434 <uvmcopy>
    80001da4:	04054863          	bltz	a0,80001df4 <kfork+0x7c>
    80001da8:	f04a                	sd	s2,32(sp)
    80001daa:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001dac:	048ab783          	ld	a5,72(s5)
    80001db0:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001db4:	058ab683          	ld	a3,88(s5)
    80001db8:	87b6                	mv	a5,a3
    80001dba:	058a3703          	ld	a4,88(s4)
    80001dbe:	12068693          	addi	a3,a3,288
    80001dc2:	6388                	ld	a0,0(a5)
    80001dc4:	678c                	ld	a1,8(a5)
    80001dc6:	6b90                	ld	a2,16(a5)
    80001dc8:	e308                	sd	a0,0(a4)
    80001dca:	e70c                	sd	a1,8(a4)
    80001dcc:	eb10                	sd	a2,16(a4)
    80001dce:	6f90                	ld	a2,24(a5)
    80001dd0:	ef10                	sd	a2,24(a4)
    80001dd2:	02078793          	addi	a5,a5,32
    80001dd6:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001dda:	fed794e3          	bne	a5,a3,80001dc2 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001dde:	058a3783          	ld	a5,88(s4)
    80001de2:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001de6:	0d0a8493          	addi	s1,s5,208
    80001dea:	0d0a0913          	addi	s2,s4,208
    80001dee:	150a8993          	addi	s3,s5,336
    80001df2:	a831                	j	80001e0e <kfork+0x96>
    freeproc(np);
    80001df4:	8552                	mv	a0,s4
    80001df6:	de7ff0ef          	jal	80001bdc <freeproc>
    release(&np->lock);
    80001dfa:	8552                	mv	a0,s4
    80001dfc:	ec1fe0ef          	jal	80000cbc <release>
    return -1;
    80001e00:	54fd                	li	s1,-1
    80001e02:	6a42                	ld	s4,16(sp)
    80001e04:	a885                	j	80001e74 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001e06:	04a1                	addi	s1,s1,8
    80001e08:	0921                	addi	s2,s2,8
    80001e0a:	01348963          	beq	s1,s3,80001e1c <kfork+0xa4>
    if(p->ofile[i])
    80001e0e:	6088                	ld	a0,0(s1)
    80001e10:	d97d                	beqz	a0,80001e06 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001e12:	2f4020ef          	jal	80004106 <filedup>
    80001e16:	00a93023          	sd	a0,0(s2)
    80001e1a:	b7f5                	j	80001e06 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001e1c:	150ab503          	ld	a0,336(s5)
    80001e20:	4c6010ef          	jal	800032e6 <idup>
    80001e24:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001e28:	4641                	li	a2,16
    80001e2a:	158a8593          	addi	a1,s5,344
    80001e2e:	158a0513          	addi	a0,s4,344
    80001e32:	81aff0ef          	jal	80000e4c <safestrcpy>
  pid = np->pid;
    80001e36:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001e3a:	8552                	mv	a0,s4
    80001e3c:	e81fe0ef          	jal	80000cbc <release>
  acquire(&wait_lock);
    80001e40:	00010517          	auipc	a0,0x10
    80001e44:	60050513          	addi	a0,a0,1536 # 80012440 <wait_lock>
    80001e48:	de1fe0ef          	jal	80000c28 <acquire>
  np->parent = p;
    80001e4c:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001e50:	00010517          	auipc	a0,0x10
    80001e54:	5f050513          	addi	a0,a0,1520 # 80012440 <wait_lock>
    80001e58:	e65fe0ef          	jal	80000cbc <release>
  acquire(&np->lock);
    80001e5c:	8552                	mv	a0,s4
    80001e5e:	dcbfe0ef          	jal	80000c28 <acquire>
  np->state = RUNNABLE;
    80001e62:	478d                	li	a5,3
    80001e64:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001e68:	8552                	mv	a0,s4
    80001e6a:	e53fe0ef          	jal	80000cbc <release>
  return pid;
    80001e6e:	7902                	ld	s2,32(sp)
    80001e70:	69e2                	ld	s3,24(sp)
    80001e72:	6a42                	ld	s4,16(sp)
}
    80001e74:	8526                	mv	a0,s1
    80001e76:	70e2                	ld	ra,56(sp)
    80001e78:	7442                	ld	s0,48(sp)
    80001e7a:	74a2                	ld	s1,40(sp)
    80001e7c:	6aa2                	ld	s5,8(sp)
    80001e7e:	6121                	addi	sp,sp,64
    80001e80:	8082                	ret
    return -1;
    80001e82:	54fd                	li	s1,-1
    80001e84:	bfc5                	j	80001e74 <kfork+0xfc>

0000000080001e86 <scheduler>:
{
    80001e86:	715d                	addi	sp,sp,-80
    80001e88:	e486                	sd	ra,72(sp)
    80001e8a:	e0a2                	sd	s0,64(sp)
    80001e8c:	fc26                	sd	s1,56(sp)
    80001e8e:	f84a                	sd	s2,48(sp)
    80001e90:	f44e                	sd	s3,40(sp)
    80001e92:	f052                	sd	s4,32(sp)
    80001e94:	ec56                	sd	s5,24(sp)
    80001e96:	e85a                	sd	s6,16(sp)
    80001e98:	e45e                	sd	s7,8(sp)
    80001e9a:	e062                	sd	s8,0(sp)
    80001e9c:	0880                	addi	s0,sp,80
    80001e9e:	8792                	mv	a5,tp
  int id = r_tp();
    80001ea0:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001ea2:	00779b93          	slli	s7,a5,0x7
    80001ea6:	00010717          	auipc	a4,0x10
    80001eaa:	58270713          	addi	a4,a4,1410 # 80012428 <pid_lock>
    80001eae:	975e                	add	a4,a4,s7
    80001eb0:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001eb4:	00010717          	auipc	a4,0x10
    80001eb8:	5ac70713          	addi	a4,a4,1452 # 80012460 <cpus+0x8>
    80001ebc:	9bba                	add	s7,s7,a4
        p->state = RUNNING;
    80001ebe:	4c11                	li	s8,4
        c->proc = p;
    80001ec0:	079e                	slli	a5,a5,0x7
    80001ec2:	00010997          	auipc	s3,0x10
    80001ec6:	56698993          	addi	s3,s3,1382 # 80012428 <pid_lock>
    80001eca:	99be                	add	s3,s3,a5
    80001ecc:	a095                	j	80001f30 <scheduler+0xaa>
        swtch(&c->context, &p->context);
    80001ece:	060a0593          	addi	a1,s4,96
    80001ed2:	855e                	mv	a0,s7
    80001ed4:	604000ef          	jal	800024d8 <swtch>
        c->proc = 0;
    80001ed8:	0209b823          	sd	zero,48(s3)
        found = 1;
    80001edc:	8a5a                	mv	s4,s6
      release(&p->lock);
    80001ede:	8526                	mv	a0,s1
    80001ee0:	dddfe0ef          	jal	80000cbc <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001ee4:	16848493          	addi	s1,s1,360
    80001ee8:	00016797          	auipc	a5,0x16
    80001eec:	37078793          	addi	a5,a5,880 # 80018258 <tickslock>
    80001ef0:	02f48c63          	beq	s1,a5,80001f28 <scheduler+0xa2>
      acquire(&p->lock);
    80001ef4:	8526                	mv	a0,s1
    80001ef6:	d33fe0ef          	jal	80000c28 <acquire>
      if(p->state == RUNNABLE) {
    80001efa:	4c9c                	lw	a5,24(s1)
    80001efc:	ff2791e3          	bne	a5,s2,80001ede <scheduler+0x58>
    80001f00:	8a26                	mv	s4,s1
        p->state = RUNNING;
    80001f02:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001f06:	0299b823          	sd	s1,48(s3)
        if (logging) {
    80001f0a:	000aa783          	lw	a5,0(s5)
    80001f0e:	d3e1                	beqz	a5,80001ece <scheduler+0x48>
          printf("running %d at %d\n", p->pid, ticks);  //If loggging is enabled, then print that the scheduler is switching to another process.
    80001f10:	00008617          	auipc	a2,0x8
    80001f14:	41062603          	lw	a2,1040(a2) # 8000a320 <ticks>
    80001f18:	588c                	lw	a1,48(s1)
    80001f1a:	00005517          	auipc	a0,0x5
    80001f1e:	2c650513          	addi	a0,a0,710 # 800071e0 <etext+0x1e0>
    80001f22:	dd8fe0ef          	jal	800004fa <printf>
    80001f26:	b765                	j	80001ece <scheduler+0x48>
    if(found == 0) {
    80001f28:	000a1563          	bnez	s4,80001f32 <scheduler+0xac>
      asm volatile("wfi");
    80001f2c:	10500073          	wfi
        found = 1;
    80001f30:	4b05                	li	s6,1
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f32:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001f36:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001f3a:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f3e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001f42:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001f44:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001f48:	4a01                	li	s4,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001f4a:	00011497          	auipc	s1,0x11
    80001f4e:	90e48493          	addi	s1,s1,-1778 # 80012858 <proc>
      if(p->state == RUNNABLE) {
    80001f52:	490d                	li	s2,3
        if (logging) {
    80001f54:	00008a97          	auipc	s5,0x8
    80001f58:	3bca8a93          	addi	s5,s5,956 # 8000a310 <logging>
    80001f5c:	bf61                	j	80001ef4 <scheduler+0x6e>

0000000080001f5e <sched>:
{
    80001f5e:	7179                	addi	sp,sp,-48
    80001f60:	f406                	sd	ra,40(sp)
    80001f62:	f022                	sd	s0,32(sp)
    80001f64:	ec26                	sd	s1,24(sp)
    80001f66:	e84a                	sd	s2,16(sp)
    80001f68:	e44e                	sd	s3,8(sp)
    80001f6a:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001f6c:	a9dff0ef          	jal	80001a08 <myproc>
    80001f70:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001f72:	c47fe0ef          	jal	80000bb8 <holding>
    80001f76:	c935                	beqz	a0,80001fea <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001f78:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001f7a:	2781                	sext.w	a5,a5
    80001f7c:	079e                	slli	a5,a5,0x7
    80001f7e:	00010717          	auipc	a4,0x10
    80001f82:	4aa70713          	addi	a4,a4,1194 # 80012428 <pid_lock>
    80001f86:	97ba                	add	a5,a5,a4
    80001f88:	0a87a703          	lw	a4,168(a5)
    80001f8c:	4785                	li	a5,1
    80001f8e:	06f71463          	bne	a4,a5,80001ff6 <sched+0x98>
  if(p->state == RUNNING)
    80001f92:	4c98                	lw	a4,24(s1)
    80001f94:	4791                	li	a5,4
    80001f96:	06f70663          	beq	a4,a5,80002002 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f9a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001f9e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001fa0:	e7bd                	bnez	a5,8000200e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001fa2:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001fa4:	00010917          	auipc	s2,0x10
    80001fa8:	48490913          	addi	s2,s2,1156 # 80012428 <pid_lock>
    80001fac:	2781                	sext.w	a5,a5
    80001fae:	079e                	slli	a5,a5,0x7
    80001fb0:	97ca                	add	a5,a5,s2
    80001fb2:	0ac7a983          	lw	s3,172(a5)
    80001fb6:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001fb8:	2781                	sext.w	a5,a5
    80001fba:	079e                	slli	a5,a5,0x7
    80001fbc:	07a1                	addi	a5,a5,8
    80001fbe:	00010597          	auipc	a1,0x10
    80001fc2:	49a58593          	addi	a1,a1,1178 # 80012458 <cpus>
    80001fc6:	95be                	add	a1,a1,a5
    80001fc8:	06048513          	addi	a0,s1,96
    80001fcc:	50c000ef          	jal	800024d8 <swtch>
    80001fd0:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001fd2:	2781                	sext.w	a5,a5
    80001fd4:	079e                	slli	a5,a5,0x7
    80001fd6:	993e                	add	s2,s2,a5
    80001fd8:	0b392623          	sw	s3,172(s2)
}
    80001fdc:	70a2                	ld	ra,40(sp)
    80001fde:	7402                	ld	s0,32(sp)
    80001fe0:	64e2                	ld	s1,24(sp)
    80001fe2:	6942                	ld	s2,16(sp)
    80001fe4:	69a2                	ld	s3,8(sp)
    80001fe6:	6145                	addi	sp,sp,48
    80001fe8:	8082                	ret
    panic("sched p->lock");
    80001fea:	00005517          	auipc	a0,0x5
    80001fee:	20e50513          	addi	a0,a0,526 # 800071f8 <etext+0x1f8>
    80001ff2:	833fe0ef          	jal	80000824 <panic>
    panic("sched locks");
    80001ff6:	00005517          	auipc	a0,0x5
    80001ffa:	21250513          	addi	a0,a0,530 # 80007208 <etext+0x208>
    80001ffe:	827fe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    80002002:	00005517          	auipc	a0,0x5
    80002006:	21650513          	addi	a0,a0,534 # 80007218 <etext+0x218>
    8000200a:	81bfe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    8000200e:	00005517          	auipc	a0,0x5
    80002012:	21a50513          	addi	a0,a0,538 # 80007228 <etext+0x228>
    80002016:	80ffe0ef          	jal	80000824 <panic>

000000008000201a <yield>:
{
    8000201a:	1101                	addi	sp,sp,-32
    8000201c:	ec06                	sd	ra,24(sp)
    8000201e:	e822                	sd	s0,16(sp)
    80002020:	e426                	sd	s1,8(sp)
    80002022:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80002024:	9e5ff0ef          	jal	80001a08 <myproc>
    80002028:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000202a:	bfffe0ef          	jal	80000c28 <acquire>
  p->state = RUNNABLE;
    8000202e:	478d                	li	a5,3
    80002030:	cc9c                	sw	a5,24(s1)
  sched();
    80002032:	f2dff0ef          	jal	80001f5e <sched>
  release(&p->lock);
    80002036:	8526                	mv	a0,s1
    80002038:	c85fe0ef          	jal	80000cbc <release>
}
    8000203c:	60e2                	ld	ra,24(sp)
    8000203e:	6442                	ld	s0,16(sp)
    80002040:	64a2                	ld	s1,8(sp)
    80002042:	6105                	addi	sp,sp,32
    80002044:	8082                	ret

0000000080002046 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80002046:	7179                	addi	sp,sp,-48
    80002048:	f406                	sd	ra,40(sp)
    8000204a:	f022                	sd	s0,32(sp)
    8000204c:	ec26                	sd	s1,24(sp)
    8000204e:	e84a                	sd	s2,16(sp)
    80002050:	e44e                	sd	s3,8(sp)
    80002052:	1800                	addi	s0,sp,48
    80002054:	89aa                	mv	s3,a0
    80002056:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002058:	9b1ff0ef          	jal	80001a08 <myproc>
    8000205c:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    8000205e:	bcbfe0ef          	jal	80000c28 <acquire>
  release(lk);
    80002062:	854a                	mv	a0,s2
    80002064:	c59fe0ef          	jal	80000cbc <release>

  // Go to sleep.
  p->chan = chan;
    80002068:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000206c:	4789                	li	a5,2
    8000206e:	cc9c                	sw	a5,24(s1)

  sched();
    80002070:	eefff0ef          	jal	80001f5e <sched>

  // Tidy up.
  p->chan = 0;
    80002074:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002078:	8526                	mv	a0,s1
    8000207a:	c43fe0ef          	jal	80000cbc <release>
  acquire(lk);
    8000207e:	854a                	mv	a0,s2
    80002080:	ba9fe0ef          	jal	80000c28 <acquire>
}
    80002084:	70a2                	ld	ra,40(sp)
    80002086:	7402                	ld	s0,32(sp)
    80002088:	64e2                	ld	s1,24(sp)
    8000208a:	6942                	ld	s2,16(sp)
    8000208c:	69a2                	ld	s3,8(sp)
    8000208e:	6145                	addi	sp,sp,48
    80002090:	8082                	ret

0000000080002092 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80002092:	7139                	addi	sp,sp,-64
    80002094:	fc06                	sd	ra,56(sp)
    80002096:	f822                	sd	s0,48(sp)
    80002098:	f426                	sd	s1,40(sp)
    8000209a:	f04a                	sd	s2,32(sp)
    8000209c:	ec4e                	sd	s3,24(sp)
    8000209e:	e852                	sd	s4,16(sp)
    800020a0:	e456                	sd	s5,8(sp)
    800020a2:	0080                	addi	s0,sp,64
    800020a4:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800020a6:	00010497          	auipc	s1,0x10
    800020aa:	7b248493          	addi	s1,s1,1970 # 80012858 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800020ae:	4989                	li	s3,2
        p->state = RUNNABLE;
    800020b0:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800020b2:	00016917          	auipc	s2,0x16
    800020b6:	1a690913          	addi	s2,s2,422 # 80018258 <tickslock>
    800020ba:	a801                	j	800020ca <wakeup+0x38>
      }
      release(&p->lock);
    800020bc:	8526                	mv	a0,s1
    800020be:	bfffe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800020c2:	16848493          	addi	s1,s1,360
    800020c6:	03248263          	beq	s1,s2,800020ea <wakeup+0x58>
    if(p != myproc()){
    800020ca:	93fff0ef          	jal	80001a08 <myproc>
    800020ce:	fe950ae3          	beq	a0,s1,800020c2 <wakeup+0x30>
      acquire(&p->lock);
    800020d2:	8526                	mv	a0,s1
    800020d4:	b55fe0ef          	jal	80000c28 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800020d8:	4c9c                	lw	a5,24(s1)
    800020da:	ff3791e3          	bne	a5,s3,800020bc <wakeup+0x2a>
    800020de:	709c                	ld	a5,32(s1)
    800020e0:	fd479ee3          	bne	a5,s4,800020bc <wakeup+0x2a>
        p->state = RUNNABLE;
    800020e4:	0154ac23          	sw	s5,24(s1)
    800020e8:	bfd1                	j	800020bc <wakeup+0x2a>
    }
  }
}
    800020ea:	70e2                	ld	ra,56(sp)
    800020ec:	7442                	ld	s0,48(sp)
    800020ee:	74a2                	ld	s1,40(sp)
    800020f0:	7902                	ld	s2,32(sp)
    800020f2:	69e2                	ld	s3,24(sp)
    800020f4:	6a42                	ld	s4,16(sp)
    800020f6:	6aa2                	ld	s5,8(sp)
    800020f8:	6121                	addi	sp,sp,64
    800020fa:	8082                	ret

00000000800020fc <reparent>:
{
    800020fc:	7179                	addi	sp,sp,-48
    800020fe:	f406                	sd	ra,40(sp)
    80002100:	f022                	sd	s0,32(sp)
    80002102:	ec26                	sd	s1,24(sp)
    80002104:	e84a                	sd	s2,16(sp)
    80002106:	e44e                	sd	s3,8(sp)
    80002108:	e052                	sd	s4,0(sp)
    8000210a:	1800                	addi	s0,sp,48
    8000210c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000210e:	00010497          	auipc	s1,0x10
    80002112:	74a48493          	addi	s1,s1,1866 # 80012858 <proc>
      pp->parent = initproc;
    80002116:	00008a17          	auipc	s4,0x8
    8000211a:	202a0a13          	addi	s4,s4,514 # 8000a318 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000211e:	00016997          	auipc	s3,0x16
    80002122:	13a98993          	addi	s3,s3,314 # 80018258 <tickslock>
    80002126:	a029                	j	80002130 <reparent+0x34>
    80002128:	16848493          	addi	s1,s1,360
    8000212c:	01348b63          	beq	s1,s3,80002142 <reparent+0x46>
    if(pp->parent == p){
    80002130:	7c9c                	ld	a5,56(s1)
    80002132:	ff279be3          	bne	a5,s2,80002128 <reparent+0x2c>
      pp->parent = initproc;
    80002136:	000a3503          	ld	a0,0(s4)
    8000213a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000213c:	f57ff0ef          	jal	80002092 <wakeup>
    80002140:	b7e5                	j	80002128 <reparent+0x2c>
}
    80002142:	70a2                	ld	ra,40(sp)
    80002144:	7402                	ld	s0,32(sp)
    80002146:	64e2                	ld	s1,24(sp)
    80002148:	6942                	ld	s2,16(sp)
    8000214a:	69a2                	ld	s3,8(sp)
    8000214c:	6a02                	ld	s4,0(sp)
    8000214e:	6145                	addi	sp,sp,48
    80002150:	8082                	ret

0000000080002152 <kexit>:
{
    80002152:	7179                	addi	sp,sp,-48
    80002154:	f406                	sd	ra,40(sp)
    80002156:	f022                	sd	s0,32(sp)
    80002158:	ec26                	sd	s1,24(sp)
    8000215a:	e84a                	sd	s2,16(sp)
    8000215c:	e44e                	sd	s3,8(sp)
    8000215e:	e052                	sd	s4,0(sp)
    80002160:	1800                	addi	s0,sp,48
    80002162:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002164:	8a5ff0ef          	jal	80001a08 <myproc>
    80002168:	89aa                	mv	s3,a0
  if(p == initproc)
    8000216a:	00008797          	auipc	a5,0x8
    8000216e:	1ae7b783          	ld	a5,430(a5) # 8000a318 <initproc>
    80002172:	0d050493          	addi	s1,a0,208
    80002176:	15050913          	addi	s2,a0,336
    8000217a:	00a79b63          	bne	a5,a0,80002190 <kexit+0x3e>
    panic("init exiting");
    8000217e:	00005517          	auipc	a0,0x5
    80002182:	0c250513          	addi	a0,a0,194 # 80007240 <etext+0x240>
    80002186:	e9efe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    8000218a:	04a1                	addi	s1,s1,8
    8000218c:	01248963          	beq	s1,s2,8000219e <kexit+0x4c>
    if(p->ofile[fd]){
    80002190:	6088                	ld	a0,0(s1)
    80002192:	dd65                	beqz	a0,8000218a <kexit+0x38>
      fileclose(f);
    80002194:	7b9010ef          	jal	8000414c <fileclose>
      p->ofile[fd] = 0;
    80002198:	0004b023          	sd	zero,0(s1)
    8000219c:	b7fd                	j	8000218a <kexit+0x38>
  begin_op();
    8000219e:	38b010ef          	jal	80003d28 <begin_op>
  iput(p->cwd);
    800021a2:	1509b503          	ld	a0,336(s3)
    800021a6:	2f8010ef          	jal	8000349e <iput>
  end_op();
    800021aa:	3ef010ef          	jal	80003d98 <end_op>
  p->cwd = 0;
    800021ae:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800021b2:	00010517          	auipc	a0,0x10
    800021b6:	28e50513          	addi	a0,a0,654 # 80012440 <wait_lock>
    800021ba:	a6ffe0ef          	jal	80000c28 <acquire>
  reparent(p);
    800021be:	854e                	mv	a0,s3
    800021c0:	f3dff0ef          	jal	800020fc <reparent>
  wakeup(p->parent);
    800021c4:	0389b503          	ld	a0,56(s3)
    800021c8:	ecbff0ef          	jal	80002092 <wakeup>
  acquire(&p->lock);
    800021cc:	854e                	mv	a0,s3
    800021ce:	a5bfe0ef          	jal	80000c28 <acquire>
  p->xstate = status;
    800021d2:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800021d6:	4795                	li	a5,5
    800021d8:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800021dc:	00010517          	auipc	a0,0x10
    800021e0:	26450513          	addi	a0,a0,612 # 80012440 <wait_lock>
    800021e4:	ad9fe0ef          	jal	80000cbc <release>
  sched();
    800021e8:	d77ff0ef          	jal	80001f5e <sched>
  panic("zombie exit");
    800021ec:	00005517          	auipc	a0,0x5
    800021f0:	06450513          	addi	a0,a0,100 # 80007250 <etext+0x250>
    800021f4:	e30fe0ef          	jal	80000824 <panic>

00000000800021f8 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800021f8:	7179                	addi	sp,sp,-48
    800021fa:	f406                	sd	ra,40(sp)
    800021fc:	f022                	sd	s0,32(sp)
    800021fe:	ec26                	sd	s1,24(sp)
    80002200:	e84a                	sd	s2,16(sp)
    80002202:	e44e                	sd	s3,8(sp)
    80002204:	1800                	addi	s0,sp,48
    80002206:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002208:	00010497          	auipc	s1,0x10
    8000220c:	65048493          	addi	s1,s1,1616 # 80012858 <proc>
    80002210:	00016997          	auipc	s3,0x16
    80002214:	04898993          	addi	s3,s3,72 # 80018258 <tickslock>
    acquire(&p->lock);
    80002218:	8526                	mv	a0,s1
    8000221a:	a0ffe0ef          	jal	80000c28 <acquire>
    if(p->pid == pid){
    8000221e:	589c                	lw	a5,48(s1)
    80002220:	01278b63          	beq	a5,s2,80002236 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002224:	8526                	mv	a0,s1
    80002226:	a97fe0ef          	jal	80000cbc <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000222a:	16848493          	addi	s1,s1,360
    8000222e:	ff3495e3          	bne	s1,s3,80002218 <kkill+0x20>
  }
  return -1;
    80002232:	557d                	li	a0,-1
    80002234:	a819                	j	8000224a <kkill+0x52>
      p->killed = 1;
    80002236:	4785                	li	a5,1
    80002238:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000223a:	4c98                	lw	a4,24(s1)
    8000223c:	4789                	li	a5,2
    8000223e:	00f70d63          	beq	a4,a5,80002258 <kkill+0x60>
      release(&p->lock);
    80002242:	8526                	mv	a0,s1
    80002244:	a79fe0ef          	jal	80000cbc <release>
      return 0;
    80002248:	4501                	li	a0,0
}
    8000224a:	70a2                	ld	ra,40(sp)
    8000224c:	7402                	ld	s0,32(sp)
    8000224e:	64e2                	ld	s1,24(sp)
    80002250:	6942                	ld	s2,16(sp)
    80002252:	69a2                	ld	s3,8(sp)
    80002254:	6145                	addi	sp,sp,48
    80002256:	8082                	ret
        p->state = RUNNABLE;
    80002258:	478d                	li	a5,3
    8000225a:	cc9c                	sw	a5,24(s1)
    8000225c:	b7dd                	j	80002242 <kkill+0x4a>

000000008000225e <setkilled>:

void
setkilled(struct proc *p)
{
    8000225e:	1101                	addi	sp,sp,-32
    80002260:	ec06                	sd	ra,24(sp)
    80002262:	e822                	sd	s0,16(sp)
    80002264:	e426                	sd	s1,8(sp)
    80002266:	1000                	addi	s0,sp,32
    80002268:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000226a:	9bffe0ef          	jal	80000c28 <acquire>
  p->killed = 1;
    8000226e:	4785                	li	a5,1
    80002270:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002272:	8526                	mv	a0,s1
    80002274:	a49fe0ef          	jal	80000cbc <release>
}
    80002278:	60e2                	ld	ra,24(sp)
    8000227a:	6442                	ld	s0,16(sp)
    8000227c:	64a2                	ld	s1,8(sp)
    8000227e:	6105                	addi	sp,sp,32
    80002280:	8082                	ret

0000000080002282 <killed>:

int
killed(struct proc *p)
{
    80002282:	1101                	addi	sp,sp,-32
    80002284:	ec06                	sd	ra,24(sp)
    80002286:	e822                	sd	s0,16(sp)
    80002288:	e426                	sd	s1,8(sp)
    8000228a:	e04a                	sd	s2,0(sp)
    8000228c:	1000                	addi	s0,sp,32
    8000228e:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002290:	999fe0ef          	jal	80000c28 <acquire>
  k = p->killed;
    80002294:	549c                	lw	a5,40(s1)
    80002296:	893e                	mv	s2,a5
  release(&p->lock);
    80002298:	8526                	mv	a0,s1
    8000229a:	a23fe0ef          	jal	80000cbc <release>
  return k;
}
    8000229e:	854a                	mv	a0,s2
    800022a0:	60e2                	ld	ra,24(sp)
    800022a2:	6442                	ld	s0,16(sp)
    800022a4:	64a2                	ld	s1,8(sp)
    800022a6:	6902                	ld	s2,0(sp)
    800022a8:	6105                	addi	sp,sp,32
    800022aa:	8082                	ret

00000000800022ac <kwait>:
{
    800022ac:	715d                	addi	sp,sp,-80
    800022ae:	e486                	sd	ra,72(sp)
    800022b0:	e0a2                	sd	s0,64(sp)
    800022b2:	fc26                	sd	s1,56(sp)
    800022b4:	f84a                	sd	s2,48(sp)
    800022b6:	f44e                	sd	s3,40(sp)
    800022b8:	f052                	sd	s4,32(sp)
    800022ba:	ec56                	sd	s5,24(sp)
    800022bc:	e85a                	sd	s6,16(sp)
    800022be:	e45e                	sd	s7,8(sp)
    800022c0:	0880                	addi	s0,sp,80
    800022c2:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800022c4:	f44ff0ef          	jal	80001a08 <myproc>
    800022c8:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800022ca:	00010517          	auipc	a0,0x10
    800022ce:	17650513          	addi	a0,a0,374 # 80012440 <wait_lock>
    800022d2:	957fe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    800022d6:	4a15                	li	s4,5
        havekids = 1;
    800022d8:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022da:	00016997          	auipc	s3,0x16
    800022de:	f7e98993          	addi	s3,s3,-130 # 80018258 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800022e2:	00010b17          	auipc	s6,0x10
    800022e6:	15eb0b13          	addi	s6,s6,350 # 80012440 <wait_lock>
    800022ea:	a869                	j	80002384 <kwait+0xd8>
          pid = pp->pid;
    800022ec:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800022f0:	000b8c63          	beqz	s7,80002308 <kwait+0x5c>
    800022f4:	4691                	li	a3,4
    800022f6:	02c48613          	addi	a2,s1,44
    800022fa:	85de                	mv	a1,s7
    800022fc:	05093503          	ld	a0,80(s2)
    80002300:	b54ff0ef          	jal	80001654 <copyout>
    80002304:	02054a63          	bltz	a0,80002338 <kwait+0x8c>
          freeproc(pp);
    80002308:	8526                	mv	a0,s1
    8000230a:	8d3ff0ef          	jal	80001bdc <freeproc>
          release(&pp->lock);
    8000230e:	8526                	mv	a0,s1
    80002310:	9adfe0ef          	jal	80000cbc <release>
          release(&wait_lock);
    80002314:	00010517          	auipc	a0,0x10
    80002318:	12c50513          	addi	a0,a0,300 # 80012440 <wait_lock>
    8000231c:	9a1fe0ef          	jal	80000cbc <release>
}
    80002320:	854e                	mv	a0,s3
    80002322:	60a6                	ld	ra,72(sp)
    80002324:	6406                	ld	s0,64(sp)
    80002326:	74e2                	ld	s1,56(sp)
    80002328:	7942                	ld	s2,48(sp)
    8000232a:	79a2                	ld	s3,40(sp)
    8000232c:	7a02                	ld	s4,32(sp)
    8000232e:	6ae2                	ld	s5,24(sp)
    80002330:	6b42                	ld	s6,16(sp)
    80002332:	6ba2                	ld	s7,8(sp)
    80002334:	6161                	addi	sp,sp,80
    80002336:	8082                	ret
            release(&pp->lock);
    80002338:	8526                	mv	a0,s1
    8000233a:	983fe0ef          	jal	80000cbc <release>
            release(&wait_lock);
    8000233e:	00010517          	auipc	a0,0x10
    80002342:	10250513          	addi	a0,a0,258 # 80012440 <wait_lock>
    80002346:	977fe0ef          	jal	80000cbc <release>
            return -1;
    8000234a:	59fd                	li	s3,-1
    8000234c:	bfd1                	j	80002320 <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000234e:	16848493          	addi	s1,s1,360
    80002352:	03348063          	beq	s1,s3,80002372 <kwait+0xc6>
      if(pp->parent == p){
    80002356:	7c9c                	ld	a5,56(s1)
    80002358:	ff279be3          	bne	a5,s2,8000234e <kwait+0xa2>
        acquire(&pp->lock);
    8000235c:	8526                	mv	a0,s1
    8000235e:	8cbfe0ef          	jal	80000c28 <acquire>
        if(pp->state == ZOMBIE){
    80002362:	4c9c                	lw	a5,24(s1)
    80002364:	f94784e3          	beq	a5,s4,800022ec <kwait+0x40>
        release(&pp->lock);
    80002368:	8526                	mv	a0,s1
    8000236a:	953fe0ef          	jal	80000cbc <release>
        havekids = 1;
    8000236e:	8756                	mv	a4,s5
    80002370:	bff9                	j	8000234e <kwait+0xa2>
    if(!havekids || killed(p)){
    80002372:	cf19                	beqz	a4,80002390 <kwait+0xe4>
    80002374:	854a                	mv	a0,s2
    80002376:	f0dff0ef          	jal	80002282 <killed>
    8000237a:	e919                	bnez	a0,80002390 <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000237c:	85da                	mv	a1,s6
    8000237e:	854a                	mv	a0,s2
    80002380:	cc7ff0ef          	jal	80002046 <sleep>
    havekids = 0;
    80002384:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002386:	00010497          	auipc	s1,0x10
    8000238a:	4d248493          	addi	s1,s1,1234 # 80012858 <proc>
    8000238e:	b7e1                	j	80002356 <kwait+0xaa>
      release(&wait_lock);
    80002390:	00010517          	auipc	a0,0x10
    80002394:	0b050513          	addi	a0,a0,176 # 80012440 <wait_lock>
    80002398:	925fe0ef          	jal	80000cbc <release>
      return -1;
    8000239c:	59fd                	li	s3,-1
    8000239e:	b749                	j	80002320 <kwait+0x74>

00000000800023a0 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800023a0:	7179                	addi	sp,sp,-48
    800023a2:	f406                	sd	ra,40(sp)
    800023a4:	f022                	sd	s0,32(sp)
    800023a6:	ec26                	sd	s1,24(sp)
    800023a8:	e84a                	sd	s2,16(sp)
    800023aa:	e44e                	sd	s3,8(sp)
    800023ac:	e052                	sd	s4,0(sp)
    800023ae:	1800                	addi	s0,sp,48
    800023b0:	84aa                	mv	s1,a0
    800023b2:	8a2e                	mv	s4,a1
    800023b4:	89b2                	mv	s3,a2
    800023b6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800023b8:	e50ff0ef          	jal	80001a08 <myproc>
  if(user_dst){
    800023bc:	cc99                	beqz	s1,800023da <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800023be:	86ca                	mv	a3,s2
    800023c0:	864e                	mv	a2,s3
    800023c2:	85d2                	mv	a1,s4
    800023c4:	6928                	ld	a0,80(a0)
    800023c6:	a8eff0ef          	jal	80001654 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800023ca:	70a2                	ld	ra,40(sp)
    800023cc:	7402                	ld	s0,32(sp)
    800023ce:	64e2                	ld	s1,24(sp)
    800023d0:	6942                	ld	s2,16(sp)
    800023d2:	69a2                	ld	s3,8(sp)
    800023d4:	6a02                	ld	s4,0(sp)
    800023d6:	6145                	addi	sp,sp,48
    800023d8:	8082                	ret
    memmove((char *)dst, src, len);
    800023da:	0009061b          	sext.w	a2,s2
    800023de:	85ce                	mv	a1,s3
    800023e0:	8552                	mv	a0,s4
    800023e2:	977fe0ef          	jal	80000d58 <memmove>
    return 0;
    800023e6:	8526                	mv	a0,s1
    800023e8:	b7cd                	j	800023ca <either_copyout+0x2a>

00000000800023ea <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800023ea:	7179                	addi	sp,sp,-48
    800023ec:	f406                	sd	ra,40(sp)
    800023ee:	f022                	sd	s0,32(sp)
    800023f0:	ec26                	sd	s1,24(sp)
    800023f2:	e84a                	sd	s2,16(sp)
    800023f4:	e44e                	sd	s3,8(sp)
    800023f6:	e052                	sd	s4,0(sp)
    800023f8:	1800                	addi	s0,sp,48
    800023fa:	8a2a                	mv	s4,a0
    800023fc:	84ae                	mv	s1,a1
    800023fe:	89b2                	mv	s3,a2
    80002400:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002402:	e06ff0ef          	jal	80001a08 <myproc>
  if(user_src){
    80002406:	cc99                	beqz	s1,80002424 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002408:	86ca                	mv	a3,s2
    8000240a:	864e                	mv	a2,s3
    8000240c:	85d2                	mv	a1,s4
    8000240e:	6928                	ld	a0,80(a0)
    80002410:	b02ff0ef          	jal	80001712 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002414:	70a2                	ld	ra,40(sp)
    80002416:	7402                	ld	s0,32(sp)
    80002418:	64e2                	ld	s1,24(sp)
    8000241a:	6942                	ld	s2,16(sp)
    8000241c:	69a2                	ld	s3,8(sp)
    8000241e:	6a02                	ld	s4,0(sp)
    80002420:	6145                	addi	sp,sp,48
    80002422:	8082                	ret
    memmove(dst, (char*)src, len);
    80002424:	0009061b          	sext.w	a2,s2
    80002428:	85ce                	mv	a1,s3
    8000242a:	8552                	mv	a0,s4
    8000242c:	92dfe0ef          	jal	80000d58 <memmove>
    return 0;
    80002430:	8526                	mv	a0,s1
    80002432:	b7cd                	j	80002414 <either_copyin+0x2a>

0000000080002434 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002434:	715d                	addi	sp,sp,-80
    80002436:	e486                	sd	ra,72(sp)
    80002438:	e0a2                	sd	s0,64(sp)
    8000243a:	fc26                	sd	s1,56(sp)
    8000243c:	f84a                	sd	s2,48(sp)
    8000243e:	f44e                	sd	s3,40(sp)
    80002440:	f052                	sd	s4,32(sp)
    80002442:	ec56                	sd	s5,24(sp)
    80002444:	e85a                	sd	s6,16(sp)
    80002446:	e45e                	sd	s7,8(sp)
    80002448:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000244a:	00005517          	auipc	a0,0x5
    8000244e:	c2e50513          	addi	a0,a0,-978 # 80007078 <etext+0x78>
    80002452:	8a8fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002456:	00010497          	auipc	s1,0x10
    8000245a:	55a48493          	addi	s1,s1,1370 # 800129b0 <proc+0x158>
    8000245e:	00016917          	auipc	s2,0x16
    80002462:	f5290913          	addi	s2,s2,-174 # 800183b0 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002466:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002468:	00005997          	auipc	s3,0x5
    8000246c:	df898993          	addi	s3,s3,-520 # 80007260 <etext+0x260>
    printf("%d %s %s", p->pid, state, p->name);
    80002470:	00005a97          	auipc	s5,0x5
    80002474:	df8a8a93          	addi	s5,s5,-520 # 80007268 <etext+0x268>
    printf("\n");
    80002478:	00005a17          	auipc	s4,0x5
    8000247c:	c00a0a13          	addi	s4,s4,-1024 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002480:	00005b97          	auipc	s7,0x5
    80002484:	308b8b93          	addi	s7,s7,776 # 80007788 <states.0>
    80002488:	a829                	j	800024a2 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000248a:	ed86a583          	lw	a1,-296(a3)
    8000248e:	8556                	mv	a0,s5
    80002490:	86afe0ef          	jal	800004fa <printf>
    printf("\n");
    80002494:	8552                	mv	a0,s4
    80002496:	864fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000249a:	16848493          	addi	s1,s1,360
    8000249e:	03248263          	beq	s1,s2,800024c2 <procdump+0x8e>
    if(p->state == UNUSED)
    800024a2:	86a6                	mv	a3,s1
    800024a4:	ec04a783          	lw	a5,-320(s1)
    800024a8:	dbed                	beqz	a5,8000249a <procdump+0x66>
      state = "???";
    800024aa:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800024ac:	fcfb6fe3          	bltu	s6,a5,8000248a <procdump+0x56>
    800024b0:	02079713          	slli	a4,a5,0x20
    800024b4:	01d75793          	srli	a5,a4,0x1d
    800024b8:	97de                	add	a5,a5,s7
    800024ba:	6390                	ld	a2,0(a5)
    800024bc:	f679                	bnez	a2,8000248a <procdump+0x56>
      state = "???";
    800024be:	864e                	mv	a2,s3
    800024c0:	b7e9                	j	8000248a <procdump+0x56>
  }
}
    800024c2:	60a6                	ld	ra,72(sp)
    800024c4:	6406                	ld	s0,64(sp)
    800024c6:	74e2                	ld	s1,56(sp)
    800024c8:	7942                	ld	s2,48(sp)
    800024ca:	79a2                	ld	s3,40(sp)
    800024cc:	7a02                	ld	s4,32(sp)
    800024ce:	6ae2                	ld	s5,24(sp)
    800024d0:	6b42                	ld	s6,16(sp)
    800024d2:	6ba2                	ld	s7,8(sp)
    800024d4:	6161                	addi	sp,sp,80
    800024d6:	8082                	ret

00000000800024d8 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800024d8:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800024dc:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800024e0:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800024e2:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800024e4:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800024e8:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800024ec:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800024f0:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800024f4:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800024f8:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800024fc:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002500:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002504:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002508:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000250c:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002510:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002514:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002516:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002518:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000251c:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002520:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002524:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002528:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000252c:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002530:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002534:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002538:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000253c:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002540:	8082                	ret

0000000080002542 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002542:	1141                	addi	sp,sp,-16
    80002544:	e406                	sd	ra,8(sp)
    80002546:	e022                	sd	s0,0(sp)
    80002548:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000254a:	00005597          	auipc	a1,0x5
    8000254e:	d5e58593          	addi	a1,a1,-674 # 800072a8 <etext+0x2a8>
    80002552:	00016517          	auipc	a0,0x16
    80002556:	d0650513          	addi	a0,a0,-762 # 80018258 <tickslock>
    8000255a:	e44fe0ef          	jal	80000b9e <initlock>
}
    8000255e:	60a2                	ld	ra,8(sp)
    80002560:	6402                	ld	s0,0(sp)
    80002562:	0141                	addi	sp,sp,16
    80002564:	8082                	ret

0000000080002566 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002566:	1141                	addi	sp,sp,-16
    80002568:	e406                	sd	ra,8(sp)
    8000256a:	e022                	sd	s0,0(sp)
    8000256c:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000256e:	00003797          	auipc	a5,0x3
    80002572:	fa278793          	addi	a5,a5,-94 # 80005510 <kernelvec>
    80002576:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000257a:	60a2                	ld	ra,8(sp)
    8000257c:	6402                	ld	s0,0(sp)
    8000257e:	0141                	addi	sp,sp,16
    80002580:	8082                	ret

0000000080002582 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002582:	1141                	addi	sp,sp,-16
    80002584:	e406                	sd	ra,8(sp)
    80002586:	e022                	sd	s0,0(sp)
    80002588:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000258a:	c7eff0ef          	jal	80001a08 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000258e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002592:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002594:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002598:	04000737          	lui	a4,0x4000
    8000259c:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000259e:	0732                	slli	a4,a4,0xc
    800025a0:	00004797          	auipc	a5,0x4
    800025a4:	a6078793          	addi	a5,a5,-1440 # 80006000 <_trampoline>
    800025a8:	00004697          	auipc	a3,0x4
    800025ac:	a5868693          	addi	a3,a3,-1448 # 80006000 <_trampoline>
    800025b0:	8f95                	sub	a5,a5,a3
    800025b2:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800025b4:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800025b8:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800025ba:	18002773          	csrr	a4,satp
    800025be:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800025c0:	6d38                	ld	a4,88(a0)
    800025c2:	613c                	ld	a5,64(a0)
    800025c4:	6685                	lui	a3,0x1
    800025c6:	97b6                	add	a5,a5,a3
    800025c8:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800025ca:	6d3c                	ld	a5,88(a0)
    800025cc:	00000717          	auipc	a4,0x0
    800025d0:	0fc70713          	addi	a4,a4,252 # 800026c8 <usertrap>
    800025d4:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800025d6:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800025d8:	8712                	mv	a4,tp
    800025da:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025dc:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800025e0:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800025e4:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025e8:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800025ec:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800025ee:	6f9c                	ld	a5,24(a5)
    800025f0:	14179073          	csrw	sepc,a5
}
    800025f4:	60a2                	ld	ra,8(sp)
    800025f6:	6402                	ld	s0,0(sp)
    800025f8:	0141                	addi	sp,sp,16
    800025fa:	8082                	ret

00000000800025fc <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800025fc:	1141                	addi	sp,sp,-16
    800025fe:	e406                	sd	ra,8(sp)
    80002600:	e022                	sd	s0,0(sp)
    80002602:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80002604:	bd0ff0ef          	jal	800019d4 <cpuid>
    80002608:	cd11                	beqz	a0,80002624 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    8000260a:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000260e:	000f4737          	lui	a4,0xf4
    80002612:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002616:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002618:	14d79073          	csrw	stimecmp,a5
}
    8000261c:	60a2                	ld	ra,8(sp)
    8000261e:	6402                	ld	s0,0(sp)
    80002620:	0141                	addi	sp,sp,16
    80002622:	8082                	ret
    acquire(&tickslock);
    80002624:	00016517          	auipc	a0,0x16
    80002628:	c3450513          	addi	a0,a0,-972 # 80018258 <tickslock>
    8000262c:	dfcfe0ef          	jal	80000c28 <acquire>
    ticks++;
    80002630:	00008717          	auipc	a4,0x8
    80002634:	cf070713          	addi	a4,a4,-784 # 8000a320 <ticks>
    80002638:	431c                	lw	a5,0(a4)
    8000263a:	2785                	addiw	a5,a5,1
    8000263c:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000263e:	853a                	mv	a0,a4
    80002640:	a53ff0ef          	jal	80002092 <wakeup>
    release(&tickslock);
    80002644:	00016517          	auipc	a0,0x16
    80002648:	c1450513          	addi	a0,a0,-1004 # 80018258 <tickslock>
    8000264c:	e70fe0ef          	jal	80000cbc <release>
    80002650:	bf6d                	j	8000260a <clockintr+0xe>

0000000080002652 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002652:	1101                	addi	sp,sp,-32
    80002654:	ec06                	sd	ra,24(sp)
    80002656:	e822                	sd	s0,16(sp)
    80002658:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000265a:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000265e:	57fd                	li	a5,-1
    80002660:	17fe                	slli	a5,a5,0x3f
    80002662:	07a5                	addi	a5,a5,9
    80002664:	00f70c63          	beq	a4,a5,8000267c <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002668:	57fd                	li	a5,-1
    8000266a:	17fe                	slli	a5,a5,0x3f
    8000266c:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000266e:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002670:	04f70863          	beq	a4,a5,800026c0 <devintr+0x6e>
  }
}
    80002674:	60e2                	ld	ra,24(sp)
    80002676:	6442                	ld	s0,16(sp)
    80002678:	6105                	addi	sp,sp,32
    8000267a:	8082                	ret
    8000267c:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000267e:	73f020ef          	jal	800055bc <plic_claim>
    80002682:	872a                	mv	a4,a0
    80002684:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002686:	47a9                	li	a5,10
    80002688:	00f50963          	beq	a0,a5,8000269a <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    8000268c:	4785                	li	a5,1
    8000268e:	00f50963          	beq	a0,a5,800026a0 <devintr+0x4e>
    return 1;
    80002692:	4505                	li	a0,1
    } else if(irq){
    80002694:	eb09                	bnez	a4,800026a6 <devintr+0x54>
    80002696:	64a2                	ld	s1,8(sp)
    80002698:	bff1                	j	80002674 <devintr+0x22>
      uartintr();
    8000269a:	b5afe0ef          	jal	800009f4 <uartintr>
    if(irq)
    8000269e:	a819                	j	800026b4 <devintr+0x62>
      virtio_disk_intr();
    800026a0:	3b2030ef          	jal	80005a52 <virtio_disk_intr>
    if(irq)
    800026a4:	a801                	j	800026b4 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800026a6:	85ba                	mv	a1,a4
    800026a8:	00005517          	auipc	a0,0x5
    800026ac:	c0850513          	addi	a0,a0,-1016 # 800072b0 <etext+0x2b0>
    800026b0:	e4bfd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    800026b4:	8526                	mv	a0,s1
    800026b6:	727020ef          	jal	800055dc <plic_complete>
    return 1;
    800026ba:	4505                	li	a0,1
    800026bc:	64a2                	ld	s1,8(sp)
    800026be:	bf5d                	j	80002674 <devintr+0x22>
    clockintr();
    800026c0:	f3dff0ef          	jal	800025fc <clockintr>
    return 2;
    800026c4:	4509                	li	a0,2
    800026c6:	b77d                	j	80002674 <devintr+0x22>

00000000800026c8 <usertrap>:
{
    800026c8:	1101                	addi	sp,sp,-32
    800026ca:	ec06                	sd	ra,24(sp)
    800026cc:	e822                	sd	s0,16(sp)
    800026ce:	e426                	sd	s1,8(sp)
    800026d0:	e04a                	sd	s2,0(sp)
    800026d2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026d4:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800026d8:	1007f793          	andi	a5,a5,256
    800026dc:	eba5                	bnez	a5,8000274c <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800026de:	00003797          	auipc	a5,0x3
    800026e2:	e3278793          	addi	a5,a5,-462 # 80005510 <kernelvec>
    800026e6:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800026ea:	b1eff0ef          	jal	80001a08 <myproc>
    800026ee:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800026f0:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026f2:	14102773          	csrr	a4,sepc
    800026f6:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026f8:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800026fc:	47a1                	li	a5,8
    800026fe:	04f70d63          	beq	a4,a5,80002758 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002702:	f51ff0ef          	jal	80002652 <devintr>
    80002706:	892a                	mv	s2,a0
    80002708:	e945                	bnez	a0,800027b8 <usertrap+0xf0>
    8000270a:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    8000270e:	47bd                	li	a5,15
    80002710:	08f70863          	beq	a4,a5,800027a0 <usertrap+0xd8>
    80002714:	14202773          	csrr	a4,scause
    80002718:	47b5                	li	a5,13
    8000271a:	08f70363          	beq	a4,a5,800027a0 <usertrap+0xd8>
    8000271e:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002722:	5890                	lw	a2,48(s1)
    80002724:	00005517          	auipc	a0,0x5
    80002728:	bcc50513          	addi	a0,a0,-1076 # 800072f0 <etext+0x2f0>
    8000272c:	dcffd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002730:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002734:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002738:	00005517          	auipc	a0,0x5
    8000273c:	be850513          	addi	a0,a0,-1048 # 80007320 <etext+0x320>
    80002740:	dbbfd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002744:	8526                	mv	a0,s1
    80002746:	b19ff0ef          	jal	8000225e <setkilled>
    8000274a:	a035                	j	80002776 <usertrap+0xae>
    panic("usertrap: not from user mode");
    8000274c:	00005517          	auipc	a0,0x5
    80002750:	b8450513          	addi	a0,a0,-1148 # 800072d0 <etext+0x2d0>
    80002754:	8d0fe0ef          	jal	80000824 <panic>
    if(killed(p))
    80002758:	b2bff0ef          	jal	80002282 <killed>
    8000275c:	ed15                	bnez	a0,80002798 <usertrap+0xd0>
    p->trapframe->epc += 4;
    8000275e:	6cb8                	ld	a4,88(s1)
    80002760:	6f1c                	ld	a5,24(a4)
    80002762:	0791                	addi	a5,a5,4
    80002764:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002766:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000276a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000276e:	10079073          	csrw	sstatus,a5
    syscall();
    80002772:	240000ef          	jal	800029b2 <syscall>
  if(killed(p))
    80002776:	8526                	mv	a0,s1
    80002778:	b0bff0ef          	jal	80002282 <killed>
    8000277c:	e139                	bnez	a0,800027c2 <usertrap+0xfa>
  prepare_return();
    8000277e:	e05ff0ef          	jal	80002582 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002782:	68a8                	ld	a0,80(s1)
    80002784:	8131                	srli	a0,a0,0xc
    80002786:	57fd                	li	a5,-1
    80002788:	17fe                	slli	a5,a5,0x3f
    8000278a:	8d5d                	or	a0,a0,a5
}
    8000278c:	60e2                	ld	ra,24(sp)
    8000278e:	6442                	ld	s0,16(sp)
    80002790:	64a2                	ld	s1,8(sp)
    80002792:	6902                	ld	s2,0(sp)
    80002794:	6105                	addi	sp,sp,32
    80002796:	8082                	ret
      kexit(-1);
    80002798:	557d                	li	a0,-1
    8000279a:	9b9ff0ef          	jal	80002152 <kexit>
    8000279e:	b7c1                	j	8000275e <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800027a0:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027a4:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800027a8:	164d                	addi	a2,a2,-13
    800027aa:	00163613          	seqz	a2,a2
    800027ae:	68a8                	ld	a0,80(s1)
    800027b0:	e21fe0ef          	jal	800015d0 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800027b4:	f169                	bnez	a0,80002776 <usertrap+0xae>
    800027b6:	b7a5                	j	8000271e <usertrap+0x56>
  if(killed(p))
    800027b8:	8526                	mv	a0,s1
    800027ba:	ac9ff0ef          	jal	80002282 <killed>
    800027be:	c511                	beqz	a0,800027ca <usertrap+0x102>
    800027c0:	a011                	j	800027c4 <usertrap+0xfc>
    800027c2:	4901                	li	s2,0
    kexit(-1);
    800027c4:	557d                	li	a0,-1
    800027c6:	98dff0ef          	jal	80002152 <kexit>
  if(which_dev == 2)
    800027ca:	4789                	li	a5,2
    800027cc:	faf919e3          	bne	s2,a5,8000277e <usertrap+0xb6>
    yield();
    800027d0:	84bff0ef          	jal	8000201a <yield>
    800027d4:	b76d                	j	8000277e <usertrap+0xb6>

00000000800027d6 <kerneltrap>:
{
    800027d6:	7179                	addi	sp,sp,-48
    800027d8:	f406                	sd	ra,40(sp)
    800027da:	f022                	sd	s0,32(sp)
    800027dc:	ec26                	sd	s1,24(sp)
    800027de:	e84a                	sd	s2,16(sp)
    800027e0:	e44e                	sd	s3,8(sp)
    800027e2:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027e4:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027e8:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027ec:	142027f3          	csrr	a5,scause
    800027f0:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    800027f2:	1004f793          	andi	a5,s1,256
    800027f6:	c795                	beqz	a5,80002822 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027f8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800027fc:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800027fe:	eb85                	bnez	a5,8000282e <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80002800:	e53ff0ef          	jal	80002652 <devintr>
    80002804:	c91d                	beqz	a0,8000283a <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002806:	4789                	li	a5,2
    80002808:	04f50a63          	beq	a0,a5,8000285c <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000280c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002810:	10049073          	csrw	sstatus,s1
}
    80002814:	70a2                	ld	ra,40(sp)
    80002816:	7402                	ld	s0,32(sp)
    80002818:	64e2                	ld	s1,24(sp)
    8000281a:	6942                	ld	s2,16(sp)
    8000281c:	69a2                	ld	s3,8(sp)
    8000281e:	6145                	addi	sp,sp,48
    80002820:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002822:	00005517          	auipc	a0,0x5
    80002826:	b2650513          	addi	a0,a0,-1242 # 80007348 <etext+0x348>
    8000282a:	ffbfd0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    8000282e:	00005517          	auipc	a0,0x5
    80002832:	b4250513          	addi	a0,a0,-1214 # 80007370 <etext+0x370>
    80002836:	feffd0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000283a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000283e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002842:	85ce                	mv	a1,s3
    80002844:	00005517          	auipc	a0,0x5
    80002848:	b4c50513          	addi	a0,a0,-1204 # 80007390 <etext+0x390>
    8000284c:	caffd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    80002850:	00005517          	auipc	a0,0x5
    80002854:	b6850513          	addi	a0,a0,-1176 # 800073b8 <etext+0x3b8>
    80002858:	fcdfd0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    8000285c:	9acff0ef          	jal	80001a08 <myproc>
    80002860:	d555                	beqz	a0,8000280c <kerneltrap+0x36>
    yield();
    80002862:	fb8ff0ef          	jal	8000201a <yield>
    80002866:	b75d                	j	8000280c <kerneltrap+0x36>

0000000080002868 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002868:	1101                	addi	sp,sp,-32
    8000286a:	ec06                	sd	ra,24(sp)
    8000286c:	e822                	sd	s0,16(sp)
    8000286e:	e426                	sd	s1,8(sp)
    80002870:	1000                	addi	s0,sp,32
    80002872:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002874:	994ff0ef          	jal	80001a08 <myproc>
  switch (n) {
    80002878:	4795                	li	a5,5
    8000287a:	0497e163          	bltu	a5,s1,800028bc <argraw+0x54>
    8000287e:	048a                	slli	s1,s1,0x2
    80002880:	00005717          	auipc	a4,0x5
    80002884:	f3870713          	addi	a4,a4,-200 # 800077b8 <states.0+0x30>
    80002888:	94ba                	add	s1,s1,a4
    8000288a:	409c                	lw	a5,0(s1)
    8000288c:	97ba                	add	a5,a5,a4
    8000288e:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002890:	6d3c                	ld	a5,88(a0)
    80002892:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002894:	60e2                	ld	ra,24(sp)
    80002896:	6442                	ld	s0,16(sp)
    80002898:	64a2                	ld	s1,8(sp)
    8000289a:	6105                	addi	sp,sp,32
    8000289c:	8082                	ret
    return p->trapframe->a1;
    8000289e:	6d3c                	ld	a5,88(a0)
    800028a0:	7fa8                	ld	a0,120(a5)
    800028a2:	bfcd                	j	80002894 <argraw+0x2c>
    return p->trapframe->a2;
    800028a4:	6d3c                	ld	a5,88(a0)
    800028a6:	63c8                	ld	a0,128(a5)
    800028a8:	b7f5                	j	80002894 <argraw+0x2c>
    return p->trapframe->a3;
    800028aa:	6d3c                	ld	a5,88(a0)
    800028ac:	67c8                	ld	a0,136(a5)
    800028ae:	b7dd                	j	80002894 <argraw+0x2c>
    return p->trapframe->a4;
    800028b0:	6d3c                	ld	a5,88(a0)
    800028b2:	6bc8                	ld	a0,144(a5)
    800028b4:	b7c5                	j	80002894 <argraw+0x2c>
    return p->trapframe->a5;
    800028b6:	6d3c                	ld	a5,88(a0)
    800028b8:	6fc8                	ld	a0,152(a5)
    800028ba:	bfe9                	j	80002894 <argraw+0x2c>
  panic("argraw");
    800028bc:	00005517          	auipc	a0,0x5
    800028c0:	b0c50513          	addi	a0,a0,-1268 # 800073c8 <etext+0x3c8>
    800028c4:	f61fd0ef          	jal	80000824 <panic>

00000000800028c8 <fetchaddr>:
{
    800028c8:	1101                	addi	sp,sp,-32
    800028ca:	ec06                	sd	ra,24(sp)
    800028cc:	e822                	sd	s0,16(sp)
    800028ce:	e426                	sd	s1,8(sp)
    800028d0:	e04a                	sd	s2,0(sp)
    800028d2:	1000                	addi	s0,sp,32
    800028d4:	84aa                	mv	s1,a0
    800028d6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800028d8:	930ff0ef          	jal	80001a08 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800028dc:	653c                	ld	a5,72(a0)
    800028de:	02f4f663          	bgeu	s1,a5,8000290a <fetchaddr+0x42>
    800028e2:	00848713          	addi	a4,s1,8
    800028e6:	02e7e463          	bltu	a5,a4,8000290e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    800028ea:	46a1                	li	a3,8
    800028ec:	8626                	mv	a2,s1
    800028ee:	85ca                	mv	a1,s2
    800028f0:	6928                	ld	a0,80(a0)
    800028f2:	e21fe0ef          	jal	80001712 <copyin>
    800028f6:	00a03533          	snez	a0,a0
    800028fa:	40a0053b          	negw	a0,a0
}
    800028fe:	60e2                	ld	ra,24(sp)
    80002900:	6442                	ld	s0,16(sp)
    80002902:	64a2                	ld	s1,8(sp)
    80002904:	6902                	ld	s2,0(sp)
    80002906:	6105                	addi	sp,sp,32
    80002908:	8082                	ret
    return -1;
    8000290a:	557d                	li	a0,-1
    8000290c:	bfcd                	j	800028fe <fetchaddr+0x36>
    8000290e:	557d                	li	a0,-1
    80002910:	b7fd                	j	800028fe <fetchaddr+0x36>

0000000080002912 <fetchstr>:
{
    80002912:	7179                	addi	sp,sp,-48
    80002914:	f406                	sd	ra,40(sp)
    80002916:	f022                	sd	s0,32(sp)
    80002918:	ec26                	sd	s1,24(sp)
    8000291a:	e84a                	sd	s2,16(sp)
    8000291c:	e44e                	sd	s3,8(sp)
    8000291e:	1800                	addi	s0,sp,48
    80002920:	89aa                	mv	s3,a0
    80002922:	84ae                	mv	s1,a1
    80002924:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002926:	8e2ff0ef          	jal	80001a08 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    8000292a:	86ca                	mv	a3,s2
    8000292c:	864e                	mv	a2,s3
    8000292e:	85a6                	mv	a1,s1
    80002930:	6928                	ld	a0,80(a0)
    80002932:	bc7fe0ef          	jal	800014f8 <copyinstr>
    80002936:	00054c63          	bltz	a0,8000294e <fetchstr+0x3c>
  return strlen(buf);
    8000293a:	8526                	mv	a0,s1
    8000293c:	d46fe0ef          	jal	80000e82 <strlen>
}
    80002940:	70a2                	ld	ra,40(sp)
    80002942:	7402                	ld	s0,32(sp)
    80002944:	64e2                	ld	s1,24(sp)
    80002946:	6942                	ld	s2,16(sp)
    80002948:	69a2                	ld	s3,8(sp)
    8000294a:	6145                	addi	sp,sp,48
    8000294c:	8082                	ret
    return -1;
    8000294e:	557d                	li	a0,-1
    80002950:	bfc5                	j	80002940 <fetchstr+0x2e>

0000000080002952 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002952:	1101                	addi	sp,sp,-32
    80002954:	ec06                	sd	ra,24(sp)
    80002956:	e822                	sd	s0,16(sp)
    80002958:	e426                	sd	s1,8(sp)
    8000295a:	1000                	addi	s0,sp,32
    8000295c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000295e:	f0bff0ef          	jal	80002868 <argraw>
    80002962:	c088                	sw	a0,0(s1)
}
    80002964:	60e2                	ld	ra,24(sp)
    80002966:	6442                	ld	s0,16(sp)
    80002968:	64a2                	ld	s1,8(sp)
    8000296a:	6105                	addi	sp,sp,32
    8000296c:	8082                	ret

000000008000296e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000296e:	1101                	addi	sp,sp,-32
    80002970:	ec06                	sd	ra,24(sp)
    80002972:	e822                	sd	s0,16(sp)
    80002974:	e426                	sd	s1,8(sp)
    80002976:	1000                	addi	s0,sp,32
    80002978:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000297a:	eefff0ef          	jal	80002868 <argraw>
    8000297e:	e088                	sd	a0,0(s1)
}
    80002980:	60e2                	ld	ra,24(sp)
    80002982:	6442                	ld	s0,16(sp)
    80002984:	64a2                	ld	s1,8(sp)
    80002986:	6105                	addi	sp,sp,32
    80002988:	8082                	ret

000000008000298a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    8000298a:	1101                	addi	sp,sp,-32
    8000298c:	ec06                	sd	ra,24(sp)
    8000298e:	e822                	sd	s0,16(sp)
    80002990:	e426                	sd	s1,8(sp)
    80002992:	e04a                	sd	s2,0(sp)
    80002994:	1000                	addi	s0,sp,32
    80002996:	892e                	mv	s2,a1
    80002998:	84b2                	mv	s1,a2
  *ip = argraw(n);
    8000299a:	ecfff0ef          	jal	80002868 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    8000299e:	8626                	mv	a2,s1
    800029a0:	85ca                	mv	a1,s2
    800029a2:	f71ff0ef          	jal	80002912 <fetchstr>
}
    800029a6:	60e2                	ld	ra,24(sp)
    800029a8:	6442                	ld	s0,16(sp)
    800029aa:	64a2                	ld	s1,8(sp)
    800029ac:	6902                	ld	s2,0(sp)
    800029ae:	6105                	addi	sp,sp,32
    800029b0:	8082                	ret

00000000800029b2 <syscall>:
[SYS_nice]    sys_nice,                 //nice syscall table implementation
};

void
syscall(void)
{
    800029b2:	1101                	addi	sp,sp,-32
    800029b4:	ec06                	sd	ra,24(sp)
    800029b6:	e822                	sd	s0,16(sp)
    800029b8:	e426                	sd	s1,8(sp)
    800029ba:	e04a                	sd	s2,0(sp)
    800029bc:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800029be:	84aff0ef          	jal	80001a08 <myproc>
    800029c2:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800029c4:	05853903          	ld	s2,88(a0)
    800029c8:	0a893783          	ld	a5,168(s2)
    800029cc:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800029d0:	37fd                	addiw	a5,a5,-1
    800029d2:	475d                	li	a4,23
    800029d4:	00f76f63          	bltu	a4,a5,800029f2 <syscall+0x40>
    800029d8:	00369713          	slli	a4,a3,0x3
    800029dc:	00005797          	auipc	a5,0x5
    800029e0:	df478793          	addi	a5,a5,-524 # 800077d0 <syscalls>
    800029e4:	97ba                	add	a5,a5,a4
    800029e6:	639c                	ld	a5,0(a5)
    800029e8:	c789                	beqz	a5,800029f2 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    800029ea:	9782                	jalr	a5
    800029ec:	06a93823          	sd	a0,112(s2)
    800029f0:	a829                	j	80002a0a <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    800029f2:	15848613          	addi	a2,s1,344
    800029f6:	588c                	lw	a1,48(s1)
    800029f8:	00005517          	auipc	a0,0x5
    800029fc:	9d850513          	addi	a0,a0,-1576 # 800073d0 <etext+0x3d0>
    80002a00:	afbfd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002a04:	6cbc                	ld	a5,88(s1)
    80002a06:	577d                	li	a4,-1
    80002a08:	fbb8                	sd	a4,112(a5)
  }
}
    80002a0a:	60e2                	ld	ra,24(sp)
    80002a0c:	6442                	ld	s0,16(sp)
    80002a0e:	64a2                	ld	s1,8(sp)
    80002a10:	6902                	ld	s2,0(sp)
    80002a12:	6105                	addi	sp,sp,32
    80002a14:	8082                	ret

0000000080002a16 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002a16:	1101                	addi	sp,sp,-32
    80002a18:	ec06                	sd	ra,24(sp)
    80002a1a:	e822                	sd	s0,16(sp)
    80002a1c:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002a1e:	fec40593          	addi	a1,s0,-20
    80002a22:	4501                	li	a0,0
    80002a24:	f2fff0ef          	jal	80002952 <argint>
  kexit(n);
    80002a28:	fec42503          	lw	a0,-20(s0)
    80002a2c:	f26ff0ef          	jal	80002152 <kexit>
  return 0;  // not reached
}
    80002a30:	4501                	li	a0,0
    80002a32:	60e2                	ld	ra,24(sp)
    80002a34:	6442                	ld	s0,16(sp)
    80002a36:	6105                	addi	sp,sp,32
    80002a38:	8082                	ret

0000000080002a3a <sys_getpid>:

uint64
sys_getpid(void)
{
    80002a3a:	1141                	addi	sp,sp,-16
    80002a3c:	e406                	sd	ra,8(sp)
    80002a3e:	e022                	sd	s0,0(sp)
    80002a40:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002a42:	fc7fe0ef          	jal	80001a08 <myproc>
}
    80002a46:	5908                	lw	a0,48(a0)
    80002a48:	60a2                	ld	ra,8(sp)
    80002a4a:	6402                	ld	s0,0(sp)
    80002a4c:	0141                	addi	sp,sp,16
    80002a4e:	8082                	ret

0000000080002a50 <sys_fork>:

uint64
sys_fork(void)
{
    80002a50:	1141                	addi	sp,sp,-16
    80002a52:	e406                	sd	ra,8(sp)
    80002a54:	e022                	sd	s0,0(sp)
    80002a56:	0800                	addi	s0,sp,16
  return kfork();
    80002a58:	b20ff0ef          	jal	80001d78 <kfork>
}
    80002a5c:	60a2                	ld	ra,8(sp)
    80002a5e:	6402                	ld	s0,0(sp)
    80002a60:	0141                	addi	sp,sp,16
    80002a62:	8082                	ret

0000000080002a64 <sys_wait>:

uint64
sys_wait(void)
{
    80002a64:	1101                	addi	sp,sp,-32
    80002a66:	ec06                	sd	ra,24(sp)
    80002a68:	e822                	sd	s0,16(sp)
    80002a6a:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a6c:	fe840593          	addi	a1,s0,-24
    80002a70:	4501                	li	a0,0
    80002a72:	efdff0ef          	jal	8000296e <argaddr>
  return kwait(p);
    80002a76:	fe843503          	ld	a0,-24(s0)
    80002a7a:	833ff0ef          	jal	800022ac <kwait>
}
    80002a7e:	60e2                	ld	ra,24(sp)
    80002a80:	6442                	ld	s0,16(sp)
    80002a82:	6105                	addi	sp,sp,32
    80002a84:	8082                	ret

0000000080002a86 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002a86:	7179                	addi	sp,sp,-48
    80002a88:	f406                	sd	ra,40(sp)
    80002a8a:	f022                	sd	s0,32(sp)
    80002a8c:	ec26                	sd	s1,24(sp)
    80002a8e:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002a90:	fd840593          	addi	a1,s0,-40
    80002a94:	4501                	li	a0,0
    80002a96:	ebdff0ef          	jal	80002952 <argint>
  argint(1, &t);
    80002a9a:	fdc40593          	addi	a1,s0,-36
    80002a9e:	4505                	li	a0,1
    80002aa0:	eb3ff0ef          	jal	80002952 <argint>
  addr = myproc()->sz;
    80002aa4:	f65fe0ef          	jal	80001a08 <myproc>
    80002aa8:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002aaa:	fdc42703          	lw	a4,-36(s0)
    80002aae:	4785                	li	a5,1
    80002ab0:	02f70763          	beq	a4,a5,80002ade <sys_sbrk+0x58>
    80002ab4:	fd842783          	lw	a5,-40(s0)
    80002ab8:	0207c363          	bltz	a5,80002ade <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002abc:	97a6                	add	a5,a5,s1
      return -1;
    if(addr + n > TRAPFRAME)
    80002abe:	02000737          	lui	a4,0x2000
    80002ac2:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002ac4:	0736                	slli	a4,a4,0xd
    80002ac6:	02f76a63          	bltu	a4,a5,80002afa <sys_sbrk+0x74>
    80002aca:	0297e863          	bltu	a5,s1,80002afa <sys_sbrk+0x74>
      return -1;
    myproc()->sz += n;
    80002ace:	f3bfe0ef          	jal	80001a08 <myproc>
    80002ad2:	fd842703          	lw	a4,-40(s0)
    80002ad6:	653c                	ld	a5,72(a0)
    80002ad8:	97ba                	add	a5,a5,a4
    80002ada:	e53c                	sd	a5,72(a0)
    80002adc:	a039                	j	80002aea <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    80002ade:	fd842503          	lw	a0,-40(s0)
    80002ae2:	a34ff0ef          	jal	80001d16 <growproc>
    80002ae6:	00054863          	bltz	a0,80002af6 <sys_sbrk+0x70>
  }
  return addr;
}
    80002aea:	8526                	mv	a0,s1
    80002aec:	70a2                	ld	ra,40(sp)
    80002aee:	7402                	ld	s0,32(sp)
    80002af0:	64e2                	ld	s1,24(sp)
    80002af2:	6145                	addi	sp,sp,48
    80002af4:	8082                	ret
      return -1;
    80002af6:	54fd                	li	s1,-1
    80002af8:	bfcd                	j	80002aea <sys_sbrk+0x64>
      return -1;
    80002afa:	54fd                	li	s1,-1
    80002afc:	b7fd                	j	80002aea <sys_sbrk+0x64>

0000000080002afe <sys_pause>:

uint64
sys_pause(void)
{
    80002afe:	7139                	addi	sp,sp,-64
    80002b00:	fc06                	sd	ra,56(sp)
    80002b02:	f822                	sd	s0,48(sp)
    80002b04:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002b06:	fcc40593          	addi	a1,s0,-52
    80002b0a:	4501                	li	a0,0
    80002b0c:	e47ff0ef          	jal	80002952 <argint>
  if(n < 0)
    80002b10:	fcc42783          	lw	a5,-52(s0)
    80002b14:	0607c863          	bltz	a5,80002b84 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002b18:	00015517          	auipc	a0,0x15
    80002b1c:	74050513          	addi	a0,a0,1856 # 80018258 <tickslock>
    80002b20:	908fe0ef          	jal	80000c28 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002b24:	fcc42783          	lw	a5,-52(s0)
    80002b28:	c3b9                	beqz	a5,80002b6e <sys_pause+0x70>
    80002b2a:	f426                	sd	s1,40(sp)
    80002b2c:	f04a                	sd	s2,32(sp)
    80002b2e:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002b30:	00007997          	auipc	s3,0x7
    80002b34:	7f09a983          	lw	s3,2032(s3) # 8000a320 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002b38:	00015917          	auipc	s2,0x15
    80002b3c:	72090913          	addi	s2,s2,1824 # 80018258 <tickslock>
    80002b40:	00007497          	auipc	s1,0x7
    80002b44:	7e048493          	addi	s1,s1,2016 # 8000a320 <ticks>
    if(killed(myproc())){
    80002b48:	ec1fe0ef          	jal	80001a08 <myproc>
    80002b4c:	f36ff0ef          	jal	80002282 <killed>
    80002b50:	ed0d                	bnez	a0,80002b8a <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002b52:	85ca                	mv	a1,s2
    80002b54:	8526                	mv	a0,s1
    80002b56:	cf0ff0ef          	jal	80002046 <sleep>
  while(ticks - ticks0 < n){
    80002b5a:	409c                	lw	a5,0(s1)
    80002b5c:	413787bb          	subw	a5,a5,s3
    80002b60:	fcc42703          	lw	a4,-52(s0)
    80002b64:	fee7e2e3          	bltu	a5,a4,80002b48 <sys_pause+0x4a>
    80002b68:	74a2                	ld	s1,40(sp)
    80002b6a:	7902                	ld	s2,32(sp)
    80002b6c:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002b6e:	00015517          	auipc	a0,0x15
    80002b72:	6ea50513          	addi	a0,a0,1770 # 80018258 <tickslock>
    80002b76:	946fe0ef          	jal	80000cbc <release>
  return 0;
    80002b7a:	4501                	li	a0,0
}
    80002b7c:	70e2                	ld	ra,56(sp)
    80002b7e:	7442                	ld	s0,48(sp)
    80002b80:	6121                	addi	sp,sp,64
    80002b82:	8082                	ret
    n = 0;
    80002b84:	fc042623          	sw	zero,-52(s0)
    80002b88:	bf41                	j	80002b18 <sys_pause+0x1a>
      release(&tickslock);
    80002b8a:	00015517          	auipc	a0,0x15
    80002b8e:	6ce50513          	addi	a0,a0,1742 # 80018258 <tickslock>
    80002b92:	92afe0ef          	jal	80000cbc <release>
      return -1;
    80002b96:	557d                	li	a0,-1
    80002b98:	74a2                	ld	s1,40(sp)
    80002b9a:	7902                	ld	s2,32(sp)
    80002b9c:	69e2                	ld	s3,24(sp)
    80002b9e:	bff9                	j	80002b7c <sys_pause+0x7e>

0000000080002ba0 <sys_kill>:

uint64
sys_kill(void)
{
    80002ba0:	1101                	addi	sp,sp,-32
    80002ba2:	ec06                	sd	ra,24(sp)
    80002ba4:	e822                	sd	s0,16(sp)
    80002ba6:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002ba8:	fec40593          	addi	a1,s0,-20
    80002bac:	4501                	li	a0,0
    80002bae:	da5ff0ef          	jal	80002952 <argint>
  return kkill(pid);
    80002bb2:	fec42503          	lw	a0,-20(s0)
    80002bb6:	e42ff0ef          	jal	800021f8 <kkill>
}
    80002bba:	60e2                	ld	ra,24(sp)
    80002bbc:	6442                	ld	s0,16(sp)
    80002bbe:	6105                	addi	sp,sp,32
    80002bc0:	8082                	ret

0000000080002bc2 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002bc2:	1101                	addi	sp,sp,-32
    80002bc4:	ec06                	sd	ra,24(sp)
    80002bc6:	e822                	sd	s0,16(sp)
    80002bc8:	e426                	sd	s1,8(sp)
    80002bca:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002bcc:	00015517          	auipc	a0,0x15
    80002bd0:	68c50513          	addi	a0,a0,1676 # 80018258 <tickslock>
    80002bd4:	854fe0ef          	jal	80000c28 <acquire>
  xticks = ticks;
    80002bd8:	00007797          	auipc	a5,0x7
    80002bdc:	7487a783          	lw	a5,1864(a5) # 8000a320 <ticks>
    80002be0:	84be                	mv	s1,a5
  release(&tickslock);
    80002be2:	00015517          	auipc	a0,0x15
    80002be6:	67650513          	addi	a0,a0,1654 # 80018258 <tickslock>
    80002bea:	8d2fe0ef          	jal	80000cbc <release>
  return xticks;
}
    80002bee:	02049513          	slli	a0,s1,0x20
    80002bf2:	9101                	srli	a0,a0,0x20
    80002bf4:	60e2                	ld	ra,24(sp)
    80002bf6:	6442                	ld	s0,16(sp)
    80002bf8:	64a2                	ld	s1,8(sp)
    80002bfa:	6105                	addi	sp,sp,32
    80002bfc:	8082                	ret

0000000080002bfe <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002bfe:	7179                	addi	sp,sp,-48
    80002c00:	f406                	sd	ra,40(sp)
    80002c02:	f022                	sd	s0,32(sp)
    80002c04:	ec26                	sd	s1,24(sp)
    80002c06:	e84a                	sd	s2,16(sp)
    80002c08:	e44e                	sd	s3,8(sp)
    80002c0a:	e052                	sd	s4,0(sp)
    80002c0c:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002c0e:	00004597          	auipc	a1,0x4
    80002c12:	7e258593          	addi	a1,a1,2018 # 800073f0 <etext+0x3f0>
    80002c16:	00015517          	auipc	a0,0x15
    80002c1a:	65a50513          	addi	a0,a0,1626 # 80018270 <bcache>
    80002c1e:	f81fd0ef          	jal	80000b9e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002c22:	0001d797          	auipc	a5,0x1d
    80002c26:	64e78793          	addi	a5,a5,1614 # 80020270 <bcache+0x8000>
    80002c2a:	0001e717          	auipc	a4,0x1e
    80002c2e:	8ae70713          	addi	a4,a4,-1874 # 800204d8 <bcache+0x8268>
    80002c32:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002c36:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002c3a:	00015497          	auipc	s1,0x15
    80002c3e:	64e48493          	addi	s1,s1,1614 # 80018288 <bcache+0x18>
    b->next = bcache.head.next;
    80002c42:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002c44:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002c46:	00004a17          	auipc	s4,0x4
    80002c4a:	7b2a0a13          	addi	s4,s4,1970 # 800073f8 <etext+0x3f8>
    b->next = bcache.head.next;
    80002c4e:	2b893783          	ld	a5,696(s2)
    80002c52:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002c54:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002c58:	85d2                	mv	a1,s4
    80002c5a:	01048513          	addi	a0,s1,16
    80002c5e:	328010ef          	jal	80003f86 <initsleeplock>
    bcache.head.next->prev = b;
    80002c62:	2b893783          	ld	a5,696(s2)
    80002c66:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002c68:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002c6c:	45848493          	addi	s1,s1,1112
    80002c70:	fd349fe3          	bne	s1,s3,80002c4e <binit+0x50>
  }
}
    80002c74:	70a2                	ld	ra,40(sp)
    80002c76:	7402                	ld	s0,32(sp)
    80002c78:	64e2                	ld	s1,24(sp)
    80002c7a:	6942                	ld	s2,16(sp)
    80002c7c:	69a2                	ld	s3,8(sp)
    80002c7e:	6a02                	ld	s4,0(sp)
    80002c80:	6145                	addi	sp,sp,48
    80002c82:	8082                	ret

0000000080002c84 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002c84:	7179                	addi	sp,sp,-48
    80002c86:	f406                	sd	ra,40(sp)
    80002c88:	f022                	sd	s0,32(sp)
    80002c8a:	ec26                	sd	s1,24(sp)
    80002c8c:	e84a                	sd	s2,16(sp)
    80002c8e:	e44e                	sd	s3,8(sp)
    80002c90:	1800                	addi	s0,sp,48
    80002c92:	892a                	mv	s2,a0
    80002c94:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c96:	00015517          	auipc	a0,0x15
    80002c9a:	5da50513          	addi	a0,a0,1498 # 80018270 <bcache>
    80002c9e:	f8bfd0ef          	jal	80000c28 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002ca2:	0001e497          	auipc	s1,0x1e
    80002ca6:	8864b483          	ld	s1,-1914(s1) # 80020528 <bcache+0x82b8>
    80002caa:	0001e797          	auipc	a5,0x1e
    80002cae:	82e78793          	addi	a5,a5,-2002 # 800204d8 <bcache+0x8268>
    80002cb2:	02f48b63          	beq	s1,a5,80002ce8 <bread+0x64>
    80002cb6:	873e                	mv	a4,a5
    80002cb8:	a021                	j	80002cc0 <bread+0x3c>
    80002cba:	68a4                	ld	s1,80(s1)
    80002cbc:	02e48663          	beq	s1,a4,80002ce8 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002cc0:	449c                	lw	a5,8(s1)
    80002cc2:	ff279ce3          	bne	a5,s2,80002cba <bread+0x36>
    80002cc6:	44dc                	lw	a5,12(s1)
    80002cc8:	ff3799e3          	bne	a5,s3,80002cba <bread+0x36>
      b->refcnt++;
    80002ccc:	40bc                	lw	a5,64(s1)
    80002cce:	2785                	addiw	a5,a5,1
    80002cd0:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002cd2:	00015517          	auipc	a0,0x15
    80002cd6:	59e50513          	addi	a0,a0,1438 # 80018270 <bcache>
    80002cda:	fe3fd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002cde:	01048513          	addi	a0,s1,16
    80002ce2:	2da010ef          	jal	80003fbc <acquiresleep>
      return b;
    80002ce6:	a889                	j	80002d38 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002ce8:	0001e497          	auipc	s1,0x1e
    80002cec:	8384b483          	ld	s1,-1992(s1) # 80020520 <bcache+0x82b0>
    80002cf0:	0001d797          	auipc	a5,0x1d
    80002cf4:	7e878793          	addi	a5,a5,2024 # 800204d8 <bcache+0x8268>
    80002cf8:	00f48863          	beq	s1,a5,80002d08 <bread+0x84>
    80002cfc:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002cfe:	40bc                	lw	a5,64(s1)
    80002d00:	cb91                	beqz	a5,80002d14 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002d02:	64a4                	ld	s1,72(s1)
    80002d04:	fee49de3          	bne	s1,a4,80002cfe <bread+0x7a>
  panic("bget: no buffers");
    80002d08:	00004517          	auipc	a0,0x4
    80002d0c:	6f850513          	addi	a0,a0,1784 # 80007400 <etext+0x400>
    80002d10:	b15fd0ef          	jal	80000824 <panic>
      b->dev = dev;
    80002d14:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002d18:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002d1c:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002d20:	4785                	li	a5,1
    80002d22:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002d24:	00015517          	auipc	a0,0x15
    80002d28:	54c50513          	addi	a0,a0,1356 # 80018270 <bcache>
    80002d2c:	f91fd0ef          	jal	80000cbc <release>
      acquiresleep(&b->lock);
    80002d30:	01048513          	addi	a0,s1,16
    80002d34:	288010ef          	jal	80003fbc <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002d38:	409c                	lw	a5,0(s1)
    80002d3a:	cb89                	beqz	a5,80002d4c <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002d3c:	8526                	mv	a0,s1
    80002d3e:	70a2                	ld	ra,40(sp)
    80002d40:	7402                	ld	s0,32(sp)
    80002d42:	64e2                	ld	s1,24(sp)
    80002d44:	6942                	ld	s2,16(sp)
    80002d46:	69a2                	ld	s3,8(sp)
    80002d48:	6145                	addi	sp,sp,48
    80002d4a:	8082                	ret
    virtio_disk_rw(b, 0);
    80002d4c:	4581                	li	a1,0
    80002d4e:	8526                	mv	a0,s1
    80002d50:	2f1020ef          	jal	80005840 <virtio_disk_rw>
    b->valid = 1;
    80002d54:	4785                	li	a5,1
    80002d56:	c09c                	sw	a5,0(s1)
  return b;
    80002d58:	b7d5                	j	80002d3c <bread+0xb8>

0000000080002d5a <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002d5a:	1101                	addi	sp,sp,-32
    80002d5c:	ec06                	sd	ra,24(sp)
    80002d5e:	e822                	sd	s0,16(sp)
    80002d60:	e426                	sd	s1,8(sp)
    80002d62:	1000                	addi	s0,sp,32
    80002d64:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d66:	0541                	addi	a0,a0,16
    80002d68:	2d2010ef          	jal	8000403a <holdingsleep>
    80002d6c:	c911                	beqz	a0,80002d80 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002d6e:	4585                	li	a1,1
    80002d70:	8526                	mv	a0,s1
    80002d72:	2cf020ef          	jal	80005840 <virtio_disk_rw>
}
    80002d76:	60e2                	ld	ra,24(sp)
    80002d78:	6442                	ld	s0,16(sp)
    80002d7a:	64a2                	ld	s1,8(sp)
    80002d7c:	6105                	addi	sp,sp,32
    80002d7e:	8082                	ret
    panic("bwrite");
    80002d80:	00004517          	auipc	a0,0x4
    80002d84:	69850513          	addi	a0,a0,1688 # 80007418 <etext+0x418>
    80002d88:	a9dfd0ef          	jal	80000824 <panic>

0000000080002d8c <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d8c:	1101                	addi	sp,sp,-32
    80002d8e:	ec06                	sd	ra,24(sp)
    80002d90:	e822                	sd	s0,16(sp)
    80002d92:	e426                	sd	s1,8(sp)
    80002d94:	e04a                	sd	s2,0(sp)
    80002d96:	1000                	addi	s0,sp,32
    80002d98:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d9a:	01050913          	addi	s2,a0,16
    80002d9e:	854a                	mv	a0,s2
    80002da0:	29a010ef          	jal	8000403a <holdingsleep>
    80002da4:	c125                	beqz	a0,80002e04 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002da6:	854a                	mv	a0,s2
    80002da8:	25a010ef          	jal	80004002 <releasesleep>

  acquire(&bcache.lock);
    80002dac:	00015517          	auipc	a0,0x15
    80002db0:	4c450513          	addi	a0,a0,1220 # 80018270 <bcache>
    80002db4:	e75fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002db8:	40bc                	lw	a5,64(s1)
    80002dba:	37fd                	addiw	a5,a5,-1
    80002dbc:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002dbe:	e79d                	bnez	a5,80002dec <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002dc0:	68b8                	ld	a4,80(s1)
    80002dc2:	64bc                	ld	a5,72(s1)
    80002dc4:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002dc6:	68b8                	ld	a4,80(s1)
    80002dc8:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002dca:	0001d797          	auipc	a5,0x1d
    80002dce:	4a678793          	addi	a5,a5,1190 # 80020270 <bcache+0x8000>
    80002dd2:	2b87b703          	ld	a4,696(a5)
    80002dd6:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002dd8:	0001d717          	auipc	a4,0x1d
    80002ddc:	70070713          	addi	a4,a4,1792 # 800204d8 <bcache+0x8268>
    80002de0:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002de2:	2b87b703          	ld	a4,696(a5)
    80002de6:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002de8:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002dec:	00015517          	auipc	a0,0x15
    80002df0:	48450513          	addi	a0,a0,1156 # 80018270 <bcache>
    80002df4:	ec9fd0ef          	jal	80000cbc <release>
}
    80002df8:	60e2                	ld	ra,24(sp)
    80002dfa:	6442                	ld	s0,16(sp)
    80002dfc:	64a2                	ld	s1,8(sp)
    80002dfe:	6902                	ld	s2,0(sp)
    80002e00:	6105                	addi	sp,sp,32
    80002e02:	8082                	ret
    panic("brelse");
    80002e04:	00004517          	auipc	a0,0x4
    80002e08:	61c50513          	addi	a0,a0,1564 # 80007420 <etext+0x420>
    80002e0c:	a19fd0ef          	jal	80000824 <panic>

0000000080002e10 <bpin>:

void
bpin(struct buf *b) {
    80002e10:	1101                	addi	sp,sp,-32
    80002e12:	ec06                	sd	ra,24(sp)
    80002e14:	e822                	sd	s0,16(sp)
    80002e16:	e426                	sd	s1,8(sp)
    80002e18:	1000                	addi	s0,sp,32
    80002e1a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e1c:	00015517          	auipc	a0,0x15
    80002e20:	45450513          	addi	a0,a0,1108 # 80018270 <bcache>
    80002e24:	e05fd0ef          	jal	80000c28 <acquire>
  b->refcnt++;
    80002e28:	40bc                	lw	a5,64(s1)
    80002e2a:	2785                	addiw	a5,a5,1
    80002e2c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e2e:	00015517          	auipc	a0,0x15
    80002e32:	44250513          	addi	a0,a0,1090 # 80018270 <bcache>
    80002e36:	e87fd0ef          	jal	80000cbc <release>
}
    80002e3a:	60e2                	ld	ra,24(sp)
    80002e3c:	6442                	ld	s0,16(sp)
    80002e3e:	64a2                	ld	s1,8(sp)
    80002e40:	6105                	addi	sp,sp,32
    80002e42:	8082                	ret

0000000080002e44 <bunpin>:

void
bunpin(struct buf *b) {
    80002e44:	1101                	addi	sp,sp,-32
    80002e46:	ec06                	sd	ra,24(sp)
    80002e48:	e822                	sd	s0,16(sp)
    80002e4a:	e426                	sd	s1,8(sp)
    80002e4c:	1000                	addi	s0,sp,32
    80002e4e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e50:	00015517          	auipc	a0,0x15
    80002e54:	42050513          	addi	a0,a0,1056 # 80018270 <bcache>
    80002e58:	dd1fd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002e5c:	40bc                	lw	a5,64(s1)
    80002e5e:	37fd                	addiw	a5,a5,-1
    80002e60:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e62:	00015517          	auipc	a0,0x15
    80002e66:	40e50513          	addi	a0,a0,1038 # 80018270 <bcache>
    80002e6a:	e53fd0ef          	jal	80000cbc <release>
}
    80002e6e:	60e2                	ld	ra,24(sp)
    80002e70:	6442                	ld	s0,16(sp)
    80002e72:	64a2                	ld	s1,8(sp)
    80002e74:	6105                	addi	sp,sp,32
    80002e76:	8082                	ret

0000000080002e78 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002e78:	1101                	addi	sp,sp,-32
    80002e7a:	ec06                	sd	ra,24(sp)
    80002e7c:	e822                	sd	s0,16(sp)
    80002e7e:	e426                	sd	s1,8(sp)
    80002e80:	e04a                	sd	s2,0(sp)
    80002e82:	1000                	addi	s0,sp,32
    80002e84:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e86:	00d5d79b          	srliw	a5,a1,0xd
    80002e8a:	0001e597          	auipc	a1,0x1e
    80002e8e:	ac25a583          	lw	a1,-1342(a1) # 8002094c <sb+0x1c>
    80002e92:	9dbd                	addw	a1,a1,a5
    80002e94:	df1ff0ef          	jal	80002c84 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e98:	0074f713          	andi	a4,s1,7
    80002e9c:	4785                	li	a5,1
    80002e9e:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002ea2:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002ea4:	90d9                	srli	s1,s1,0x36
    80002ea6:	00950733          	add	a4,a0,s1
    80002eaa:	05874703          	lbu	a4,88(a4)
    80002eae:	00e7f6b3          	and	a3,a5,a4
    80002eb2:	c29d                	beqz	a3,80002ed8 <bfree+0x60>
    80002eb4:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002eb6:	94aa                	add	s1,s1,a0
    80002eb8:	fff7c793          	not	a5,a5
    80002ebc:	8f7d                	and	a4,a4,a5
    80002ebe:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002ec2:	000010ef          	jal	80003ec2 <log_write>
  brelse(bp);
    80002ec6:	854a                	mv	a0,s2
    80002ec8:	ec5ff0ef          	jal	80002d8c <brelse>
}
    80002ecc:	60e2                	ld	ra,24(sp)
    80002ece:	6442                	ld	s0,16(sp)
    80002ed0:	64a2                	ld	s1,8(sp)
    80002ed2:	6902                	ld	s2,0(sp)
    80002ed4:	6105                	addi	sp,sp,32
    80002ed6:	8082                	ret
    panic("freeing free block");
    80002ed8:	00004517          	auipc	a0,0x4
    80002edc:	55050513          	addi	a0,a0,1360 # 80007428 <etext+0x428>
    80002ee0:	945fd0ef          	jal	80000824 <panic>

0000000080002ee4 <balloc>:
{
    80002ee4:	715d                	addi	sp,sp,-80
    80002ee6:	e486                	sd	ra,72(sp)
    80002ee8:	e0a2                	sd	s0,64(sp)
    80002eea:	fc26                	sd	s1,56(sp)
    80002eec:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002eee:	0001e797          	auipc	a5,0x1e
    80002ef2:	a467a783          	lw	a5,-1466(a5) # 80020934 <sb+0x4>
    80002ef6:	0e078263          	beqz	a5,80002fda <balloc+0xf6>
    80002efa:	f84a                	sd	s2,48(sp)
    80002efc:	f44e                	sd	s3,40(sp)
    80002efe:	f052                	sd	s4,32(sp)
    80002f00:	ec56                	sd	s5,24(sp)
    80002f02:	e85a                	sd	s6,16(sp)
    80002f04:	e45e                	sd	s7,8(sp)
    80002f06:	e062                	sd	s8,0(sp)
    80002f08:	8baa                	mv	s7,a0
    80002f0a:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002f0c:	0001eb17          	auipc	s6,0x1e
    80002f10:	a24b0b13          	addi	s6,s6,-1500 # 80020930 <sb>
      m = 1 << (bi % 8);
    80002f14:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f16:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002f18:	6c09                	lui	s8,0x2
    80002f1a:	a09d                	j	80002f80 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002f1c:	97ca                	add	a5,a5,s2
    80002f1e:	8e55                	or	a2,a2,a3
    80002f20:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002f24:	854a                	mv	a0,s2
    80002f26:	79d000ef          	jal	80003ec2 <log_write>
        brelse(bp);
    80002f2a:	854a                	mv	a0,s2
    80002f2c:	e61ff0ef          	jal	80002d8c <brelse>
  bp = bread(dev, bno);
    80002f30:	85a6                	mv	a1,s1
    80002f32:	855e                	mv	a0,s7
    80002f34:	d51ff0ef          	jal	80002c84 <bread>
    80002f38:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002f3a:	40000613          	li	a2,1024
    80002f3e:	4581                	li	a1,0
    80002f40:	05850513          	addi	a0,a0,88
    80002f44:	db5fd0ef          	jal	80000cf8 <memset>
  log_write(bp);
    80002f48:	854a                	mv	a0,s2
    80002f4a:	779000ef          	jal	80003ec2 <log_write>
  brelse(bp);
    80002f4e:	854a                	mv	a0,s2
    80002f50:	e3dff0ef          	jal	80002d8c <brelse>
}
    80002f54:	7942                	ld	s2,48(sp)
    80002f56:	79a2                	ld	s3,40(sp)
    80002f58:	7a02                	ld	s4,32(sp)
    80002f5a:	6ae2                	ld	s5,24(sp)
    80002f5c:	6b42                	ld	s6,16(sp)
    80002f5e:	6ba2                	ld	s7,8(sp)
    80002f60:	6c02                	ld	s8,0(sp)
}
    80002f62:	8526                	mv	a0,s1
    80002f64:	60a6                	ld	ra,72(sp)
    80002f66:	6406                	ld	s0,64(sp)
    80002f68:	74e2                	ld	s1,56(sp)
    80002f6a:	6161                	addi	sp,sp,80
    80002f6c:	8082                	ret
    brelse(bp);
    80002f6e:	854a                	mv	a0,s2
    80002f70:	e1dff0ef          	jal	80002d8c <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002f74:	015c0abb          	addw	s5,s8,s5
    80002f78:	004b2783          	lw	a5,4(s6)
    80002f7c:	04faf863          	bgeu	s5,a5,80002fcc <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002f80:	40dad59b          	sraiw	a1,s5,0xd
    80002f84:	01cb2783          	lw	a5,28(s6)
    80002f88:	9dbd                	addw	a1,a1,a5
    80002f8a:	855e                	mv	a0,s7
    80002f8c:	cf9ff0ef          	jal	80002c84 <bread>
    80002f90:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f92:	004b2503          	lw	a0,4(s6)
    80002f96:	84d6                	mv	s1,s5
    80002f98:	4701                	li	a4,0
    80002f9a:	fca4fae3          	bgeu	s1,a0,80002f6e <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f9e:	00777693          	andi	a3,a4,7
    80002fa2:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002fa6:	41f7579b          	sraiw	a5,a4,0x1f
    80002faa:	01d7d79b          	srliw	a5,a5,0x1d
    80002fae:	9fb9                	addw	a5,a5,a4
    80002fb0:	4037d79b          	sraiw	a5,a5,0x3
    80002fb4:	00f90633          	add	a2,s2,a5
    80002fb8:	05864603          	lbu	a2,88(a2)
    80002fbc:	00c6f5b3          	and	a1,a3,a2
    80002fc0:	ddb1                	beqz	a1,80002f1c <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002fc2:	2705                	addiw	a4,a4,1
    80002fc4:	2485                	addiw	s1,s1,1
    80002fc6:	fd471ae3          	bne	a4,s4,80002f9a <balloc+0xb6>
    80002fca:	b755                	j	80002f6e <balloc+0x8a>
    80002fcc:	7942                	ld	s2,48(sp)
    80002fce:	79a2                	ld	s3,40(sp)
    80002fd0:	7a02                	ld	s4,32(sp)
    80002fd2:	6ae2                	ld	s5,24(sp)
    80002fd4:	6b42                	ld	s6,16(sp)
    80002fd6:	6ba2                	ld	s7,8(sp)
    80002fd8:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002fda:	00004517          	auipc	a0,0x4
    80002fde:	46650513          	addi	a0,a0,1126 # 80007440 <etext+0x440>
    80002fe2:	d18fd0ef          	jal	800004fa <printf>
  return 0;
    80002fe6:	4481                	li	s1,0
    80002fe8:	bfad                	j	80002f62 <balloc+0x7e>

0000000080002fea <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002fea:	7179                	addi	sp,sp,-48
    80002fec:	f406                	sd	ra,40(sp)
    80002fee:	f022                	sd	s0,32(sp)
    80002ff0:	ec26                	sd	s1,24(sp)
    80002ff2:	e84a                	sd	s2,16(sp)
    80002ff4:	e44e                	sd	s3,8(sp)
    80002ff6:	1800                	addi	s0,sp,48
    80002ff8:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002ffa:	47ad                	li	a5,11
    80002ffc:	02b7e363          	bltu	a5,a1,80003022 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80003000:	02059793          	slli	a5,a1,0x20
    80003004:	01e7d593          	srli	a1,a5,0x1e
    80003008:	00b509b3          	add	s3,a0,a1
    8000300c:	0509a483          	lw	s1,80(s3)
    80003010:	e0b5                	bnez	s1,80003074 <bmap+0x8a>
      addr = balloc(ip->dev);
    80003012:	4108                	lw	a0,0(a0)
    80003014:	ed1ff0ef          	jal	80002ee4 <balloc>
    80003018:	84aa                	mv	s1,a0
      if(addr == 0)
    8000301a:	cd29                	beqz	a0,80003074 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    8000301c:	04a9a823          	sw	a0,80(s3)
    80003020:	a891                	j	80003074 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003022:	ff45879b          	addiw	a5,a1,-12
    80003026:	873e                	mv	a4,a5
    80003028:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    8000302a:	0ff00793          	li	a5,255
    8000302e:	06e7e763          	bltu	a5,a4,8000309c <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003032:	08052483          	lw	s1,128(a0)
    80003036:	e891                	bnez	s1,8000304a <bmap+0x60>
      addr = balloc(ip->dev);
    80003038:	4108                	lw	a0,0(a0)
    8000303a:	eabff0ef          	jal	80002ee4 <balloc>
    8000303e:	84aa                	mv	s1,a0
      if(addr == 0)
    80003040:	c915                	beqz	a0,80003074 <bmap+0x8a>
    80003042:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003044:	08a92023          	sw	a0,128(s2)
    80003048:	a011                	j	8000304c <bmap+0x62>
    8000304a:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000304c:	85a6                	mv	a1,s1
    8000304e:	00092503          	lw	a0,0(s2)
    80003052:	c33ff0ef          	jal	80002c84 <bread>
    80003056:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003058:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000305c:	02099713          	slli	a4,s3,0x20
    80003060:	01e75593          	srli	a1,a4,0x1e
    80003064:	97ae                	add	a5,a5,a1
    80003066:	89be                	mv	s3,a5
    80003068:	4384                	lw	s1,0(a5)
    8000306a:	cc89                	beqz	s1,80003084 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000306c:	8552                	mv	a0,s4
    8000306e:	d1fff0ef          	jal	80002d8c <brelse>
    return addr;
    80003072:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003074:	8526                	mv	a0,s1
    80003076:	70a2                	ld	ra,40(sp)
    80003078:	7402                	ld	s0,32(sp)
    8000307a:	64e2                	ld	s1,24(sp)
    8000307c:	6942                	ld	s2,16(sp)
    8000307e:	69a2                	ld	s3,8(sp)
    80003080:	6145                	addi	sp,sp,48
    80003082:	8082                	ret
      addr = balloc(ip->dev);
    80003084:	00092503          	lw	a0,0(s2)
    80003088:	e5dff0ef          	jal	80002ee4 <balloc>
    8000308c:	84aa                	mv	s1,a0
      if(addr){
    8000308e:	dd79                	beqz	a0,8000306c <bmap+0x82>
        a[bn] = addr;
    80003090:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80003094:	8552                	mv	a0,s4
    80003096:	62d000ef          	jal	80003ec2 <log_write>
    8000309a:	bfc9                	j	8000306c <bmap+0x82>
    8000309c:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000309e:	00004517          	auipc	a0,0x4
    800030a2:	3ba50513          	addi	a0,a0,954 # 80007458 <etext+0x458>
    800030a6:	f7efd0ef          	jal	80000824 <panic>

00000000800030aa <iget>:
{
    800030aa:	7179                	addi	sp,sp,-48
    800030ac:	f406                	sd	ra,40(sp)
    800030ae:	f022                	sd	s0,32(sp)
    800030b0:	ec26                	sd	s1,24(sp)
    800030b2:	e84a                	sd	s2,16(sp)
    800030b4:	e44e                	sd	s3,8(sp)
    800030b6:	e052                	sd	s4,0(sp)
    800030b8:	1800                	addi	s0,sp,48
    800030ba:	892a                	mv	s2,a0
    800030bc:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800030be:	0001e517          	auipc	a0,0x1e
    800030c2:	89250513          	addi	a0,a0,-1902 # 80020950 <itable>
    800030c6:	b63fd0ef          	jal	80000c28 <acquire>
  empty = 0;
    800030ca:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800030cc:	0001e497          	auipc	s1,0x1e
    800030d0:	89c48493          	addi	s1,s1,-1892 # 80020968 <itable+0x18>
    800030d4:	0001f697          	auipc	a3,0x1f
    800030d8:	32468693          	addi	a3,a3,804 # 800223f8 <log>
    800030dc:	a809                	j	800030ee <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800030de:	e781                	bnez	a5,800030e6 <iget+0x3c>
    800030e0:	00099363          	bnez	s3,800030e6 <iget+0x3c>
      empty = ip;
    800030e4:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800030e6:	08848493          	addi	s1,s1,136
    800030ea:	02d48563          	beq	s1,a3,80003114 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800030ee:	449c                	lw	a5,8(s1)
    800030f0:	fef057e3          	blez	a5,800030de <iget+0x34>
    800030f4:	4098                	lw	a4,0(s1)
    800030f6:	ff2718e3          	bne	a4,s2,800030e6 <iget+0x3c>
    800030fa:	40d8                	lw	a4,4(s1)
    800030fc:	ff4715e3          	bne	a4,s4,800030e6 <iget+0x3c>
      ip->ref++;
    80003100:	2785                	addiw	a5,a5,1
    80003102:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003104:	0001e517          	auipc	a0,0x1e
    80003108:	84c50513          	addi	a0,a0,-1972 # 80020950 <itable>
    8000310c:	bb1fd0ef          	jal	80000cbc <release>
      return ip;
    80003110:	89a6                	mv	s3,s1
    80003112:	a015                	j	80003136 <iget+0x8c>
  if(empty == 0)
    80003114:	02098a63          	beqz	s3,80003148 <iget+0x9e>
  ip->dev = dev;
    80003118:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    8000311c:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80003120:	4785                	li	a5,1
    80003122:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    80003126:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000312a:	0001e517          	auipc	a0,0x1e
    8000312e:	82650513          	addi	a0,a0,-2010 # 80020950 <itable>
    80003132:	b8bfd0ef          	jal	80000cbc <release>
}
    80003136:	854e                	mv	a0,s3
    80003138:	70a2                	ld	ra,40(sp)
    8000313a:	7402                	ld	s0,32(sp)
    8000313c:	64e2                	ld	s1,24(sp)
    8000313e:	6942                	ld	s2,16(sp)
    80003140:	69a2                	ld	s3,8(sp)
    80003142:	6a02                	ld	s4,0(sp)
    80003144:	6145                	addi	sp,sp,48
    80003146:	8082                	ret
    panic("iget: no inodes");
    80003148:	00004517          	auipc	a0,0x4
    8000314c:	32850513          	addi	a0,a0,808 # 80007470 <etext+0x470>
    80003150:	ed4fd0ef          	jal	80000824 <panic>

0000000080003154 <iinit>:
{
    80003154:	7179                	addi	sp,sp,-48
    80003156:	f406                	sd	ra,40(sp)
    80003158:	f022                	sd	s0,32(sp)
    8000315a:	ec26                	sd	s1,24(sp)
    8000315c:	e84a                	sd	s2,16(sp)
    8000315e:	e44e                	sd	s3,8(sp)
    80003160:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003162:	00004597          	auipc	a1,0x4
    80003166:	31e58593          	addi	a1,a1,798 # 80007480 <etext+0x480>
    8000316a:	0001d517          	auipc	a0,0x1d
    8000316e:	7e650513          	addi	a0,a0,2022 # 80020950 <itable>
    80003172:	a2dfd0ef          	jal	80000b9e <initlock>
  for(i = 0; i < NINODE; i++) {
    80003176:	0001e497          	auipc	s1,0x1e
    8000317a:	80248493          	addi	s1,s1,-2046 # 80020978 <itable+0x28>
    8000317e:	0001f997          	auipc	s3,0x1f
    80003182:	28a98993          	addi	s3,s3,650 # 80022408 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003186:	00004917          	auipc	s2,0x4
    8000318a:	30290913          	addi	s2,s2,770 # 80007488 <etext+0x488>
    8000318e:	85ca                	mv	a1,s2
    80003190:	8526                	mv	a0,s1
    80003192:	5f5000ef          	jal	80003f86 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003196:	08848493          	addi	s1,s1,136
    8000319a:	ff349ae3          	bne	s1,s3,8000318e <iinit+0x3a>
}
    8000319e:	70a2                	ld	ra,40(sp)
    800031a0:	7402                	ld	s0,32(sp)
    800031a2:	64e2                	ld	s1,24(sp)
    800031a4:	6942                	ld	s2,16(sp)
    800031a6:	69a2                	ld	s3,8(sp)
    800031a8:	6145                	addi	sp,sp,48
    800031aa:	8082                	ret

00000000800031ac <ialloc>:
{
    800031ac:	7139                	addi	sp,sp,-64
    800031ae:	fc06                	sd	ra,56(sp)
    800031b0:	f822                	sd	s0,48(sp)
    800031b2:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    800031b4:	0001d717          	auipc	a4,0x1d
    800031b8:	78872703          	lw	a4,1928(a4) # 8002093c <sb+0xc>
    800031bc:	4785                	li	a5,1
    800031be:	06e7f063          	bgeu	a5,a4,8000321e <ialloc+0x72>
    800031c2:	f426                	sd	s1,40(sp)
    800031c4:	f04a                	sd	s2,32(sp)
    800031c6:	ec4e                	sd	s3,24(sp)
    800031c8:	e852                	sd	s4,16(sp)
    800031ca:	e456                	sd	s5,8(sp)
    800031cc:	e05a                	sd	s6,0(sp)
    800031ce:	8aaa                	mv	s5,a0
    800031d0:	8b2e                	mv	s6,a1
    800031d2:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800031d4:	0001da17          	auipc	s4,0x1d
    800031d8:	75ca0a13          	addi	s4,s4,1884 # 80020930 <sb>
    800031dc:	00495593          	srli	a1,s2,0x4
    800031e0:	018a2783          	lw	a5,24(s4)
    800031e4:	9dbd                	addw	a1,a1,a5
    800031e6:	8556                	mv	a0,s5
    800031e8:	a9dff0ef          	jal	80002c84 <bread>
    800031ec:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800031ee:	05850993          	addi	s3,a0,88
    800031f2:	00f97793          	andi	a5,s2,15
    800031f6:	079a                	slli	a5,a5,0x6
    800031f8:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800031fa:	00099783          	lh	a5,0(s3)
    800031fe:	cb9d                	beqz	a5,80003234 <ialloc+0x88>
    brelse(bp);
    80003200:	b8dff0ef          	jal	80002d8c <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003204:	0905                	addi	s2,s2,1
    80003206:	00ca2703          	lw	a4,12(s4)
    8000320a:	0009079b          	sext.w	a5,s2
    8000320e:	fce7e7e3          	bltu	a5,a4,800031dc <ialloc+0x30>
    80003212:	74a2                	ld	s1,40(sp)
    80003214:	7902                	ld	s2,32(sp)
    80003216:	69e2                	ld	s3,24(sp)
    80003218:	6a42                	ld	s4,16(sp)
    8000321a:	6aa2                	ld	s5,8(sp)
    8000321c:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    8000321e:	00004517          	auipc	a0,0x4
    80003222:	27250513          	addi	a0,a0,626 # 80007490 <etext+0x490>
    80003226:	ad4fd0ef          	jal	800004fa <printf>
  return 0;
    8000322a:	4501                	li	a0,0
}
    8000322c:	70e2                	ld	ra,56(sp)
    8000322e:	7442                	ld	s0,48(sp)
    80003230:	6121                	addi	sp,sp,64
    80003232:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003234:	04000613          	li	a2,64
    80003238:	4581                	li	a1,0
    8000323a:	854e                	mv	a0,s3
    8000323c:	abdfd0ef          	jal	80000cf8 <memset>
      dip->type = type;
    80003240:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003244:	8526                	mv	a0,s1
    80003246:	47d000ef          	jal	80003ec2 <log_write>
      brelse(bp);
    8000324a:	8526                	mv	a0,s1
    8000324c:	b41ff0ef          	jal	80002d8c <brelse>
      return iget(dev, inum);
    80003250:	0009059b          	sext.w	a1,s2
    80003254:	8556                	mv	a0,s5
    80003256:	e55ff0ef          	jal	800030aa <iget>
    8000325a:	74a2                	ld	s1,40(sp)
    8000325c:	7902                	ld	s2,32(sp)
    8000325e:	69e2                	ld	s3,24(sp)
    80003260:	6a42                	ld	s4,16(sp)
    80003262:	6aa2                	ld	s5,8(sp)
    80003264:	6b02                	ld	s6,0(sp)
    80003266:	b7d9                	j	8000322c <ialloc+0x80>

0000000080003268 <iupdate>:
{
    80003268:	1101                	addi	sp,sp,-32
    8000326a:	ec06                	sd	ra,24(sp)
    8000326c:	e822                	sd	s0,16(sp)
    8000326e:	e426                	sd	s1,8(sp)
    80003270:	e04a                	sd	s2,0(sp)
    80003272:	1000                	addi	s0,sp,32
    80003274:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003276:	415c                	lw	a5,4(a0)
    80003278:	0047d79b          	srliw	a5,a5,0x4
    8000327c:	0001d597          	auipc	a1,0x1d
    80003280:	6cc5a583          	lw	a1,1740(a1) # 80020948 <sb+0x18>
    80003284:	9dbd                	addw	a1,a1,a5
    80003286:	4108                	lw	a0,0(a0)
    80003288:	9fdff0ef          	jal	80002c84 <bread>
    8000328c:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000328e:	05850793          	addi	a5,a0,88
    80003292:	40d8                	lw	a4,4(s1)
    80003294:	8b3d                	andi	a4,a4,15
    80003296:	071a                	slli	a4,a4,0x6
    80003298:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    8000329a:	04449703          	lh	a4,68(s1)
    8000329e:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800032a2:	04649703          	lh	a4,70(s1)
    800032a6:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800032aa:	04849703          	lh	a4,72(s1)
    800032ae:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800032b2:	04a49703          	lh	a4,74(s1)
    800032b6:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800032ba:	44f8                	lw	a4,76(s1)
    800032bc:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800032be:	03400613          	li	a2,52
    800032c2:	05048593          	addi	a1,s1,80
    800032c6:	00c78513          	addi	a0,a5,12
    800032ca:	a8ffd0ef          	jal	80000d58 <memmove>
  log_write(bp);
    800032ce:	854a                	mv	a0,s2
    800032d0:	3f3000ef          	jal	80003ec2 <log_write>
  brelse(bp);
    800032d4:	854a                	mv	a0,s2
    800032d6:	ab7ff0ef          	jal	80002d8c <brelse>
}
    800032da:	60e2                	ld	ra,24(sp)
    800032dc:	6442                	ld	s0,16(sp)
    800032de:	64a2                	ld	s1,8(sp)
    800032e0:	6902                	ld	s2,0(sp)
    800032e2:	6105                	addi	sp,sp,32
    800032e4:	8082                	ret

00000000800032e6 <idup>:
{
    800032e6:	1101                	addi	sp,sp,-32
    800032e8:	ec06                	sd	ra,24(sp)
    800032ea:	e822                	sd	s0,16(sp)
    800032ec:	e426                	sd	s1,8(sp)
    800032ee:	1000                	addi	s0,sp,32
    800032f0:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800032f2:	0001d517          	auipc	a0,0x1d
    800032f6:	65e50513          	addi	a0,a0,1630 # 80020950 <itable>
    800032fa:	92ffd0ef          	jal	80000c28 <acquire>
  ip->ref++;
    800032fe:	449c                	lw	a5,8(s1)
    80003300:	2785                	addiw	a5,a5,1
    80003302:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003304:	0001d517          	auipc	a0,0x1d
    80003308:	64c50513          	addi	a0,a0,1612 # 80020950 <itable>
    8000330c:	9b1fd0ef          	jal	80000cbc <release>
}
    80003310:	8526                	mv	a0,s1
    80003312:	60e2                	ld	ra,24(sp)
    80003314:	6442                	ld	s0,16(sp)
    80003316:	64a2                	ld	s1,8(sp)
    80003318:	6105                	addi	sp,sp,32
    8000331a:	8082                	ret

000000008000331c <ilock>:
{
    8000331c:	1101                	addi	sp,sp,-32
    8000331e:	ec06                	sd	ra,24(sp)
    80003320:	e822                	sd	s0,16(sp)
    80003322:	e426                	sd	s1,8(sp)
    80003324:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003326:	cd19                	beqz	a0,80003344 <ilock+0x28>
    80003328:	84aa                	mv	s1,a0
    8000332a:	451c                	lw	a5,8(a0)
    8000332c:	00f05c63          	blez	a5,80003344 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003330:	0541                	addi	a0,a0,16
    80003332:	48b000ef          	jal	80003fbc <acquiresleep>
  if(ip->valid == 0){
    80003336:	40bc                	lw	a5,64(s1)
    80003338:	cf89                	beqz	a5,80003352 <ilock+0x36>
}
    8000333a:	60e2                	ld	ra,24(sp)
    8000333c:	6442                	ld	s0,16(sp)
    8000333e:	64a2                	ld	s1,8(sp)
    80003340:	6105                	addi	sp,sp,32
    80003342:	8082                	ret
    80003344:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003346:	00004517          	auipc	a0,0x4
    8000334a:	16250513          	addi	a0,a0,354 # 800074a8 <etext+0x4a8>
    8000334e:	cd6fd0ef          	jal	80000824 <panic>
    80003352:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003354:	40dc                	lw	a5,4(s1)
    80003356:	0047d79b          	srliw	a5,a5,0x4
    8000335a:	0001d597          	auipc	a1,0x1d
    8000335e:	5ee5a583          	lw	a1,1518(a1) # 80020948 <sb+0x18>
    80003362:	9dbd                	addw	a1,a1,a5
    80003364:	4088                	lw	a0,0(s1)
    80003366:	91fff0ef          	jal	80002c84 <bread>
    8000336a:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000336c:	05850593          	addi	a1,a0,88
    80003370:	40dc                	lw	a5,4(s1)
    80003372:	8bbd                	andi	a5,a5,15
    80003374:	079a                	slli	a5,a5,0x6
    80003376:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003378:	00059783          	lh	a5,0(a1)
    8000337c:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003380:	00259783          	lh	a5,2(a1)
    80003384:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003388:	00459783          	lh	a5,4(a1)
    8000338c:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003390:	00659783          	lh	a5,6(a1)
    80003394:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003398:	459c                	lw	a5,8(a1)
    8000339a:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000339c:	03400613          	li	a2,52
    800033a0:	05b1                	addi	a1,a1,12
    800033a2:	05048513          	addi	a0,s1,80
    800033a6:	9b3fd0ef          	jal	80000d58 <memmove>
    brelse(bp);
    800033aa:	854a                	mv	a0,s2
    800033ac:	9e1ff0ef          	jal	80002d8c <brelse>
    ip->valid = 1;
    800033b0:	4785                	li	a5,1
    800033b2:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800033b4:	04449783          	lh	a5,68(s1)
    800033b8:	c399                	beqz	a5,800033be <ilock+0xa2>
    800033ba:	6902                	ld	s2,0(sp)
    800033bc:	bfbd                	j	8000333a <ilock+0x1e>
      panic("ilock: no type");
    800033be:	00004517          	auipc	a0,0x4
    800033c2:	0f250513          	addi	a0,a0,242 # 800074b0 <etext+0x4b0>
    800033c6:	c5efd0ef          	jal	80000824 <panic>

00000000800033ca <iunlock>:
{
    800033ca:	1101                	addi	sp,sp,-32
    800033cc:	ec06                	sd	ra,24(sp)
    800033ce:	e822                	sd	s0,16(sp)
    800033d0:	e426                	sd	s1,8(sp)
    800033d2:	e04a                	sd	s2,0(sp)
    800033d4:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800033d6:	c505                	beqz	a0,800033fe <iunlock+0x34>
    800033d8:	84aa                	mv	s1,a0
    800033da:	01050913          	addi	s2,a0,16
    800033de:	854a                	mv	a0,s2
    800033e0:	45b000ef          	jal	8000403a <holdingsleep>
    800033e4:	cd09                	beqz	a0,800033fe <iunlock+0x34>
    800033e6:	449c                	lw	a5,8(s1)
    800033e8:	00f05b63          	blez	a5,800033fe <iunlock+0x34>
  releasesleep(&ip->lock);
    800033ec:	854a                	mv	a0,s2
    800033ee:	415000ef          	jal	80004002 <releasesleep>
}
    800033f2:	60e2                	ld	ra,24(sp)
    800033f4:	6442                	ld	s0,16(sp)
    800033f6:	64a2                	ld	s1,8(sp)
    800033f8:	6902                	ld	s2,0(sp)
    800033fa:	6105                	addi	sp,sp,32
    800033fc:	8082                	ret
    panic("iunlock");
    800033fe:	00004517          	auipc	a0,0x4
    80003402:	0c250513          	addi	a0,a0,194 # 800074c0 <etext+0x4c0>
    80003406:	c1efd0ef          	jal	80000824 <panic>

000000008000340a <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000340a:	7179                	addi	sp,sp,-48
    8000340c:	f406                	sd	ra,40(sp)
    8000340e:	f022                	sd	s0,32(sp)
    80003410:	ec26                	sd	s1,24(sp)
    80003412:	e84a                	sd	s2,16(sp)
    80003414:	e44e                	sd	s3,8(sp)
    80003416:	1800                	addi	s0,sp,48
    80003418:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000341a:	05050493          	addi	s1,a0,80
    8000341e:	08050913          	addi	s2,a0,128
    80003422:	a021                	j	8000342a <itrunc+0x20>
    80003424:	0491                	addi	s1,s1,4
    80003426:	01248b63          	beq	s1,s2,8000343c <itrunc+0x32>
    if(ip->addrs[i]){
    8000342a:	408c                	lw	a1,0(s1)
    8000342c:	dde5                	beqz	a1,80003424 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000342e:	0009a503          	lw	a0,0(s3)
    80003432:	a47ff0ef          	jal	80002e78 <bfree>
      ip->addrs[i] = 0;
    80003436:	0004a023          	sw	zero,0(s1)
    8000343a:	b7ed                	j	80003424 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000343c:	0809a583          	lw	a1,128(s3)
    80003440:	ed89                	bnez	a1,8000345a <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003442:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003446:	854e                	mv	a0,s3
    80003448:	e21ff0ef          	jal	80003268 <iupdate>
}
    8000344c:	70a2                	ld	ra,40(sp)
    8000344e:	7402                	ld	s0,32(sp)
    80003450:	64e2                	ld	s1,24(sp)
    80003452:	6942                	ld	s2,16(sp)
    80003454:	69a2                	ld	s3,8(sp)
    80003456:	6145                	addi	sp,sp,48
    80003458:	8082                	ret
    8000345a:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000345c:	0009a503          	lw	a0,0(s3)
    80003460:	825ff0ef          	jal	80002c84 <bread>
    80003464:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003466:	05850493          	addi	s1,a0,88
    8000346a:	45850913          	addi	s2,a0,1112
    8000346e:	a021                	j	80003476 <itrunc+0x6c>
    80003470:	0491                	addi	s1,s1,4
    80003472:	01248963          	beq	s1,s2,80003484 <itrunc+0x7a>
      if(a[j])
    80003476:	408c                	lw	a1,0(s1)
    80003478:	dde5                	beqz	a1,80003470 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    8000347a:	0009a503          	lw	a0,0(s3)
    8000347e:	9fbff0ef          	jal	80002e78 <bfree>
    80003482:	b7fd                	j	80003470 <itrunc+0x66>
    brelse(bp);
    80003484:	8552                	mv	a0,s4
    80003486:	907ff0ef          	jal	80002d8c <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000348a:	0809a583          	lw	a1,128(s3)
    8000348e:	0009a503          	lw	a0,0(s3)
    80003492:	9e7ff0ef          	jal	80002e78 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003496:	0809a023          	sw	zero,128(s3)
    8000349a:	6a02                	ld	s4,0(sp)
    8000349c:	b75d                	j	80003442 <itrunc+0x38>

000000008000349e <iput>:
{
    8000349e:	1101                	addi	sp,sp,-32
    800034a0:	ec06                	sd	ra,24(sp)
    800034a2:	e822                	sd	s0,16(sp)
    800034a4:	e426                	sd	s1,8(sp)
    800034a6:	1000                	addi	s0,sp,32
    800034a8:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034aa:	0001d517          	auipc	a0,0x1d
    800034ae:	4a650513          	addi	a0,a0,1190 # 80020950 <itable>
    800034b2:	f76fd0ef          	jal	80000c28 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800034b6:	4498                	lw	a4,8(s1)
    800034b8:	4785                	li	a5,1
    800034ba:	02f70063          	beq	a4,a5,800034da <iput+0x3c>
  ip->ref--;
    800034be:	449c                	lw	a5,8(s1)
    800034c0:	37fd                	addiw	a5,a5,-1
    800034c2:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034c4:	0001d517          	auipc	a0,0x1d
    800034c8:	48c50513          	addi	a0,a0,1164 # 80020950 <itable>
    800034cc:	ff0fd0ef          	jal	80000cbc <release>
}
    800034d0:	60e2                	ld	ra,24(sp)
    800034d2:	6442                	ld	s0,16(sp)
    800034d4:	64a2                	ld	s1,8(sp)
    800034d6:	6105                	addi	sp,sp,32
    800034d8:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800034da:	40bc                	lw	a5,64(s1)
    800034dc:	d3ed                	beqz	a5,800034be <iput+0x20>
    800034de:	04a49783          	lh	a5,74(s1)
    800034e2:	fff1                	bnez	a5,800034be <iput+0x20>
    800034e4:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800034e6:	01048793          	addi	a5,s1,16
    800034ea:	893e                	mv	s2,a5
    800034ec:	853e                	mv	a0,a5
    800034ee:	2cf000ef          	jal	80003fbc <acquiresleep>
    release(&itable.lock);
    800034f2:	0001d517          	auipc	a0,0x1d
    800034f6:	45e50513          	addi	a0,a0,1118 # 80020950 <itable>
    800034fa:	fc2fd0ef          	jal	80000cbc <release>
    itrunc(ip);
    800034fe:	8526                	mv	a0,s1
    80003500:	f0bff0ef          	jal	8000340a <itrunc>
    ip->type = 0;
    80003504:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003508:	8526                	mv	a0,s1
    8000350a:	d5fff0ef          	jal	80003268 <iupdate>
    ip->valid = 0;
    8000350e:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003512:	854a                	mv	a0,s2
    80003514:	2ef000ef          	jal	80004002 <releasesleep>
    acquire(&itable.lock);
    80003518:	0001d517          	auipc	a0,0x1d
    8000351c:	43850513          	addi	a0,a0,1080 # 80020950 <itable>
    80003520:	f08fd0ef          	jal	80000c28 <acquire>
    80003524:	6902                	ld	s2,0(sp)
    80003526:	bf61                	j	800034be <iput+0x20>

0000000080003528 <iunlockput>:
{
    80003528:	1101                	addi	sp,sp,-32
    8000352a:	ec06                	sd	ra,24(sp)
    8000352c:	e822                	sd	s0,16(sp)
    8000352e:	e426                	sd	s1,8(sp)
    80003530:	1000                	addi	s0,sp,32
    80003532:	84aa                	mv	s1,a0
  iunlock(ip);
    80003534:	e97ff0ef          	jal	800033ca <iunlock>
  iput(ip);
    80003538:	8526                	mv	a0,s1
    8000353a:	f65ff0ef          	jal	8000349e <iput>
}
    8000353e:	60e2                	ld	ra,24(sp)
    80003540:	6442                	ld	s0,16(sp)
    80003542:	64a2                	ld	s1,8(sp)
    80003544:	6105                	addi	sp,sp,32
    80003546:	8082                	ret

0000000080003548 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003548:	0001d717          	auipc	a4,0x1d
    8000354c:	3f472703          	lw	a4,1012(a4) # 8002093c <sb+0xc>
    80003550:	4785                	li	a5,1
    80003552:	0ae7fe63          	bgeu	a5,a4,8000360e <ireclaim+0xc6>
{
    80003556:	7139                	addi	sp,sp,-64
    80003558:	fc06                	sd	ra,56(sp)
    8000355a:	f822                	sd	s0,48(sp)
    8000355c:	f426                	sd	s1,40(sp)
    8000355e:	f04a                	sd	s2,32(sp)
    80003560:	ec4e                	sd	s3,24(sp)
    80003562:	e852                	sd	s4,16(sp)
    80003564:	e456                	sd	s5,8(sp)
    80003566:	e05a                	sd	s6,0(sp)
    80003568:	0080                	addi	s0,sp,64
    8000356a:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000356c:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000356e:	0001da17          	auipc	s4,0x1d
    80003572:	3c2a0a13          	addi	s4,s4,962 # 80020930 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003576:	00004b17          	auipc	s6,0x4
    8000357a:	f52b0b13          	addi	s6,s6,-174 # 800074c8 <etext+0x4c8>
    8000357e:	a099                	j	800035c4 <ireclaim+0x7c>
    80003580:	85ce                	mv	a1,s3
    80003582:	855a                	mv	a0,s6
    80003584:	f77fc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003588:	85ce                	mv	a1,s3
    8000358a:	8556                	mv	a0,s5
    8000358c:	b1fff0ef          	jal	800030aa <iget>
    80003590:	89aa                	mv	s3,a0
    brelse(bp);
    80003592:	854a                	mv	a0,s2
    80003594:	ff8ff0ef          	jal	80002d8c <brelse>
    if (ip) {
    80003598:	00098f63          	beqz	s3,800035b6 <ireclaim+0x6e>
      begin_op();
    8000359c:	78c000ef          	jal	80003d28 <begin_op>
      ilock(ip);
    800035a0:	854e                	mv	a0,s3
    800035a2:	d7bff0ef          	jal	8000331c <ilock>
      iunlock(ip);
    800035a6:	854e                	mv	a0,s3
    800035a8:	e23ff0ef          	jal	800033ca <iunlock>
      iput(ip);
    800035ac:	854e                	mv	a0,s3
    800035ae:	ef1ff0ef          	jal	8000349e <iput>
      end_op();
    800035b2:	7e6000ef          	jal	80003d98 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035b6:	0485                	addi	s1,s1,1
    800035b8:	00ca2703          	lw	a4,12(s4)
    800035bc:	0004879b          	sext.w	a5,s1
    800035c0:	02e7fd63          	bgeu	a5,a4,800035fa <ireclaim+0xb2>
    800035c4:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800035c8:	0044d593          	srli	a1,s1,0x4
    800035cc:	018a2783          	lw	a5,24(s4)
    800035d0:	9dbd                	addw	a1,a1,a5
    800035d2:	8556                	mv	a0,s5
    800035d4:	eb0ff0ef          	jal	80002c84 <bread>
    800035d8:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800035da:	05850793          	addi	a5,a0,88
    800035de:	00f9f713          	andi	a4,s3,15
    800035e2:	071a                	slli	a4,a4,0x6
    800035e4:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800035e6:	00079703          	lh	a4,0(a5)
    800035ea:	c701                	beqz	a4,800035f2 <ireclaim+0xaa>
    800035ec:	00679783          	lh	a5,6(a5)
    800035f0:	dbc1                	beqz	a5,80003580 <ireclaim+0x38>
    brelse(bp);
    800035f2:	854a                	mv	a0,s2
    800035f4:	f98ff0ef          	jal	80002d8c <brelse>
    if (ip) {
    800035f8:	bf7d                	j	800035b6 <ireclaim+0x6e>
}
    800035fa:	70e2                	ld	ra,56(sp)
    800035fc:	7442                	ld	s0,48(sp)
    800035fe:	74a2                	ld	s1,40(sp)
    80003600:	7902                	ld	s2,32(sp)
    80003602:	69e2                	ld	s3,24(sp)
    80003604:	6a42                	ld	s4,16(sp)
    80003606:	6aa2                	ld	s5,8(sp)
    80003608:	6b02                	ld	s6,0(sp)
    8000360a:	6121                	addi	sp,sp,64
    8000360c:	8082                	ret
    8000360e:	8082                	ret

0000000080003610 <fsinit>:
fsinit(int dev) {
    80003610:	1101                	addi	sp,sp,-32
    80003612:	ec06                	sd	ra,24(sp)
    80003614:	e822                	sd	s0,16(sp)
    80003616:	e426                	sd	s1,8(sp)
    80003618:	e04a                	sd	s2,0(sp)
    8000361a:	1000                	addi	s0,sp,32
    8000361c:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000361e:	4585                	li	a1,1
    80003620:	e64ff0ef          	jal	80002c84 <bread>
    80003624:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003626:	02000613          	li	a2,32
    8000362a:	05850593          	addi	a1,a0,88
    8000362e:	0001d517          	auipc	a0,0x1d
    80003632:	30250513          	addi	a0,a0,770 # 80020930 <sb>
    80003636:	f22fd0ef          	jal	80000d58 <memmove>
  brelse(bp);
    8000363a:	8526                	mv	a0,s1
    8000363c:	f50ff0ef          	jal	80002d8c <brelse>
  if(sb.magic != FSMAGIC)
    80003640:	0001d717          	auipc	a4,0x1d
    80003644:	2f072703          	lw	a4,752(a4) # 80020930 <sb>
    80003648:	102037b7          	lui	a5,0x10203
    8000364c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003650:	02f71263          	bne	a4,a5,80003674 <fsinit+0x64>
  initlog(dev, &sb);
    80003654:	0001d597          	auipc	a1,0x1d
    80003658:	2dc58593          	addi	a1,a1,732 # 80020930 <sb>
    8000365c:	854a                	mv	a0,s2
    8000365e:	648000ef          	jal	80003ca6 <initlog>
  ireclaim(dev);
    80003662:	854a                	mv	a0,s2
    80003664:	ee5ff0ef          	jal	80003548 <ireclaim>
}
    80003668:	60e2                	ld	ra,24(sp)
    8000366a:	6442                	ld	s0,16(sp)
    8000366c:	64a2                	ld	s1,8(sp)
    8000366e:	6902                	ld	s2,0(sp)
    80003670:	6105                	addi	sp,sp,32
    80003672:	8082                	ret
    panic("invalid file system");
    80003674:	00004517          	auipc	a0,0x4
    80003678:	e7450513          	addi	a0,a0,-396 # 800074e8 <etext+0x4e8>
    8000367c:	9a8fd0ef          	jal	80000824 <panic>

0000000080003680 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003680:	1141                	addi	sp,sp,-16
    80003682:	e406                	sd	ra,8(sp)
    80003684:	e022                	sd	s0,0(sp)
    80003686:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003688:	411c                	lw	a5,0(a0)
    8000368a:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000368c:	415c                	lw	a5,4(a0)
    8000368e:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003690:	04451783          	lh	a5,68(a0)
    80003694:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003698:	04a51783          	lh	a5,74(a0)
    8000369c:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800036a0:	04c56783          	lwu	a5,76(a0)
    800036a4:	e99c                	sd	a5,16(a1)
}
    800036a6:	60a2                	ld	ra,8(sp)
    800036a8:	6402                	ld	s0,0(sp)
    800036aa:	0141                	addi	sp,sp,16
    800036ac:	8082                	ret

00000000800036ae <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800036ae:	457c                	lw	a5,76(a0)
    800036b0:	0ed7e663          	bltu	a5,a3,8000379c <readi+0xee>
{
    800036b4:	7159                	addi	sp,sp,-112
    800036b6:	f486                	sd	ra,104(sp)
    800036b8:	f0a2                	sd	s0,96(sp)
    800036ba:	eca6                	sd	s1,88(sp)
    800036bc:	e0d2                	sd	s4,64(sp)
    800036be:	fc56                	sd	s5,56(sp)
    800036c0:	f85a                	sd	s6,48(sp)
    800036c2:	f45e                	sd	s7,40(sp)
    800036c4:	1880                	addi	s0,sp,112
    800036c6:	8b2a                	mv	s6,a0
    800036c8:	8bae                	mv	s7,a1
    800036ca:	8a32                	mv	s4,a2
    800036cc:	84b6                	mv	s1,a3
    800036ce:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800036d0:	9f35                	addw	a4,a4,a3
    return 0;
    800036d2:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800036d4:	0ad76b63          	bltu	a4,a3,8000378a <readi+0xdc>
    800036d8:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800036da:	00e7f463          	bgeu	a5,a4,800036e2 <readi+0x34>
    n = ip->size - off;
    800036de:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800036e2:	080a8b63          	beqz	s5,80003778 <readi+0xca>
    800036e6:	e8ca                	sd	s2,80(sp)
    800036e8:	f062                	sd	s8,32(sp)
    800036ea:	ec66                	sd	s9,24(sp)
    800036ec:	e86a                	sd	s10,16(sp)
    800036ee:	e46e                	sd	s11,8(sp)
    800036f0:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800036f2:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800036f6:	5c7d                	li	s8,-1
    800036f8:	a80d                	j	8000372a <readi+0x7c>
    800036fa:	020d1d93          	slli	s11,s10,0x20
    800036fe:	020ddd93          	srli	s11,s11,0x20
    80003702:	05890613          	addi	a2,s2,88
    80003706:	86ee                	mv	a3,s11
    80003708:	963e                	add	a2,a2,a5
    8000370a:	85d2                	mv	a1,s4
    8000370c:	855e                	mv	a0,s7
    8000370e:	c93fe0ef          	jal	800023a0 <either_copyout>
    80003712:	05850363          	beq	a0,s8,80003758 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003716:	854a                	mv	a0,s2
    80003718:	e74ff0ef          	jal	80002d8c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000371c:	013d09bb          	addw	s3,s10,s3
    80003720:	009d04bb          	addw	s1,s10,s1
    80003724:	9a6e                	add	s4,s4,s11
    80003726:	0559f363          	bgeu	s3,s5,8000376c <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000372a:	00a4d59b          	srliw	a1,s1,0xa
    8000372e:	855a                	mv	a0,s6
    80003730:	8bbff0ef          	jal	80002fea <bmap>
    80003734:	85aa                	mv	a1,a0
    if(addr == 0)
    80003736:	c139                	beqz	a0,8000377c <readi+0xce>
    bp = bread(ip->dev, addr);
    80003738:	000b2503          	lw	a0,0(s6)
    8000373c:	d48ff0ef          	jal	80002c84 <bread>
    80003740:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003742:	3ff4f793          	andi	a5,s1,1023
    80003746:	40fc873b          	subw	a4,s9,a5
    8000374a:	413a86bb          	subw	a3,s5,s3
    8000374e:	8d3a                	mv	s10,a4
    80003750:	fae6f5e3          	bgeu	a3,a4,800036fa <readi+0x4c>
    80003754:	8d36                	mv	s10,a3
    80003756:	b755                	j	800036fa <readi+0x4c>
      brelse(bp);
    80003758:	854a                	mv	a0,s2
    8000375a:	e32ff0ef          	jal	80002d8c <brelse>
      tot = -1;
    8000375e:	59fd                	li	s3,-1
      break;
    80003760:	6946                	ld	s2,80(sp)
    80003762:	7c02                	ld	s8,32(sp)
    80003764:	6ce2                	ld	s9,24(sp)
    80003766:	6d42                	ld	s10,16(sp)
    80003768:	6da2                	ld	s11,8(sp)
    8000376a:	a831                	j	80003786 <readi+0xd8>
    8000376c:	6946                	ld	s2,80(sp)
    8000376e:	7c02                	ld	s8,32(sp)
    80003770:	6ce2                	ld	s9,24(sp)
    80003772:	6d42                	ld	s10,16(sp)
    80003774:	6da2                	ld	s11,8(sp)
    80003776:	a801                	j	80003786 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003778:	89d6                	mv	s3,s5
    8000377a:	a031                	j	80003786 <readi+0xd8>
    8000377c:	6946                	ld	s2,80(sp)
    8000377e:	7c02                	ld	s8,32(sp)
    80003780:	6ce2                	ld	s9,24(sp)
    80003782:	6d42                	ld	s10,16(sp)
    80003784:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003786:	854e                	mv	a0,s3
    80003788:	69a6                	ld	s3,72(sp)
}
    8000378a:	70a6                	ld	ra,104(sp)
    8000378c:	7406                	ld	s0,96(sp)
    8000378e:	64e6                	ld	s1,88(sp)
    80003790:	6a06                	ld	s4,64(sp)
    80003792:	7ae2                	ld	s5,56(sp)
    80003794:	7b42                	ld	s6,48(sp)
    80003796:	7ba2                	ld	s7,40(sp)
    80003798:	6165                	addi	sp,sp,112
    8000379a:	8082                	ret
    return 0;
    8000379c:	4501                	li	a0,0
}
    8000379e:	8082                	ret

00000000800037a0 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800037a0:	457c                	lw	a5,76(a0)
    800037a2:	0ed7eb63          	bltu	a5,a3,80003898 <writei+0xf8>
{
    800037a6:	7159                	addi	sp,sp,-112
    800037a8:	f486                	sd	ra,104(sp)
    800037aa:	f0a2                	sd	s0,96(sp)
    800037ac:	e8ca                	sd	s2,80(sp)
    800037ae:	e0d2                	sd	s4,64(sp)
    800037b0:	fc56                	sd	s5,56(sp)
    800037b2:	f85a                	sd	s6,48(sp)
    800037b4:	f45e                	sd	s7,40(sp)
    800037b6:	1880                	addi	s0,sp,112
    800037b8:	8aaa                	mv	s5,a0
    800037ba:	8bae                	mv	s7,a1
    800037bc:	8a32                	mv	s4,a2
    800037be:	8936                	mv	s2,a3
    800037c0:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800037c2:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800037c6:	00043737          	lui	a4,0x43
    800037ca:	0cf76963          	bltu	a4,a5,8000389c <writei+0xfc>
    800037ce:	0cd7e763          	bltu	a5,a3,8000389c <writei+0xfc>
    800037d2:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800037d4:	0a0b0a63          	beqz	s6,80003888 <writei+0xe8>
    800037d8:	eca6                	sd	s1,88(sp)
    800037da:	f062                	sd	s8,32(sp)
    800037dc:	ec66                	sd	s9,24(sp)
    800037de:	e86a                	sd	s10,16(sp)
    800037e0:	e46e                	sd	s11,8(sp)
    800037e2:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800037e4:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800037e8:	5c7d                	li	s8,-1
    800037ea:	a825                	j	80003822 <writei+0x82>
    800037ec:	020d1d93          	slli	s11,s10,0x20
    800037f0:	020ddd93          	srli	s11,s11,0x20
    800037f4:	05848513          	addi	a0,s1,88
    800037f8:	86ee                	mv	a3,s11
    800037fa:	8652                	mv	a2,s4
    800037fc:	85de                	mv	a1,s7
    800037fe:	953e                	add	a0,a0,a5
    80003800:	bebfe0ef          	jal	800023ea <either_copyin>
    80003804:	05850663          	beq	a0,s8,80003850 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003808:	8526                	mv	a0,s1
    8000380a:	6b8000ef          	jal	80003ec2 <log_write>
    brelse(bp);
    8000380e:	8526                	mv	a0,s1
    80003810:	d7cff0ef          	jal	80002d8c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003814:	013d09bb          	addw	s3,s10,s3
    80003818:	012d093b          	addw	s2,s10,s2
    8000381c:	9a6e                	add	s4,s4,s11
    8000381e:	0369fc63          	bgeu	s3,s6,80003856 <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003822:	00a9559b          	srliw	a1,s2,0xa
    80003826:	8556                	mv	a0,s5
    80003828:	fc2ff0ef          	jal	80002fea <bmap>
    8000382c:	85aa                	mv	a1,a0
    if(addr == 0)
    8000382e:	c505                	beqz	a0,80003856 <writei+0xb6>
    bp = bread(ip->dev, addr);
    80003830:	000aa503          	lw	a0,0(s5)
    80003834:	c50ff0ef          	jal	80002c84 <bread>
    80003838:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000383a:	3ff97793          	andi	a5,s2,1023
    8000383e:	40fc873b          	subw	a4,s9,a5
    80003842:	413b06bb          	subw	a3,s6,s3
    80003846:	8d3a                	mv	s10,a4
    80003848:	fae6f2e3          	bgeu	a3,a4,800037ec <writei+0x4c>
    8000384c:	8d36                	mv	s10,a3
    8000384e:	bf79                	j	800037ec <writei+0x4c>
      brelse(bp);
    80003850:	8526                	mv	a0,s1
    80003852:	d3aff0ef          	jal	80002d8c <brelse>
  }

  if(off > ip->size)
    80003856:	04caa783          	lw	a5,76(s5)
    8000385a:	0327f963          	bgeu	a5,s2,8000388c <writei+0xec>
    ip->size = off;
    8000385e:	052aa623          	sw	s2,76(s5)
    80003862:	64e6                	ld	s1,88(sp)
    80003864:	7c02                	ld	s8,32(sp)
    80003866:	6ce2                	ld	s9,24(sp)
    80003868:	6d42                	ld	s10,16(sp)
    8000386a:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    8000386c:	8556                	mv	a0,s5
    8000386e:	9fbff0ef          	jal	80003268 <iupdate>

  return tot;
    80003872:	854e                	mv	a0,s3
    80003874:	69a6                	ld	s3,72(sp)
}
    80003876:	70a6                	ld	ra,104(sp)
    80003878:	7406                	ld	s0,96(sp)
    8000387a:	6946                	ld	s2,80(sp)
    8000387c:	6a06                	ld	s4,64(sp)
    8000387e:	7ae2                	ld	s5,56(sp)
    80003880:	7b42                	ld	s6,48(sp)
    80003882:	7ba2                	ld	s7,40(sp)
    80003884:	6165                	addi	sp,sp,112
    80003886:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003888:	89da                	mv	s3,s6
    8000388a:	b7cd                	j	8000386c <writei+0xcc>
    8000388c:	64e6                	ld	s1,88(sp)
    8000388e:	7c02                	ld	s8,32(sp)
    80003890:	6ce2                	ld	s9,24(sp)
    80003892:	6d42                	ld	s10,16(sp)
    80003894:	6da2                	ld	s11,8(sp)
    80003896:	bfd9                	j	8000386c <writei+0xcc>
    return -1;
    80003898:	557d                	li	a0,-1
}
    8000389a:	8082                	ret
    return -1;
    8000389c:	557d                	li	a0,-1
    8000389e:	bfe1                	j	80003876 <writei+0xd6>

00000000800038a0 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800038a0:	1141                	addi	sp,sp,-16
    800038a2:	e406                	sd	ra,8(sp)
    800038a4:	e022                	sd	s0,0(sp)
    800038a6:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800038a8:	4639                	li	a2,14
    800038aa:	d22fd0ef          	jal	80000dcc <strncmp>
}
    800038ae:	60a2                	ld	ra,8(sp)
    800038b0:	6402                	ld	s0,0(sp)
    800038b2:	0141                	addi	sp,sp,16
    800038b4:	8082                	ret

00000000800038b6 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800038b6:	711d                	addi	sp,sp,-96
    800038b8:	ec86                	sd	ra,88(sp)
    800038ba:	e8a2                	sd	s0,80(sp)
    800038bc:	e4a6                	sd	s1,72(sp)
    800038be:	e0ca                	sd	s2,64(sp)
    800038c0:	fc4e                	sd	s3,56(sp)
    800038c2:	f852                	sd	s4,48(sp)
    800038c4:	f456                	sd	s5,40(sp)
    800038c6:	f05a                	sd	s6,32(sp)
    800038c8:	ec5e                	sd	s7,24(sp)
    800038ca:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    800038cc:	04451703          	lh	a4,68(a0)
    800038d0:	4785                	li	a5,1
    800038d2:	00f71f63          	bne	a4,a5,800038f0 <dirlookup+0x3a>
    800038d6:	892a                	mv	s2,a0
    800038d8:	8aae                	mv	s5,a1
    800038da:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    800038dc:	457c                	lw	a5,76(a0)
    800038de:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038e0:	fa040a13          	addi	s4,s0,-96
    800038e4:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    800038e6:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800038ea:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    800038ec:	e39d                	bnez	a5,80003912 <dirlookup+0x5c>
    800038ee:	a8b9                	j	8000394c <dirlookup+0x96>
    panic("dirlookup not DIR");
    800038f0:	00004517          	auipc	a0,0x4
    800038f4:	c1050513          	addi	a0,a0,-1008 # 80007500 <etext+0x500>
    800038f8:	f2dfc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    800038fc:	00004517          	auipc	a0,0x4
    80003900:	c1c50513          	addi	a0,a0,-996 # 80007518 <etext+0x518>
    80003904:	f21fc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003908:	24c1                	addiw	s1,s1,16
    8000390a:	04c92783          	lw	a5,76(s2)
    8000390e:	02f4fe63          	bgeu	s1,a5,8000394a <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003912:	874e                	mv	a4,s3
    80003914:	86a6                	mv	a3,s1
    80003916:	8652                	mv	a2,s4
    80003918:	4581                	li	a1,0
    8000391a:	854a                	mv	a0,s2
    8000391c:	d93ff0ef          	jal	800036ae <readi>
    80003920:	fd351ee3          	bne	a0,s3,800038fc <dirlookup+0x46>
    if(de.inum == 0)
    80003924:	fa045783          	lhu	a5,-96(s0)
    80003928:	d3e5                	beqz	a5,80003908 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    8000392a:	85da                	mv	a1,s6
    8000392c:	8556                	mv	a0,s5
    8000392e:	f73ff0ef          	jal	800038a0 <namecmp>
    80003932:	f979                	bnez	a0,80003908 <dirlookup+0x52>
      if(poff)
    80003934:	000b8463          	beqz	s7,8000393c <dirlookup+0x86>
        *poff = off;
    80003938:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    8000393c:	fa045583          	lhu	a1,-96(s0)
    80003940:	00092503          	lw	a0,0(s2)
    80003944:	f66ff0ef          	jal	800030aa <iget>
    80003948:	a011                	j	8000394c <dirlookup+0x96>
  return 0;
    8000394a:	4501                	li	a0,0
}
    8000394c:	60e6                	ld	ra,88(sp)
    8000394e:	6446                	ld	s0,80(sp)
    80003950:	64a6                	ld	s1,72(sp)
    80003952:	6906                	ld	s2,64(sp)
    80003954:	79e2                	ld	s3,56(sp)
    80003956:	7a42                	ld	s4,48(sp)
    80003958:	7aa2                	ld	s5,40(sp)
    8000395a:	7b02                	ld	s6,32(sp)
    8000395c:	6be2                	ld	s7,24(sp)
    8000395e:	6125                	addi	sp,sp,96
    80003960:	8082                	ret

0000000080003962 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003962:	711d                	addi	sp,sp,-96
    80003964:	ec86                	sd	ra,88(sp)
    80003966:	e8a2                	sd	s0,80(sp)
    80003968:	e4a6                	sd	s1,72(sp)
    8000396a:	e0ca                	sd	s2,64(sp)
    8000396c:	fc4e                	sd	s3,56(sp)
    8000396e:	f852                	sd	s4,48(sp)
    80003970:	f456                	sd	s5,40(sp)
    80003972:	f05a                	sd	s6,32(sp)
    80003974:	ec5e                	sd	s7,24(sp)
    80003976:	e862                	sd	s8,16(sp)
    80003978:	e466                	sd	s9,8(sp)
    8000397a:	e06a                	sd	s10,0(sp)
    8000397c:	1080                	addi	s0,sp,96
    8000397e:	84aa                	mv	s1,a0
    80003980:	8b2e                	mv	s6,a1
    80003982:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003984:	00054703          	lbu	a4,0(a0)
    80003988:	02f00793          	li	a5,47
    8000398c:	00f70f63          	beq	a4,a5,800039aa <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003990:	878fe0ef          	jal	80001a08 <myproc>
    80003994:	15053503          	ld	a0,336(a0)
    80003998:	94fff0ef          	jal	800032e6 <idup>
    8000399c:	8a2a                	mv	s4,a0
  while(*path == '/')
    8000399e:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    800039a2:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    800039a4:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    800039a6:	4b85                	li	s7,1
    800039a8:	a879                	j	80003a46 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    800039aa:	4585                	li	a1,1
    800039ac:	852e                	mv	a0,a1
    800039ae:	efcff0ef          	jal	800030aa <iget>
    800039b2:	8a2a                	mv	s4,a0
    800039b4:	b7ed                	j	8000399e <namex+0x3c>
      iunlockput(ip);
    800039b6:	8552                	mv	a0,s4
    800039b8:	b71ff0ef          	jal	80003528 <iunlockput>
      return 0;
    800039bc:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    800039be:	8552                	mv	a0,s4
    800039c0:	60e6                	ld	ra,88(sp)
    800039c2:	6446                	ld	s0,80(sp)
    800039c4:	64a6                	ld	s1,72(sp)
    800039c6:	6906                	ld	s2,64(sp)
    800039c8:	79e2                	ld	s3,56(sp)
    800039ca:	7a42                	ld	s4,48(sp)
    800039cc:	7aa2                	ld	s5,40(sp)
    800039ce:	7b02                	ld	s6,32(sp)
    800039d0:	6be2                	ld	s7,24(sp)
    800039d2:	6c42                	ld	s8,16(sp)
    800039d4:	6ca2                	ld	s9,8(sp)
    800039d6:	6d02                	ld	s10,0(sp)
    800039d8:	6125                	addi	sp,sp,96
    800039da:	8082                	ret
      iunlock(ip);
    800039dc:	8552                	mv	a0,s4
    800039de:	9edff0ef          	jal	800033ca <iunlock>
      return ip;
    800039e2:	bff1                	j	800039be <namex+0x5c>
      iunlockput(ip);
    800039e4:	8552                	mv	a0,s4
    800039e6:	b43ff0ef          	jal	80003528 <iunlockput>
      return 0;
    800039ea:	8a4a                	mv	s4,s2
    800039ec:	bfc9                	j	800039be <namex+0x5c>
  len = path - s;
    800039ee:	40990633          	sub	a2,s2,s1
    800039f2:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    800039f6:	09ac5463          	bge	s8,s10,80003a7e <namex+0x11c>
    memmove(name, s, DIRSIZ);
    800039fa:	8666                	mv	a2,s9
    800039fc:	85a6                	mv	a1,s1
    800039fe:	8556                	mv	a0,s5
    80003a00:	b58fd0ef          	jal	80000d58 <memmove>
    80003a04:	84ca                	mv	s1,s2
  while(*path == '/')
    80003a06:	0004c783          	lbu	a5,0(s1)
    80003a0a:	01379763          	bne	a5,s3,80003a18 <namex+0xb6>
    path++;
    80003a0e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003a10:	0004c783          	lbu	a5,0(s1)
    80003a14:	ff378de3          	beq	a5,s3,80003a0e <namex+0xac>
    ilock(ip);
    80003a18:	8552                	mv	a0,s4
    80003a1a:	903ff0ef          	jal	8000331c <ilock>
    if(ip->type != T_DIR){
    80003a1e:	044a1783          	lh	a5,68(s4)
    80003a22:	f9779ae3          	bne	a5,s7,800039b6 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80003a26:	000b0563          	beqz	s6,80003a30 <namex+0xce>
    80003a2a:	0004c783          	lbu	a5,0(s1)
    80003a2e:	d7dd                	beqz	a5,800039dc <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003a30:	4601                	li	a2,0
    80003a32:	85d6                	mv	a1,s5
    80003a34:	8552                	mv	a0,s4
    80003a36:	e81ff0ef          	jal	800038b6 <dirlookup>
    80003a3a:	892a                	mv	s2,a0
    80003a3c:	d545                	beqz	a0,800039e4 <namex+0x82>
    iunlockput(ip);
    80003a3e:	8552                	mv	a0,s4
    80003a40:	ae9ff0ef          	jal	80003528 <iunlockput>
    ip = next;
    80003a44:	8a4a                	mv	s4,s2
  while(*path == '/')
    80003a46:	0004c783          	lbu	a5,0(s1)
    80003a4a:	01379763          	bne	a5,s3,80003a58 <namex+0xf6>
    path++;
    80003a4e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003a50:	0004c783          	lbu	a5,0(s1)
    80003a54:	ff378de3          	beq	a5,s3,80003a4e <namex+0xec>
  if(*path == 0)
    80003a58:	cf8d                	beqz	a5,80003a92 <namex+0x130>
  while(*path != '/' && *path != 0)
    80003a5a:	0004c783          	lbu	a5,0(s1)
    80003a5e:	fd178713          	addi	a4,a5,-47
    80003a62:	cb19                	beqz	a4,80003a78 <namex+0x116>
    80003a64:	cb91                	beqz	a5,80003a78 <namex+0x116>
    80003a66:	8926                	mv	s2,s1
    path++;
    80003a68:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80003a6a:	00094783          	lbu	a5,0(s2)
    80003a6e:	fd178713          	addi	a4,a5,-47
    80003a72:	df35                	beqz	a4,800039ee <namex+0x8c>
    80003a74:	fbf5                	bnez	a5,80003a68 <namex+0x106>
    80003a76:	bfa5                	j	800039ee <namex+0x8c>
    80003a78:	8926                	mv	s2,s1
  len = path - s;
    80003a7a:	4d01                	li	s10,0
    80003a7c:	4601                	li	a2,0
    memmove(name, s, len);
    80003a7e:	2601                	sext.w	a2,a2
    80003a80:	85a6                	mv	a1,s1
    80003a82:	8556                	mv	a0,s5
    80003a84:	ad4fd0ef          	jal	80000d58 <memmove>
    name[len] = 0;
    80003a88:	9d56                	add	s10,s10,s5
    80003a8a:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffdb9c8>
    80003a8e:	84ca                	mv	s1,s2
    80003a90:	bf9d                	j	80003a06 <namex+0xa4>
  if(nameiparent){
    80003a92:	f20b06e3          	beqz	s6,800039be <namex+0x5c>
    iput(ip);
    80003a96:	8552                	mv	a0,s4
    80003a98:	a07ff0ef          	jal	8000349e <iput>
    return 0;
    80003a9c:	4a01                	li	s4,0
    80003a9e:	b705                	j	800039be <namex+0x5c>

0000000080003aa0 <dirlink>:
{
    80003aa0:	715d                	addi	sp,sp,-80
    80003aa2:	e486                	sd	ra,72(sp)
    80003aa4:	e0a2                	sd	s0,64(sp)
    80003aa6:	f84a                	sd	s2,48(sp)
    80003aa8:	ec56                	sd	s5,24(sp)
    80003aaa:	e85a                	sd	s6,16(sp)
    80003aac:	0880                	addi	s0,sp,80
    80003aae:	892a                	mv	s2,a0
    80003ab0:	8aae                	mv	s5,a1
    80003ab2:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003ab4:	4601                	li	a2,0
    80003ab6:	e01ff0ef          	jal	800038b6 <dirlookup>
    80003aba:	ed1d                	bnez	a0,80003af8 <dirlink+0x58>
    80003abc:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003abe:	04c92483          	lw	s1,76(s2)
    80003ac2:	c4b9                	beqz	s1,80003b10 <dirlink+0x70>
    80003ac4:	f44e                	sd	s3,40(sp)
    80003ac6:	f052                	sd	s4,32(sp)
    80003ac8:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003aca:	fb040a13          	addi	s4,s0,-80
    80003ace:	49c1                	li	s3,16
    80003ad0:	874e                	mv	a4,s3
    80003ad2:	86a6                	mv	a3,s1
    80003ad4:	8652                	mv	a2,s4
    80003ad6:	4581                	li	a1,0
    80003ad8:	854a                	mv	a0,s2
    80003ada:	bd5ff0ef          	jal	800036ae <readi>
    80003ade:	03351163          	bne	a0,s3,80003b00 <dirlink+0x60>
    if(de.inum == 0)
    80003ae2:	fb045783          	lhu	a5,-80(s0)
    80003ae6:	c39d                	beqz	a5,80003b0c <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ae8:	24c1                	addiw	s1,s1,16
    80003aea:	04c92783          	lw	a5,76(s2)
    80003aee:	fef4e1e3          	bltu	s1,a5,80003ad0 <dirlink+0x30>
    80003af2:	79a2                	ld	s3,40(sp)
    80003af4:	7a02                	ld	s4,32(sp)
    80003af6:	a829                	j	80003b10 <dirlink+0x70>
    iput(ip);
    80003af8:	9a7ff0ef          	jal	8000349e <iput>
    return -1;
    80003afc:	557d                	li	a0,-1
    80003afe:	a83d                	j	80003b3c <dirlink+0x9c>
      panic("dirlink read");
    80003b00:	00004517          	auipc	a0,0x4
    80003b04:	a2850513          	addi	a0,a0,-1496 # 80007528 <etext+0x528>
    80003b08:	d1dfc0ef          	jal	80000824 <panic>
    80003b0c:	79a2                	ld	s3,40(sp)
    80003b0e:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003b10:	4639                	li	a2,14
    80003b12:	85d6                	mv	a1,s5
    80003b14:	fb240513          	addi	a0,s0,-78
    80003b18:	aeefd0ef          	jal	80000e06 <strncpy>
  de.inum = inum;
    80003b1c:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b20:	4741                	li	a4,16
    80003b22:	86a6                	mv	a3,s1
    80003b24:	fb040613          	addi	a2,s0,-80
    80003b28:	4581                	li	a1,0
    80003b2a:	854a                	mv	a0,s2
    80003b2c:	c75ff0ef          	jal	800037a0 <writei>
    80003b30:	1541                	addi	a0,a0,-16
    80003b32:	00a03533          	snez	a0,a0
    80003b36:	40a0053b          	negw	a0,a0
    80003b3a:	74e2                	ld	s1,56(sp)
}
    80003b3c:	60a6                	ld	ra,72(sp)
    80003b3e:	6406                	ld	s0,64(sp)
    80003b40:	7942                	ld	s2,48(sp)
    80003b42:	6ae2                	ld	s5,24(sp)
    80003b44:	6b42                	ld	s6,16(sp)
    80003b46:	6161                	addi	sp,sp,80
    80003b48:	8082                	ret

0000000080003b4a <namei>:

struct inode*
namei(char *path)
{
    80003b4a:	1101                	addi	sp,sp,-32
    80003b4c:	ec06                	sd	ra,24(sp)
    80003b4e:	e822                	sd	s0,16(sp)
    80003b50:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003b52:	fe040613          	addi	a2,s0,-32
    80003b56:	4581                	li	a1,0
    80003b58:	e0bff0ef          	jal	80003962 <namex>
}
    80003b5c:	60e2                	ld	ra,24(sp)
    80003b5e:	6442                	ld	s0,16(sp)
    80003b60:	6105                	addi	sp,sp,32
    80003b62:	8082                	ret

0000000080003b64 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003b64:	1141                	addi	sp,sp,-16
    80003b66:	e406                	sd	ra,8(sp)
    80003b68:	e022                	sd	s0,0(sp)
    80003b6a:	0800                	addi	s0,sp,16
    80003b6c:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003b6e:	4585                	li	a1,1
    80003b70:	df3ff0ef          	jal	80003962 <namex>
}
    80003b74:	60a2                	ld	ra,8(sp)
    80003b76:	6402                	ld	s0,0(sp)
    80003b78:	0141                	addi	sp,sp,16
    80003b7a:	8082                	ret

0000000080003b7c <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003b7c:	1101                	addi	sp,sp,-32
    80003b7e:	ec06                	sd	ra,24(sp)
    80003b80:	e822                	sd	s0,16(sp)
    80003b82:	e426                	sd	s1,8(sp)
    80003b84:	e04a                	sd	s2,0(sp)
    80003b86:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003b88:	0001f917          	auipc	s2,0x1f
    80003b8c:	87090913          	addi	s2,s2,-1936 # 800223f8 <log>
    80003b90:	01892583          	lw	a1,24(s2)
    80003b94:	02492503          	lw	a0,36(s2)
    80003b98:	8ecff0ef          	jal	80002c84 <bread>
    80003b9c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003b9e:	02892603          	lw	a2,40(s2)
    80003ba2:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003ba4:	00c05f63          	blez	a2,80003bc2 <write_head+0x46>
    80003ba8:	0001f717          	auipc	a4,0x1f
    80003bac:	87c70713          	addi	a4,a4,-1924 # 80022424 <log+0x2c>
    80003bb0:	87aa                	mv	a5,a0
    80003bb2:	060a                	slli	a2,a2,0x2
    80003bb4:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003bb6:	4314                	lw	a3,0(a4)
    80003bb8:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003bba:	0711                	addi	a4,a4,4
    80003bbc:	0791                	addi	a5,a5,4
    80003bbe:	fec79ce3          	bne	a5,a2,80003bb6 <write_head+0x3a>
  }
  bwrite(buf);
    80003bc2:	8526                	mv	a0,s1
    80003bc4:	996ff0ef          	jal	80002d5a <bwrite>
  brelse(buf);
    80003bc8:	8526                	mv	a0,s1
    80003bca:	9c2ff0ef          	jal	80002d8c <brelse>
}
    80003bce:	60e2                	ld	ra,24(sp)
    80003bd0:	6442                	ld	s0,16(sp)
    80003bd2:	64a2                	ld	s1,8(sp)
    80003bd4:	6902                	ld	s2,0(sp)
    80003bd6:	6105                	addi	sp,sp,32
    80003bd8:	8082                	ret

0000000080003bda <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bda:	0001f797          	auipc	a5,0x1f
    80003bde:	8467a783          	lw	a5,-1978(a5) # 80022420 <log+0x28>
    80003be2:	0cf05163          	blez	a5,80003ca4 <install_trans+0xca>
{
    80003be6:	715d                	addi	sp,sp,-80
    80003be8:	e486                	sd	ra,72(sp)
    80003bea:	e0a2                	sd	s0,64(sp)
    80003bec:	fc26                	sd	s1,56(sp)
    80003bee:	f84a                	sd	s2,48(sp)
    80003bf0:	f44e                	sd	s3,40(sp)
    80003bf2:	f052                	sd	s4,32(sp)
    80003bf4:	ec56                	sd	s5,24(sp)
    80003bf6:	e85a                	sd	s6,16(sp)
    80003bf8:	e45e                	sd	s7,8(sp)
    80003bfa:	e062                	sd	s8,0(sp)
    80003bfc:	0880                	addi	s0,sp,80
    80003bfe:	8b2a                	mv	s6,a0
    80003c00:	0001fa97          	auipc	s5,0x1f
    80003c04:	824a8a93          	addi	s5,s5,-2012 # 80022424 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c08:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c0a:	00004c17          	auipc	s8,0x4
    80003c0e:	92ec0c13          	addi	s8,s8,-1746 # 80007538 <etext+0x538>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003c12:	0001ea17          	auipc	s4,0x1e
    80003c16:	7e6a0a13          	addi	s4,s4,2022 # 800223f8 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003c1a:	40000b93          	li	s7,1024
    80003c1e:	a025                	j	80003c46 <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c20:	000aa603          	lw	a2,0(s5)
    80003c24:	85ce                	mv	a1,s3
    80003c26:	8562                	mv	a0,s8
    80003c28:	8d3fc0ef          	jal	800004fa <printf>
    80003c2c:	a839                	j	80003c4a <install_trans+0x70>
    brelse(lbuf);
    80003c2e:	854a                	mv	a0,s2
    80003c30:	95cff0ef          	jal	80002d8c <brelse>
    brelse(dbuf);
    80003c34:	8526                	mv	a0,s1
    80003c36:	956ff0ef          	jal	80002d8c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c3a:	2985                	addiw	s3,s3,1
    80003c3c:	0a91                	addi	s5,s5,4
    80003c3e:	028a2783          	lw	a5,40(s4)
    80003c42:	04f9d563          	bge	s3,a5,80003c8c <install_trans+0xb2>
    if(recovering) {
    80003c46:	fc0b1de3          	bnez	s6,80003c20 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003c4a:	018a2583          	lw	a1,24(s4)
    80003c4e:	013585bb          	addw	a1,a1,s3
    80003c52:	2585                	addiw	a1,a1,1
    80003c54:	024a2503          	lw	a0,36(s4)
    80003c58:	82cff0ef          	jal	80002c84 <bread>
    80003c5c:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003c5e:	000aa583          	lw	a1,0(s5)
    80003c62:	024a2503          	lw	a0,36(s4)
    80003c66:	81eff0ef          	jal	80002c84 <bread>
    80003c6a:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003c6c:	865e                	mv	a2,s7
    80003c6e:	05890593          	addi	a1,s2,88
    80003c72:	05850513          	addi	a0,a0,88
    80003c76:	8e2fd0ef          	jal	80000d58 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003c7a:	8526                	mv	a0,s1
    80003c7c:	8deff0ef          	jal	80002d5a <bwrite>
    if(recovering == 0)
    80003c80:	fa0b17e3          	bnez	s6,80003c2e <install_trans+0x54>
      bunpin(dbuf);
    80003c84:	8526                	mv	a0,s1
    80003c86:	9beff0ef          	jal	80002e44 <bunpin>
    80003c8a:	b755                	j	80003c2e <install_trans+0x54>
}
    80003c8c:	60a6                	ld	ra,72(sp)
    80003c8e:	6406                	ld	s0,64(sp)
    80003c90:	74e2                	ld	s1,56(sp)
    80003c92:	7942                	ld	s2,48(sp)
    80003c94:	79a2                	ld	s3,40(sp)
    80003c96:	7a02                	ld	s4,32(sp)
    80003c98:	6ae2                	ld	s5,24(sp)
    80003c9a:	6b42                	ld	s6,16(sp)
    80003c9c:	6ba2                	ld	s7,8(sp)
    80003c9e:	6c02                	ld	s8,0(sp)
    80003ca0:	6161                	addi	sp,sp,80
    80003ca2:	8082                	ret
    80003ca4:	8082                	ret

0000000080003ca6 <initlog>:
{
    80003ca6:	7179                	addi	sp,sp,-48
    80003ca8:	f406                	sd	ra,40(sp)
    80003caa:	f022                	sd	s0,32(sp)
    80003cac:	ec26                	sd	s1,24(sp)
    80003cae:	e84a                	sd	s2,16(sp)
    80003cb0:	e44e                	sd	s3,8(sp)
    80003cb2:	1800                	addi	s0,sp,48
    80003cb4:	84aa                	mv	s1,a0
    80003cb6:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003cb8:	0001e917          	auipc	s2,0x1e
    80003cbc:	74090913          	addi	s2,s2,1856 # 800223f8 <log>
    80003cc0:	00004597          	auipc	a1,0x4
    80003cc4:	89858593          	addi	a1,a1,-1896 # 80007558 <etext+0x558>
    80003cc8:	854a                	mv	a0,s2
    80003cca:	ed5fc0ef          	jal	80000b9e <initlock>
  log.start = sb->logstart;
    80003cce:	0149a583          	lw	a1,20(s3)
    80003cd2:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003cd6:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003cda:	8526                	mv	a0,s1
    80003cdc:	fa9fe0ef          	jal	80002c84 <bread>
  log.lh.n = lh->n;
    80003ce0:	4d30                	lw	a2,88(a0)
    80003ce2:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003ce6:	00c05f63          	blez	a2,80003d04 <initlog+0x5e>
    80003cea:	87aa                	mv	a5,a0
    80003cec:	0001e717          	auipc	a4,0x1e
    80003cf0:	73870713          	addi	a4,a4,1848 # 80022424 <log+0x2c>
    80003cf4:	060a                	slli	a2,a2,0x2
    80003cf6:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003cf8:	4ff4                	lw	a3,92(a5)
    80003cfa:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003cfc:	0791                	addi	a5,a5,4
    80003cfe:	0711                	addi	a4,a4,4
    80003d00:	fec79ce3          	bne	a5,a2,80003cf8 <initlog+0x52>
  brelse(buf);
    80003d04:	888ff0ef          	jal	80002d8c <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003d08:	4505                	li	a0,1
    80003d0a:	ed1ff0ef          	jal	80003bda <install_trans>
  log.lh.n = 0;
    80003d0e:	0001e797          	auipc	a5,0x1e
    80003d12:	7007a923          	sw	zero,1810(a5) # 80022420 <log+0x28>
  write_head(); // clear the log
    80003d16:	e67ff0ef          	jal	80003b7c <write_head>
}
    80003d1a:	70a2                	ld	ra,40(sp)
    80003d1c:	7402                	ld	s0,32(sp)
    80003d1e:	64e2                	ld	s1,24(sp)
    80003d20:	6942                	ld	s2,16(sp)
    80003d22:	69a2                	ld	s3,8(sp)
    80003d24:	6145                	addi	sp,sp,48
    80003d26:	8082                	ret

0000000080003d28 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003d28:	1101                	addi	sp,sp,-32
    80003d2a:	ec06                	sd	ra,24(sp)
    80003d2c:	e822                	sd	s0,16(sp)
    80003d2e:	e426                	sd	s1,8(sp)
    80003d30:	e04a                	sd	s2,0(sp)
    80003d32:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003d34:	0001e517          	auipc	a0,0x1e
    80003d38:	6c450513          	addi	a0,a0,1732 # 800223f8 <log>
    80003d3c:	eedfc0ef          	jal	80000c28 <acquire>
  while(1){
    if(log.committing){
    80003d40:	0001e497          	auipc	s1,0x1e
    80003d44:	6b848493          	addi	s1,s1,1720 # 800223f8 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003d48:	4979                	li	s2,30
    80003d4a:	a029                	j	80003d54 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003d4c:	85a6                	mv	a1,s1
    80003d4e:	8526                	mv	a0,s1
    80003d50:	af6fe0ef          	jal	80002046 <sleep>
    if(log.committing){
    80003d54:	509c                	lw	a5,32(s1)
    80003d56:	fbfd                	bnez	a5,80003d4c <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003d58:	4cd8                	lw	a4,28(s1)
    80003d5a:	2705                	addiw	a4,a4,1
    80003d5c:	0027179b          	slliw	a5,a4,0x2
    80003d60:	9fb9                	addw	a5,a5,a4
    80003d62:	0017979b          	slliw	a5,a5,0x1
    80003d66:	5494                	lw	a3,40(s1)
    80003d68:	9fb5                	addw	a5,a5,a3
    80003d6a:	00f95763          	bge	s2,a5,80003d78 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003d6e:	85a6                	mv	a1,s1
    80003d70:	8526                	mv	a0,s1
    80003d72:	ad4fe0ef          	jal	80002046 <sleep>
    80003d76:	bff9                	j	80003d54 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003d78:	0001e797          	auipc	a5,0x1e
    80003d7c:	68e7ae23          	sw	a4,1692(a5) # 80022414 <log+0x1c>
      release(&log.lock);
    80003d80:	0001e517          	auipc	a0,0x1e
    80003d84:	67850513          	addi	a0,a0,1656 # 800223f8 <log>
    80003d88:	f35fc0ef          	jal	80000cbc <release>
      break;
    }
  }
}
    80003d8c:	60e2                	ld	ra,24(sp)
    80003d8e:	6442                	ld	s0,16(sp)
    80003d90:	64a2                	ld	s1,8(sp)
    80003d92:	6902                	ld	s2,0(sp)
    80003d94:	6105                	addi	sp,sp,32
    80003d96:	8082                	ret

0000000080003d98 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003d98:	7139                	addi	sp,sp,-64
    80003d9a:	fc06                	sd	ra,56(sp)
    80003d9c:	f822                	sd	s0,48(sp)
    80003d9e:	f426                	sd	s1,40(sp)
    80003da0:	f04a                	sd	s2,32(sp)
    80003da2:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003da4:	0001e497          	auipc	s1,0x1e
    80003da8:	65448493          	addi	s1,s1,1620 # 800223f8 <log>
    80003dac:	8526                	mv	a0,s1
    80003dae:	e7bfc0ef          	jal	80000c28 <acquire>
  log.outstanding -= 1;
    80003db2:	4cdc                	lw	a5,28(s1)
    80003db4:	37fd                	addiw	a5,a5,-1
    80003db6:	893e                	mv	s2,a5
    80003db8:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003dba:	509c                	lw	a5,32(s1)
    80003dbc:	e7b1                	bnez	a5,80003e08 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003dbe:	04091e63          	bnez	s2,80003e1a <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80003dc2:	0001e497          	auipc	s1,0x1e
    80003dc6:	63648493          	addi	s1,s1,1590 # 800223f8 <log>
    80003dca:	4785                	li	a5,1
    80003dcc:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003dce:	8526                	mv	a0,s1
    80003dd0:	eedfc0ef          	jal	80000cbc <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003dd4:	549c                	lw	a5,40(s1)
    80003dd6:	06f04463          	bgtz	a5,80003e3e <end_op+0xa6>
    acquire(&log.lock);
    80003dda:	0001e517          	auipc	a0,0x1e
    80003dde:	61e50513          	addi	a0,a0,1566 # 800223f8 <log>
    80003de2:	e47fc0ef          	jal	80000c28 <acquire>
    log.committing = 0;
    80003de6:	0001e797          	auipc	a5,0x1e
    80003dea:	6207a923          	sw	zero,1586(a5) # 80022418 <log+0x20>
    wakeup(&log);
    80003dee:	0001e517          	auipc	a0,0x1e
    80003df2:	60a50513          	addi	a0,a0,1546 # 800223f8 <log>
    80003df6:	a9cfe0ef          	jal	80002092 <wakeup>
    release(&log.lock);
    80003dfa:	0001e517          	auipc	a0,0x1e
    80003dfe:	5fe50513          	addi	a0,a0,1534 # 800223f8 <log>
    80003e02:	ebbfc0ef          	jal	80000cbc <release>
}
    80003e06:	a035                	j	80003e32 <end_op+0x9a>
    80003e08:	ec4e                	sd	s3,24(sp)
    80003e0a:	e852                	sd	s4,16(sp)
    80003e0c:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003e0e:	00003517          	auipc	a0,0x3
    80003e12:	75250513          	addi	a0,a0,1874 # 80007560 <etext+0x560>
    80003e16:	a0ffc0ef          	jal	80000824 <panic>
    wakeup(&log);
    80003e1a:	0001e517          	auipc	a0,0x1e
    80003e1e:	5de50513          	addi	a0,a0,1502 # 800223f8 <log>
    80003e22:	a70fe0ef          	jal	80002092 <wakeup>
  release(&log.lock);
    80003e26:	0001e517          	auipc	a0,0x1e
    80003e2a:	5d250513          	addi	a0,a0,1490 # 800223f8 <log>
    80003e2e:	e8ffc0ef          	jal	80000cbc <release>
}
    80003e32:	70e2                	ld	ra,56(sp)
    80003e34:	7442                	ld	s0,48(sp)
    80003e36:	74a2                	ld	s1,40(sp)
    80003e38:	7902                	ld	s2,32(sp)
    80003e3a:	6121                	addi	sp,sp,64
    80003e3c:	8082                	ret
    80003e3e:	ec4e                	sd	s3,24(sp)
    80003e40:	e852                	sd	s4,16(sp)
    80003e42:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e44:	0001ea97          	auipc	s5,0x1e
    80003e48:	5e0a8a93          	addi	s5,s5,1504 # 80022424 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003e4c:	0001ea17          	auipc	s4,0x1e
    80003e50:	5aca0a13          	addi	s4,s4,1452 # 800223f8 <log>
    80003e54:	018a2583          	lw	a1,24(s4)
    80003e58:	012585bb          	addw	a1,a1,s2
    80003e5c:	2585                	addiw	a1,a1,1
    80003e5e:	024a2503          	lw	a0,36(s4)
    80003e62:	e23fe0ef          	jal	80002c84 <bread>
    80003e66:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003e68:	000aa583          	lw	a1,0(s5)
    80003e6c:	024a2503          	lw	a0,36(s4)
    80003e70:	e15fe0ef          	jal	80002c84 <bread>
    80003e74:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003e76:	40000613          	li	a2,1024
    80003e7a:	05850593          	addi	a1,a0,88
    80003e7e:	05848513          	addi	a0,s1,88
    80003e82:	ed7fc0ef          	jal	80000d58 <memmove>
    bwrite(to);  // write the log
    80003e86:	8526                	mv	a0,s1
    80003e88:	ed3fe0ef          	jal	80002d5a <bwrite>
    brelse(from);
    80003e8c:	854e                	mv	a0,s3
    80003e8e:	efffe0ef          	jal	80002d8c <brelse>
    brelse(to);
    80003e92:	8526                	mv	a0,s1
    80003e94:	ef9fe0ef          	jal	80002d8c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e98:	2905                	addiw	s2,s2,1
    80003e9a:	0a91                	addi	s5,s5,4
    80003e9c:	028a2783          	lw	a5,40(s4)
    80003ea0:	faf94ae3          	blt	s2,a5,80003e54 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003ea4:	cd9ff0ef          	jal	80003b7c <write_head>
    install_trans(0); // Now install writes to home locations
    80003ea8:	4501                	li	a0,0
    80003eaa:	d31ff0ef          	jal	80003bda <install_trans>
    log.lh.n = 0;
    80003eae:	0001e797          	auipc	a5,0x1e
    80003eb2:	5607a923          	sw	zero,1394(a5) # 80022420 <log+0x28>
    write_head();    // Erase the transaction from the log
    80003eb6:	cc7ff0ef          	jal	80003b7c <write_head>
    80003eba:	69e2                	ld	s3,24(sp)
    80003ebc:	6a42                	ld	s4,16(sp)
    80003ebe:	6aa2                	ld	s5,8(sp)
    80003ec0:	bf29                	j	80003dda <end_op+0x42>

0000000080003ec2 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003ec2:	1101                	addi	sp,sp,-32
    80003ec4:	ec06                	sd	ra,24(sp)
    80003ec6:	e822                	sd	s0,16(sp)
    80003ec8:	e426                	sd	s1,8(sp)
    80003eca:	1000                	addi	s0,sp,32
    80003ecc:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003ece:	0001e517          	auipc	a0,0x1e
    80003ed2:	52a50513          	addi	a0,a0,1322 # 800223f8 <log>
    80003ed6:	d53fc0ef          	jal	80000c28 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003eda:	0001e617          	auipc	a2,0x1e
    80003ede:	54662603          	lw	a2,1350(a2) # 80022420 <log+0x28>
    80003ee2:	47f5                	li	a5,29
    80003ee4:	04c7cd63          	blt	a5,a2,80003f3e <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003ee8:	0001e797          	auipc	a5,0x1e
    80003eec:	52c7a783          	lw	a5,1324(a5) # 80022414 <log+0x1c>
    80003ef0:	04f05d63          	blez	a5,80003f4a <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003ef4:	4781                	li	a5,0
    80003ef6:	06c05063          	blez	a2,80003f56 <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003efa:	44cc                	lw	a1,12(s1)
    80003efc:	0001e717          	auipc	a4,0x1e
    80003f00:	52870713          	addi	a4,a4,1320 # 80022424 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80003f04:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003f06:	4314                	lw	a3,0(a4)
    80003f08:	04b68763          	beq	a3,a1,80003f56 <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80003f0c:	2785                	addiw	a5,a5,1
    80003f0e:	0711                	addi	a4,a4,4
    80003f10:	fef61be3          	bne	a2,a5,80003f06 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003f14:	060a                	slli	a2,a2,0x2
    80003f16:	02060613          	addi	a2,a2,32
    80003f1a:	0001e797          	auipc	a5,0x1e
    80003f1e:	4de78793          	addi	a5,a5,1246 # 800223f8 <log>
    80003f22:	97b2                	add	a5,a5,a2
    80003f24:	44d8                	lw	a4,12(s1)
    80003f26:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003f28:	8526                	mv	a0,s1
    80003f2a:	ee7fe0ef          	jal	80002e10 <bpin>
    log.lh.n++;
    80003f2e:	0001e717          	auipc	a4,0x1e
    80003f32:	4ca70713          	addi	a4,a4,1226 # 800223f8 <log>
    80003f36:	571c                	lw	a5,40(a4)
    80003f38:	2785                	addiw	a5,a5,1
    80003f3a:	d71c                	sw	a5,40(a4)
    80003f3c:	a815                	j	80003f70 <log_write+0xae>
    panic("too big a transaction");
    80003f3e:	00003517          	auipc	a0,0x3
    80003f42:	63250513          	addi	a0,a0,1586 # 80007570 <etext+0x570>
    80003f46:	8dffc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    80003f4a:	00003517          	auipc	a0,0x3
    80003f4e:	63e50513          	addi	a0,a0,1598 # 80007588 <etext+0x588>
    80003f52:	8d3fc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    80003f56:	00279693          	slli	a3,a5,0x2
    80003f5a:	02068693          	addi	a3,a3,32
    80003f5e:	0001e717          	auipc	a4,0x1e
    80003f62:	49a70713          	addi	a4,a4,1178 # 800223f8 <log>
    80003f66:	9736                	add	a4,a4,a3
    80003f68:	44d4                	lw	a3,12(s1)
    80003f6a:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003f6c:	faf60ee3          	beq	a2,a5,80003f28 <log_write+0x66>
  }
  release(&log.lock);
    80003f70:	0001e517          	auipc	a0,0x1e
    80003f74:	48850513          	addi	a0,a0,1160 # 800223f8 <log>
    80003f78:	d45fc0ef          	jal	80000cbc <release>
}
    80003f7c:	60e2                	ld	ra,24(sp)
    80003f7e:	6442                	ld	s0,16(sp)
    80003f80:	64a2                	ld	s1,8(sp)
    80003f82:	6105                	addi	sp,sp,32
    80003f84:	8082                	ret

0000000080003f86 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003f86:	1101                	addi	sp,sp,-32
    80003f88:	ec06                	sd	ra,24(sp)
    80003f8a:	e822                	sd	s0,16(sp)
    80003f8c:	e426                	sd	s1,8(sp)
    80003f8e:	e04a                	sd	s2,0(sp)
    80003f90:	1000                	addi	s0,sp,32
    80003f92:	84aa                	mv	s1,a0
    80003f94:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003f96:	00003597          	auipc	a1,0x3
    80003f9a:	61258593          	addi	a1,a1,1554 # 800075a8 <etext+0x5a8>
    80003f9e:	0521                	addi	a0,a0,8
    80003fa0:	bfffc0ef          	jal	80000b9e <initlock>
  lk->name = name;
    80003fa4:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003fa8:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003fac:	0204a423          	sw	zero,40(s1)
}
    80003fb0:	60e2                	ld	ra,24(sp)
    80003fb2:	6442                	ld	s0,16(sp)
    80003fb4:	64a2                	ld	s1,8(sp)
    80003fb6:	6902                	ld	s2,0(sp)
    80003fb8:	6105                	addi	sp,sp,32
    80003fba:	8082                	ret

0000000080003fbc <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003fbc:	1101                	addi	sp,sp,-32
    80003fbe:	ec06                	sd	ra,24(sp)
    80003fc0:	e822                	sd	s0,16(sp)
    80003fc2:	e426                	sd	s1,8(sp)
    80003fc4:	e04a                	sd	s2,0(sp)
    80003fc6:	1000                	addi	s0,sp,32
    80003fc8:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003fca:	00850913          	addi	s2,a0,8
    80003fce:	854a                	mv	a0,s2
    80003fd0:	c59fc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    80003fd4:	409c                	lw	a5,0(s1)
    80003fd6:	c799                	beqz	a5,80003fe4 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003fd8:	85ca                	mv	a1,s2
    80003fda:	8526                	mv	a0,s1
    80003fdc:	86afe0ef          	jal	80002046 <sleep>
  while (lk->locked) {
    80003fe0:	409c                	lw	a5,0(s1)
    80003fe2:	fbfd                	bnez	a5,80003fd8 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003fe4:	4785                	li	a5,1
    80003fe6:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003fe8:	a21fd0ef          	jal	80001a08 <myproc>
    80003fec:	591c                	lw	a5,48(a0)
    80003fee:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003ff0:	854a                	mv	a0,s2
    80003ff2:	ccbfc0ef          	jal	80000cbc <release>
}
    80003ff6:	60e2                	ld	ra,24(sp)
    80003ff8:	6442                	ld	s0,16(sp)
    80003ffa:	64a2                	ld	s1,8(sp)
    80003ffc:	6902                	ld	s2,0(sp)
    80003ffe:	6105                	addi	sp,sp,32
    80004000:	8082                	ret

0000000080004002 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004002:	1101                	addi	sp,sp,-32
    80004004:	ec06                	sd	ra,24(sp)
    80004006:	e822                	sd	s0,16(sp)
    80004008:	e426                	sd	s1,8(sp)
    8000400a:	e04a                	sd	s2,0(sp)
    8000400c:	1000                	addi	s0,sp,32
    8000400e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004010:	00850913          	addi	s2,a0,8
    80004014:	854a                	mv	a0,s2
    80004016:	c13fc0ef          	jal	80000c28 <acquire>
  lk->locked = 0;
    8000401a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000401e:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004022:	8526                	mv	a0,s1
    80004024:	86efe0ef          	jal	80002092 <wakeup>
  release(&lk->lk);
    80004028:	854a                	mv	a0,s2
    8000402a:	c93fc0ef          	jal	80000cbc <release>
}
    8000402e:	60e2                	ld	ra,24(sp)
    80004030:	6442                	ld	s0,16(sp)
    80004032:	64a2                	ld	s1,8(sp)
    80004034:	6902                	ld	s2,0(sp)
    80004036:	6105                	addi	sp,sp,32
    80004038:	8082                	ret

000000008000403a <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000403a:	7179                	addi	sp,sp,-48
    8000403c:	f406                	sd	ra,40(sp)
    8000403e:	f022                	sd	s0,32(sp)
    80004040:	ec26                	sd	s1,24(sp)
    80004042:	e84a                	sd	s2,16(sp)
    80004044:	1800                	addi	s0,sp,48
    80004046:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80004048:	00850913          	addi	s2,a0,8
    8000404c:	854a                	mv	a0,s2
    8000404e:	bdbfc0ef          	jal	80000c28 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004052:	409c                	lw	a5,0(s1)
    80004054:	ef81                	bnez	a5,8000406c <holdingsleep+0x32>
    80004056:	4481                	li	s1,0
  release(&lk->lk);
    80004058:	854a                	mv	a0,s2
    8000405a:	c63fc0ef          	jal	80000cbc <release>
  return r;
}
    8000405e:	8526                	mv	a0,s1
    80004060:	70a2                	ld	ra,40(sp)
    80004062:	7402                	ld	s0,32(sp)
    80004064:	64e2                	ld	s1,24(sp)
    80004066:	6942                	ld	s2,16(sp)
    80004068:	6145                	addi	sp,sp,48
    8000406a:	8082                	ret
    8000406c:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    8000406e:	0284a983          	lw	s3,40(s1)
    80004072:	997fd0ef          	jal	80001a08 <myproc>
    80004076:	5904                	lw	s1,48(a0)
    80004078:	413484b3          	sub	s1,s1,s3
    8000407c:	0014b493          	seqz	s1,s1
    80004080:	69a2                	ld	s3,8(sp)
    80004082:	bfd9                	j	80004058 <holdingsleep+0x1e>

0000000080004084 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004084:	1141                	addi	sp,sp,-16
    80004086:	e406                	sd	ra,8(sp)
    80004088:	e022                	sd	s0,0(sp)
    8000408a:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000408c:	00003597          	auipc	a1,0x3
    80004090:	52c58593          	addi	a1,a1,1324 # 800075b8 <etext+0x5b8>
    80004094:	0001e517          	auipc	a0,0x1e
    80004098:	4ac50513          	addi	a0,a0,1196 # 80022540 <ftable>
    8000409c:	b03fc0ef          	jal	80000b9e <initlock>
}
    800040a0:	60a2                	ld	ra,8(sp)
    800040a2:	6402                	ld	s0,0(sp)
    800040a4:	0141                	addi	sp,sp,16
    800040a6:	8082                	ret

00000000800040a8 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800040a8:	1101                	addi	sp,sp,-32
    800040aa:	ec06                	sd	ra,24(sp)
    800040ac:	e822                	sd	s0,16(sp)
    800040ae:	e426                	sd	s1,8(sp)
    800040b0:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800040b2:	0001e517          	auipc	a0,0x1e
    800040b6:	48e50513          	addi	a0,a0,1166 # 80022540 <ftable>
    800040ba:	b6ffc0ef          	jal	80000c28 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800040be:	0001e497          	auipc	s1,0x1e
    800040c2:	49a48493          	addi	s1,s1,1178 # 80022558 <ftable+0x18>
    800040c6:	0001f717          	auipc	a4,0x1f
    800040ca:	43270713          	addi	a4,a4,1074 # 800234f8 <disk>
    if(f->ref == 0){
    800040ce:	40dc                	lw	a5,4(s1)
    800040d0:	cf89                	beqz	a5,800040ea <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800040d2:	02848493          	addi	s1,s1,40
    800040d6:	fee49ce3          	bne	s1,a4,800040ce <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800040da:	0001e517          	auipc	a0,0x1e
    800040de:	46650513          	addi	a0,a0,1126 # 80022540 <ftable>
    800040e2:	bdbfc0ef          	jal	80000cbc <release>
  return 0;
    800040e6:	4481                	li	s1,0
    800040e8:	a809                	j	800040fa <filealloc+0x52>
      f->ref = 1;
    800040ea:	4785                	li	a5,1
    800040ec:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800040ee:	0001e517          	auipc	a0,0x1e
    800040f2:	45250513          	addi	a0,a0,1106 # 80022540 <ftable>
    800040f6:	bc7fc0ef          	jal	80000cbc <release>
}
    800040fa:	8526                	mv	a0,s1
    800040fc:	60e2                	ld	ra,24(sp)
    800040fe:	6442                	ld	s0,16(sp)
    80004100:	64a2                	ld	s1,8(sp)
    80004102:	6105                	addi	sp,sp,32
    80004104:	8082                	ret

0000000080004106 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004106:	1101                	addi	sp,sp,-32
    80004108:	ec06                	sd	ra,24(sp)
    8000410a:	e822                	sd	s0,16(sp)
    8000410c:	e426                	sd	s1,8(sp)
    8000410e:	1000                	addi	s0,sp,32
    80004110:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004112:	0001e517          	auipc	a0,0x1e
    80004116:	42e50513          	addi	a0,a0,1070 # 80022540 <ftable>
    8000411a:	b0ffc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    8000411e:	40dc                	lw	a5,4(s1)
    80004120:	02f05063          	blez	a5,80004140 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004124:	2785                	addiw	a5,a5,1
    80004126:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004128:	0001e517          	auipc	a0,0x1e
    8000412c:	41850513          	addi	a0,a0,1048 # 80022540 <ftable>
    80004130:	b8dfc0ef          	jal	80000cbc <release>
  return f;
}
    80004134:	8526                	mv	a0,s1
    80004136:	60e2                	ld	ra,24(sp)
    80004138:	6442                	ld	s0,16(sp)
    8000413a:	64a2                	ld	s1,8(sp)
    8000413c:	6105                	addi	sp,sp,32
    8000413e:	8082                	ret
    panic("filedup");
    80004140:	00003517          	auipc	a0,0x3
    80004144:	48050513          	addi	a0,a0,1152 # 800075c0 <etext+0x5c0>
    80004148:	edcfc0ef          	jal	80000824 <panic>

000000008000414c <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000414c:	7139                	addi	sp,sp,-64
    8000414e:	fc06                	sd	ra,56(sp)
    80004150:	f822                	sd	s0,48(sp)
    80004152:	f426                	sd	s1,40(sp)
    80004154:	0080                	addi	s0,sp,64
    80004156:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004158:	0001e517          	auipc	a0,0x1e
    8000415c:	3e850513          	addi	a0,a0,1000 # 80022540 <ftable>
    80004160:	ac9fc0ef          	jal	80000c28 <acquire>
  if(f->ref < 1)
    80004164:	40dc                	lw	a5,4(s1)
    80004166:	04f05a63          	blez	a5,800041ba <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000416a:	37fd                	addiw	a5,a5,-1
    8000416c:	c0dc                	sw	a5,4(s1)
    8000416e:	06f04063          	bgtz	a5,800041ce <fileclose+0x82>
    80004172:	f04a                	sd	s2,32(sp)
    80004174:	ec4e                	sd	s3,24(sp)
    80004176:	e852                	sd	s4,16(sp)
    80004178:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000417a:	0004a903          	lw	s2,0(s1)
    8000417e:	0094c783          	lbu	a5,9(s1)
    80004182:	89be                	mv	s3,a5
    80004184:	689c                	ld	a5,16(s1)
    80004186:	8a3e                	mv	s4,a5
    80004188:	6c9c                	ld	a5,24(s1)
    8000418a:	8abe                	mv	s5,a5
  f->ref = 0;
    8000418c:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004190:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004194:	0001e517          	auipc	a0,0x1e
    80004198:	3ac50513          	addi	a0,a0,940 # 80022540 <ftable>
    8000419c:	b21fc0ef          	jal	80000cbc <release>

  if(ff.type == FD_PIPE){
    800041a0:	4785                	li	a5,1
    800041a2:	04f90163          	beq	s2,a5,800041e4 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800041a6:	ffe9079b          	addiw	a5,s2,-2
    800041aa:	4705                	li	a4,1
    800041ac:	04f77563          	bgeu	a4,a5,800041f6 <fileclose+0xaa>
    800041b0:	7902                	ld	s2,32(sp)
    800041b2:	69e2                	ld	s3,24(sp)
    800041b4:	6a42                	ld	s4,16(sp)
    800041b6:	6aa2                	ld	s5,8(sp)
    800041b8:	a00d                	j	800041da <fileclose+0x8e>
    800041ba:	f04a                	sd	s2,32(sp)
    800041bc:	ec4e                	sd	s3,24(sp)
    800041be:	e852                	sd	s4,16(sp)
    800041c0:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800041c2:	00003517          	auipc	a0,0x3
    800041c6:	40650513          	addi	a0,a0,1030 # 800075c8 <etext+0x5c8>
    800041ca:	e5afc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    800041ce:	0001e517          	auipc	a0,0x1e
    800041d2:	37250513          	addi	a0,a0,882 # 80022540 <ftable>
    800041d6:	ae7fc0ef          	jal	80000cbc <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800041da:	70e2                	ld	ra,56(sp)
    800041dc:	7442                	ld	s0,48(sp)
    800041de:	74a2                	ld	s1,40(sp)
    800041e0:	6121                	addi	sp,sp,64
    800041e2:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800041e4:	85ce                	mv	a1,s3
    800041e6:	8552                	mv	a0,s4
    800041e8:	348000ef          	jal	80004530 <pipeclose>
    800041ec:	7902                	ld	s2,32(sp)
    800041ee:	69e2                	ld	s3,24(sp)
    800041f0:	6a42                	ld	s4,16(sp)
    800041f2:	6aa2                	ld	s5,8(sp)
    800041f4:	b7dd                	j	800041da <fileclose+0x8e>
    begin_op();
    800041f6:	b33ff0ef          	jal	80003d28 <begin_op>
    iput(ff.ip);
    800041fa:	8556                	mv	a0,s5
    800041fc:	aa2ff0ef          	jal	8000349e <iput>
    end_op();
    80004200:	b99ff0ef          	jal	80003d98 <end_op>
    80004204:	7902                	ld	s2,32(sp)
    80004206:	69e2                	ld	s3,24(sp)
    80004208:	6a42                	ld	s4,16(sp)
    8000420a:	6aa2                	ld	s5,8(sp)
    8000420c:	b7f9                	j	800041da <fileclose+0x8e>

000000008000420e <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000420e:	715d                	addi	sp,sp,-80
    80004210:	e486                	sd	ra,72(sp)
    80004212:	e0a2                	sd	s0,64(sp)
    80004214:	fc26                	sd	s1,56(sp)
    80004216:	f052                	sd	s4,32(sp)
    80004218:	0880                	addi	s0,sp,80
    8000421a:	84aa                	mv	s1,a0
    8000421c:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    8000421e:	feafd0ef          	jal	80001a08 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004222:	409c                	lw	a5,0(s1)
    80004224:	37f9                	addiw	a5,a5,-2
    80004226:	4705                	li	a4,1
    80004228:	04f76263          	bltu	a4,a5,8000426c <filestat+0x5e>
    8000422c:	f84a                	sd	s2,48(sp)
    8000422e:	f44e                	sd	s3,40(sp)
    80004230:	89aa                	mv	s3,a0
    ilock(f->ip);
    80004232:	6c88                	ld	a0,24(s1)
    80004234:	8e8ff0ef          	jal	8000331c <ilock>
    stati(f->ip, &st);
    80004238:	fb840913          	addi	s2,s0,-72
    8000423c:	85ca                	mv	a1,s2
    8000423e:	6c88                	ld	a0,24(s1)
    80004240:	c40ff0ef          	jal	80003680 <stati>
    iunlock(f->ip);
    80004244:	6c88                	ld	a0,24(s1)
    80004246:	984ff0ef          	jal	800033ca <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000424a:	46e1                	li	a3,24
    8000424c:	864a                	mv	a2,s2
    8000424e:	85d2                	mv	a1,s4
    80004250:	0509b503          	ld	a0,80(s3)
    80004254:	c00fd0ef          	jal	80001654 <copyout>
    80004258:	41f5551b          	sraiw	a0,a0,0x1f
    8000425c:	7942                	ld	s2,48(sp)
    8000425e:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004260:	60a6                	ld	ra,72(sp)
    80004262:	6406                	ld	s0,64(sp)
    80004264:	74e2                	ld	s1,56(sp)
    80004266:	7a02                	ld	s4,32(sp)
    80004268:	6161                	addi	sp,sp,80
    8000426a:	8082                	ret
  return -1;
    8000426c:	557d                	li	a0,-1
    8000426e:	bfcd                	j	80004260 <filestat+0x52>

0000000080004270 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004270:	7179                	addi	sp,sp,-48
    80004272:	f406                	sd	ra,40(sp)
    80004274:	f022                	sd	s0,32(sp)
    80004276:	e84a                	sd	s2,16(sp)
    80004278:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000427a:	00854783          	lbu	a5,8(a0)
    8000427e:	cfd1                	beqz	a5,8000431a <fileread+0xaa>
    80004280:	ec26                	sd	s1,24(sp)
    80004282:	e44e                	sd	s3,8(sp)
    80004284:	84aa                	mv	s1,a0
    80004286:	892e                	mv	s2,a1
    80004288:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    8000428a:	411c                	lw	a5,0(a0)
    8000428c:	4705                	li	a4,1
    8000428e:	04e78363          	beq	a5,a4,800042d4 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004292:	470d                	li	a4,3
    80004294:	04e78763          	beq	a5,a4,800042e2 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004298:	4709                	li	a4,2
    8000429a:	06e79a63          	bne	a5,a4,8000430e <fileread+0x9e>
    ilock(f->ip);
    8000429e:	6d08                	ld	a0,24(a0)
    800042a0:	87cff0ef          	jal	8000331c <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800042a4:	874e                	mv	a4,s3
    800042a6:	5094                	lw	a3,32(s1)
    800042a8:	864a                	mv	a2,s2
    800042aa:	4585                	li	a1,1
    800042ac:	6c88                	ld	a0,24(s1)
    800042ae:	c00ff0ef          	jal	800036ae <readi>
    800042b2:	892a                	mv	s2,a0
    800042b4:	00a05563          	blez	a0,800042be <fileread+0x4e>
      f->off += r;
    800042b8:	509c                	lw	a5,32(s1)
    800042ba:	9fa9                	addw	a5,a5,a0
    800042bc:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800042be:	6c88                	ld	a0,24(s1)
    800042c0:	90aff0ef          	jal	800033ca <iunlock>
    800042c4:	64e2                	ld	s1,24(sp)
    800042c6:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800042c8:	854a                	mv	a0,s2
    800042ca:	70a2                	ld	ra,40(sp)
    800042cc:	7402                	ld	s0,32(sp)
    800042ce:	6942                	ld	s2,16(sp)
    800042d0:	6145                	addi	sp,sp,48
    800042d2:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800042d4:	6908                	ld	a0,16(a0)
    800042d6:	3b0000ef          	jal	80004686 <piperead>
    800042da:	892a                	mv	s2,a0
    800042dc:	64e2                	ld	s1,24(sp)
    800042de:	69a2                	ld	s3,8(sp)
    800042e0:	b7e5                	j	800042c8 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800042e2:	02451783          	lh	a5,36(a0)
    800042e6:	03079693          	slli	a3,a5,0x30
    800042ea:	92c1                	srli	a3,a3,0x30
    800042ec:	4725                	li	a4,9
    800042ee:	02d76963          	bltu	a4,a3,80004320 <fileread+0xb0>
    800042f2:	0792                	slli	a5,a5,0x4
    800042f4:	0001e717          	auipc	a4,0x1e
    800042f8:	1ac70713          	addi	a4,a4,428 # 800224a0 <devsw>
    800042fc:	97ba                	add	a5,a5,a4
    800042fe:	639c                	ld	a5,0(a5)
    80004300:	c78d                	beqz	a5,8000432a <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80004302:	4505                	li	a0,1
    80004304:	9782                	jalr	a5
    80004306:	892a                	mv	s2,a0
    80004308:	64e2                	ld	s1,24(sp)
    8000430a:	69a2                	ld	s3,8(sp)
    8000430c:	bf75                	j	800042c8 <fileread+0x58>
    panic("fileread");
    8000430e:	00003517          	auipc	a0,0x3
    80004312:	2ca50513          	addi	a0,a0,714 # 800075d8 <etext+0x5d8>
    80004316:	d0efc0ef          	jal	80000824 <panic>
    return -1;
    8000431a:	57fd                	li	a5,-1
    8000431c:	893e                	mv	s2,a5
    8000431e:	b76d                	j	800042c8 <fileread+0x58>
      return -1;
    80004320:	57fd                	li	a5,-1
    80004322:	893e                	mv	s2,a5
    80004324:	64e2                	ld	s1,24(sp)
    80004326:	69a2                	ld	s3,8(sp)
    80004328:	b745                	j	800042c8 <fileread+0x58>
    8000432a:	57fd                	li	a5,-1
    8000432c:	893e                	mv	s2,a5
    8000432e:	64e2                	ld	s1,24(sp)
    80004330:	69a2                	ld	s3,8(sp)
    80004332:	bf59                	j	800042c8 <fileread+0x58>

0000000080004334 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004334:	00954783          	lbu	a5,9(a0)
    80004338:	10078f63          	beqz	a5,80004456 <filewrite+0x122>
{
    8000433c:	711d                	addi	sp,sp,-96
    8000433e:	ec86                	sd	ra,88(sp)
    80004340:	e8a2                	sd	s0,80(sp)
    80004342:	e0ca                	sd	s2,64(sp)
    80004344:	f456                	sd	s5,40(sp)
    80004346:	f05a                	sd	s6,32(sp)
    80004348:	1080                	addi	s0,sp,96
    8000434a:	892a                	mv	s2,a0
    8000434c:	8b2e                	mv	s6,a1
    8000434e:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80004350:	411c                	lw	a5,0(a0)
    80004352:	4705                	li	a4,1
    80004354:	02e78a63          	beq	a5,a4,80004388 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004358:	470d                	li	a4,3
    8000435a:	02e78b63          	beq	a5,a4,80004390 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    8000435e:	4709                	li	a4,2
    80004360:	0ce79f63          	bne	a5,a4,8000443e <filewrite+0x10a>
    80004364:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80004366:	0ac05a63          	blez	a2,8000441a <filewrite+0xe6>
    8000436a:	e4a6                	sd	s1,72(sp)
    8000436c:	fc4e                	sd	s3,56(sp)
    8000436e:	ec5e                	sd	s7,24(sp)
    80004370:	e862                	sd	s8,16(sp)
    80004372:	e466                	sd	s9,8(sp)
    int i = 0;
    80004374:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80004376:	6b85                	lui	s7,0x1
    80004378:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000437c:	6785                	lui	a5,0x1
    8000437e:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004382:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004384:	4c05                	li	s8,1
    80004386:	a8ad                	j	80004400 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004388:	6908                	ld	a0,16(a0)
    8000438a:	204000ef          	jal	8000458e <pipewrite>
    8000438e:	a04d                	j	80004430 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004390:	02451783          	lh	a5,36(a0)
    80004394:	03079693          	slli	a3,a5,0x30
    80004398:	92c1                	srli	a3,a3,0x30
    8000439a:	4725                	li	a4,9
    8000439c:	0ad76f63          	bltu	a4,a3,8000445a <filewrite+0x126>
    800043a0:	0792                	slli	a5,a5,0x4
    800043a2:	0001e717          	auipc	a4,0x1e
    800043a6:	0fe70713          	addi	a4,a4,254 # 800224a0 <devsw>
    800043aa:	97ba                	add	a5,a5,a4
    800043ac:	679c                	ld	a5,8(a5)
    800043ae:	cbc5                	beqz	a5,8000445e <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800043b0:	4505                	li	a0,1
    800043b2:	9782                	jalr	a5
    800043b4:	a8b5                	j	80004430 <filewrite+0xfc>
      if(n1 > max)
    800043b6:	2981                	sext.w	s3,s3
      begin_op();
    800043b8:	971ff0ef          	jal	80003d28 <begin_op>
      ilock(f->ip);
    800043bc:	01893503          	ld	a0,24(s2)
    800043c0:	f5dfe0ef          	jal	8000331c <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800043c4:	874e                	mv	a4,s3
    800043c6:	02092683          	lw	a3,32(s2)
    800043ca:	016a0633          	add	a2,s4,s6
    800043ce:	85e2                	mv	a1,s8
    800043d0:	01893503          	ld	a0,24(s2)
    800043d4:	bccff0ef          	jal	800037a0 <writei>
    800043d8:	84aa                	mv	s1,a0
    800043da:	00a05763          	blez	a0,800043e8 <filewrite+0xb4>
        f->off += r;
    800043de:	02092783          	lw	a5,32(s2)
    800043e2:	9fa9                	addw	a5,a5,a0
    800043e4:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800043e8:	01893503          	ld	a0,24(s2)
    800043ec:	fdffe0ef          	jal	800033ca <iunlock>
      end_op();
    800043f0:	9a9ff0ef          	jal	80003d98 <end_op>

      if(r != n1){
    800043f4:	02999563          	bne	s3,s1,8000441e <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    800043f8:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    800043fc:	015a5963          	bge	s4,s5,8000440e <filewrite+0xda>
      int n1 = n - i;
    80004400:	414a87bb          	subw	a5,s5,s4
    80004404:	89be                	mv	s3,a5
      if(n1 > max)
    80004406:	fafbd8e3          	bge	s7,a5,800043b6 <filewrite+0x82>
    8000440a:	89e6                	mv	s3,s9
    8000440c:	b76d                	j	800043b6 <filewrite+0x82>
    8000440e:	64a6                	ld	s1,72(sp)
    80004410:	79e2                	ld	s3,56(sp)
    80004412:	6be2                	ld	s7,24(sp)
    80004414:	6c42                	ld	s8,16(sp)
    80004416:	6ca2                	ld	s9,8(sp)
    80004418:	a801                	j	80004428 <filewrite+0xf4>
    int i = 0;
    8000441a:	4a01                	li	s4,0
    8000441c:	a031                	j	80004428 <filewrite+0xf4>
    8000441e:	64a6                	ld	s1,72(sp)
    80004420:	79e2                	ld	s3,56(sp)
    80004422:	6be2                	ld	s7,24(sp)
    80004424:	6c42                	ld	s8,16(sp)
    80004426:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80004428:	034a9d63          	bne	s5,s4,80004462 <filewrite+0x12e>
    8000442c:	8556                	mv	a0,s5
    8000442e:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004430:	60e6                	ld	ra,88(sp)
    80004432:	6446                	ld	s0,80(sp)
    80004434:	6906                	ld	s2,64(sp)
    80004436:	7aa2                	ld	s5,40(sp)
    80004438:	7b02                	ld	s6,32(sp)
    8000443a:	6125                	addi	sp,sp,96
    8000443c:	8082                	ret
    8000443e:	e4a6                	sd	s1,72(sp)
    80004440:	fc4e                	sd	s3,56(sp)
    80004442:	f852                	sd	s4,48(sp)
    80004444:	ec5e                	sd	s7,24(sp)
    80004446:	e862                	sd	s8,16(sp)
    80004448:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000444a:	00003517          	auipc	a0,0x3
    8000444e:	19e50513          	addi	a0,a0,414 # 800075e8 <etext+0x5e8>
    80004452:	bd2fc0ef          	jal	80000824 <panic>
    return -1;
    80004456:	557d                	li	a0,-1
}
    80004458:	8082                	ret
      return -1;
    8000445a:	557d                	li	a0,-1
    8000445c:	bfd1                	j	80004430 <filewrite+0xfc>
    8000445e:	557d                	li	a0,-1
    80004460:	bfc1                	j	80004430 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80004462:	557d                	li	a0,-1
    80004464:	7a42                	ld	s4,48(sp)
    80004466:	b7e9                	j	80004430 <filewrite+0xfc>

0000000080004468 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004468:	7179                	addi	sp,sp,-48
    8000446a:	f406                	sd	ra,40(sp)
    8000446c:	f022                	sd	s0,32(sp)
    8000446e:	ec26                	sd	s1,24(sp)
    80004470:	e052                	sd	s4,0(sp)
    80004472:	1800                	addi	s0,sp,48
    80004474:	84aa                	mv	s1,a0
    80004476:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004478:	0005b023          	sd	zero,0(a1)
    8000447c:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004480:	c29ff0ef          	jal	800040a8 <filealloc>
    80004484:	e088                	sd	a0,0(s1)
    80004486:	c549                	beqz	a0,80004510 <pipealloc+0xa8>
    80004488:	c21ff0ef          	jal	800040a8 <filealloc>
    8000448c:	00aa3023          	sd	a0,0(s4)
    80004490:	cd25                	beqz	a0,80004508 <pipealloc+0xa0>
    80004492:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004494:	eb0fc0ef          	jal	80000b44 <kalloc>
    80004498:	892a                	mv	s2,a0
    8000449a:	c12d                	beqz	a0,800044fc <pipealloc+0x94>
    8000449c:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000449e:	4985                	li	s3,1
    800044a0:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800044a4:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800044a8:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800044ac:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800044b0:	00003597          	auipc	a1,0x3
    800044b4:	14858593          	addi	a1,a1,328 # 800075f8 <etext+0x5f8>
    800044b8:	ee6fc0ef          	jal	80000b9e <initlock>
  (*f0)->type = FD_PIPE;
    800044bc:	609c                	ld	a5,0(s1)
    800044be:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800044c2:	609c                	ld	a5,0(s1)
    800044c4:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800044c8:	609c                	ld	a5,0(s1)
    800044ca:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800044ce:	609c                	ld	a5,0(s1)
    800044d0:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800044d4:	000a3783          	ld	a5,0(s4)
    800044d8:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800044dc:	000a3783          	ld	a5,0(s4)
    800044e0:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800044e4:	000a3783          	ld	a5,0(s4)
    800044e8:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800044ec:	000a3783          	ld	a5,0(s4)
    800044f0:	0127b823          	sd	s2,16(a5)
  return 0;
    800044f4:	4501                	li	a0,0
    800044f6:	6942                	ld	s2,16(sp)
    800044f8:	69a2                	ld	s3,8(sp)
    800044fa:	a01d                	j	80004520 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800044fc:	6088                	ld	a0,0(s1)
    800044fe:	c119                	beqz	a0,80004504 <pipealloc+0x9c>
    80004500:	6942                	ld	s2,16(sp)
    80004502:	a029                	j	8000450c <pipealloc+0xa4>
    80004504:	6942                	ld	s2,16(sp)
    80004506:	a029                	j	80004510 <pipealloc+0xa8>
    80004508:	6088                	ld	a0,0(s1)
    8000450a:	c10d                	beqz	a0,8000452c <pipealloc+0xc4>
    fileclose(*f0);
    8000450c:	c41ff0ef          	jal	8000414c <fileclose>
  if(*f1)
    80004510:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004514:	557d                	li	a0,-1
  if(*f1)
    80004516:	c789                	beqz	a5,80004520 <pipealloc+0xb8>
    fileclose(*f1);
    80004518:	853e                	mv	a0,a5
    8000451a:	c33ff0ef          	jal	8000414c <fileclose>
  return -1;
    8000451e:	557d                	li	a0,-1
}
    80004520:	70a2                	ld	ra,40(sp)
    80004522:	7402                	ld	s0,32(sp)
    80004524:	64e2                	ld	s1,24(sp)
    80004526:	6a02                	ld	s4,0(sp)
    80004528:	6145                	addi	sp,sp,48
    8000452a:	8082                	ret
  return -1;
    8000452c:	557d                	li	a0,-1
    8000452e:	bfcd                	j	80004520 <pipealloc+0xb8>

0000000080004530 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004530:	1101                	addi	sp,sp,-32
    80004532:	ec06                	sd	ra,24(sp)
    80004534:	e822                	sd	s0,16(sp)
    80004536:	e426                	sd	s1,8(sp)
    80004538:	e04a                	sd	s2,0(sp)
    8000453a:	1000                	addi	s0,sp,32
    8000453c:	84aa                	mv	s1,a0
    8000453e:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004540:	ee8fc0ef          	jal	80000c28 <acquire>
  if(writable){
    80004544:	02090763          	beqz	s2,80004572 <pipeclose+0x42>
    pi->writeopen = 0;
    80004548:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000454c:	21848513          	addi	a0,s1,536
    80004550:	b43fd0ef          	jal	80002092 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004554:	2204a783          	lw	a5,544(s1)
    80004558:	e781                	bnez	a5,80004560 <pipeclose+0x30>
    8000455a:	2244a783          	lw	a5,548(s1)
    8000455e:	c38d                	beqz	a5,80004580 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80004560:	8526                	mv	a0,s1
    80004562:	f5afc0ef          	jal	80000cbc <release>
}
    80004566:	60e2                	ld	ra,24(sp)
    80004568:	6442                	ld	s0,16(sp)
    8000456a:	64a2                	ld	s1,8(sp)
    8000456c:	6902                	ld	s2,0(sp)
    8000456e:	6105                	addi	sp,sp,32
    80004570:	8082                	ret
    pi->readopen = 0;
    80004572:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004576:	21c48513          	addi	a0,s1,540
    8000457a:	b19fd0ef          	jal	80002092 <wakeup>
    8000457e:	bfd9                	j	80004554 <pipeclose+0x24>
    release(&pi->lock);
    80004580:	8526                	mv	a0,s1
    80004582:	f3afc0ef          	jal	80000cbc <release>
    kfree((char*)pi);
    80004586:	8526                	mv	a0,s1
    80004588:	cd4fc0ef          	jal	80000a5c <kfree>
    8000458c:	bfe9                	j	80004566 <pipeclose+0x36>

000000008000458e <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    8000458e:	7159                	addi	sp,sp,-112
    80004590:	f486                	sd	ra,104(sp)
    80004592:	f0a2                	sd	s0,96(sp)
    80004594:	eca6                	sd	s1,88(sp)
    80004596:	e8ca                	sd	s2,80(sp)
    80004598:	e4ce                	sd	s3,72(sp)
    8000459a:	e0d2                	sd	s4,64(sp)
    8000459c:	fc56                	sd	s5,56(sp)
    8000459e:	1880                	addi	s0,sp,112
    800045a0:	84aa                	mv	s1,a0
    800045a2:	8aae                	mv	s5,a1
    800045a4:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800045a6:	c62fd0ef          	jal	80001a08 <myproc>
    800045aa:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800045ac:	8526                	mv	a0,s1
    800045ae:	e7afc0ef          	jal	80000c28 <acquire>
  while(i < n){
    800045b2:	0d405263          	blez	s4,80004676 <pipewrite+0xe8>
    800045b6:	f85a                	sd	s6,48(sp)
    800045b8:	f45e                	sd	s7,40(sp)
    800045ba:	f062                	sd	s8,32(sp)
    800045bc:	ec66                	sd	s9,24(sp)
    800045be:	e86a                	sd	s10,16(sp)
  int i = 0;
    800045c0:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800045c2:	f9f40c13          	addi	s8,s0,-97
    800045c6:	4b85                	li	s7,1
    800045c8:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800045ca:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800045ce:	21c48c93          	addi	s9,s1,540
    800045d2:	a82d                	j	8000460c <pipewrite+0x7e>
      release(&pi->lock);
    800045d4:	8526                	mv	a0,s1
    800045d6:	ee6fc0ef          	jal	80000cbc <release>
      return -1;
    800045da:	597d                	li	s2,-1
    800045dc:	7b42                	ld	s6,48(sp)
    800045de:	7ba2                	ld	s7,40(sp)
    800045e0:	7c02                	ld	s8,32(sp)
    800045e2:	6ce2                	ld	s9,24(sp)
    800045e4:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800045e6:	854a                	mv	a0,s2
    800045e8:	70a6                	ld	ra,104(sp)
    800045ea:	7406                	ld	s0,96(sp)
    800045ec:	64e6                	ld	s1,88(sp)
    800045ee:	6946                	ld	s2,80(sp)
    800045f0:	69a6                	ld	s3,72(sp)
    800045f2:	6a06                	ld	s4,64(sp)
    800045f4:	7ae2                	ld	s5,56(sp)
    800045f6:	6165                	addi	sp,sp,112
    800045f8:	8082                	ret
      wakeup(&pi->nread);
    800045fa:	856a                	mv	a0,s10
    800045fc:	a97fd0ef          	jal	80002092 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004600:	85a6                	mv	a1,s1
    80004602:	8566                	mv	a0,s9
    80004604:	a43fd0ef          	jal	80002046 <sleep>
  while(i < n){
    80004608:	05495a63          	bge	s2,s4,8000465c <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    8000460c:	2204a783          	lw	a5,544(s1)
    80004610:	d3f1                	beqz	a5,800045d4 <pipewrite+0x46>
    80004612:	854e                	mv	a0,s3
    80004614:	c6ffd0ef          	jal	80002282 <killed>
    80004618:	fd55                	bnez	a0,800045d4 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000461a:	2184a783          	lw	a5,536(s1)
    8000461e:	21c4a703          	lw	a4,540(s1)
    80004622:	2007879b          	addiw	a5,a5,512
    80004626:	fcf70ae3          	beq	a4,a5,800045fa <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000462a:	86de                	mv	a3,s7
    8000462c:	01590633          	add	a2,s2,s5
    80004630:	85e2                	mv	a1,s8
    80004632:	0509b503          	ld	a0,80(s3)
    80004636:	8dcfd0ef          	jal	80001712 <copyin>
    8000463a:	05650063          	beq	a0,s6,8000467a <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000463e:	21c4a783          	lw	a5,540(s1)
    80004642:	0017871b          	addiw	a4,a5,1
    80004646:	20e4ae23          	sw	a4,540(s1)
    8000464a:	1ff7f793          	andi	a5,a5,511
    8000464e:	97a6                	add	a5,a5,s1
    80004650:	f9f44703          	lbu	a4,-97(s0)
    80004654:	00e78c23          	sb	a4,24(a5)
      i++;
    80004658:	2905                	addiw	s2,s2,1
    8000465a:	b77d                	j	80004608 <pipewrite+0x7a>
    8000465c:	7b42                	ld	s6,48(sp)
    8000465e:	7ba2                	ld	s7,40(sp)
    80004660:	7c02                	ld	s8,32(sp)
    80004662:	6ce2                	ld	s9,24(sp)
    80004664:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004666:	21848513          	addi	a0,s1,536
    8000466a:	a29fd0ef          	jal	80002092 <wakeup>
  release(&pi->lock);
    8000466e:	8526                	mv	a0,s1
    80004670:	e4cfc0ef          	jal	80000cbc <release>
  return i;
    80004674:	bf8d                	j	800045e6 <pipewrite+0x58>
  int i = 0;
    80004676:	4901                	li	s2,0
    80004678:	b7fd                	j	80004666 <pipewrite+0xd8>
    8000467a:	7b42                	ld	s6,48(sp)
    8000467c:	7ba2                	ld	s7,40(sp)
    8000467e:	7c02                	ld	s8,32(sp)
    80004680:	6ce2                	ld	s9,24(sp)
    80004682:	6d42                	ld	s10,16(sp)
    80004684:	b7cd                	j	80004666 <pipewrite+0xd8>

0000000080004686 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004686:	711d                	addi	sp,sp,-96
    80004688:	ec86                	sd	ra,88(sp)
    8000468a:	e8a2                	sd	s0,80(sp)
    8000468c:	e4a6                	sd	s1,72(sp)
    8000468e:	e0ca                	sd	s2,64(sp)
    80004690:	fc4e                	sd	s3,56(sp)
    80004692:	f852                	sd	s4,48(sp)
    80004694:	f456                	sd	s5,40(sp)
    80004696:	1080                	addi	s0,sp,96
    80004698:	84aa                	mv	s1,a0
    8000469a:	892e                	mv	s2,a1
    8000469c:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000469e:	b6afd0ef          	jal	80001a08 <myproc>
    800046a2:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800046a4:	8526                	mv	a0,s1
    800046a6:	d82fc0ef          	jal	80000c28 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046aa:	2184a703          	lw	a4,536(s1)
    800046ae:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800046b2:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046b6:	02f71763          	bne	a4,a5,800046e4 <piperead+0x5e>
    800046ba:	2244a783          	lw	a5,548(s1)
    800046be:	cf85                	beqz	a5,800046f6 <piperead+0x70>
    if(killed(pr)){
    800046c0:	8552                	mv	a0,s4
    800046c2:	bc1fd0ef          	jal	80002282 <killed>
    800046c6:	e11d                	bnez	a0,800046ec <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800046c8:	85a6                	mv	a1,s1
    800046ca:	854e                	mv	a0,s3
    800046cc:	97bfd0ef          	jal	80002046 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046d0:	2184a703          	lw	a4,536(s1)
    800046d4:	21c4a783          	lw	a5,540(s1)
    800046d8:	fef701e3          	beq	a4,a5,800046ba <piperead+0x34>
    800046dc:	f05a                	sd	s6,32(sp)
    800046de:	ec5e                	sd	s7,24(sp)
    800046e0:	e862                	sd	s8,16(sp)
    800046e2:	a829                	j	800046fc <piperead+0x76>
    800046e4:	f05a                	sd	s6,32(sp)
    800046e6:	ec5e                	sd	s7,24(sp)
    800046e8:	e862                	sd	s8,16(sp)
    800046ea:	a809                	j	800046fc <piperead+0x76>
      release(&pi->lock);
    800046ec:	8526                	mv	a0,s1
    800046ee:	dcefc0ef          	jal	80000cbc <release>
      return -1;
    800046f2:	59fd                	li	s3,-1
    800046f4:	a0a5                	j	8000475c <piperead+0xd6>
    800046f6:	f05a                	sd	s6,32(sp)
    800046f8:	ec5e                	sd	s7,24(sp)
    800046fa:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800046fc:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    800046fe:	faf40c13          	addi	s8,s0,-81
    80004702:	4b85                	li	s7,1
    80004704:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004706:	05505163          	blez	s5,80004748 <piperead+0xc2>
    if(pi->nread == pi->nwrite)
    8000470a:	2184a783          	lw	a5,536(s1)
    8000470e:	21c4a703          	lw	a4,540(s1)
    80004712:	02f70b63          	beq	a4,a5,80004748 <piperead+0xc2>
    ch = pi->data[pi->nread % PIPESIZE];
    80004716:	1ff7f793          	andi	a5,a5,511
    8000471a:	97a6                	add	a5,a5,s1
    8000471c:	0187c783          	lbu	a5,24(a5)
    80004720:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004724:	86de                	mv	a3,s7
    80004726:	8662                	mv	a2,s8
    80004728:	85ca                	mv	a1,s2
    8000472a:	050a3503          	ld	a0,80(s4)
    8000472e:	f27fc0ef          	jal	80001654 <copyout>
    80004732:	03650f63          	beq	a0,s6,80004770 <piperead+0xea>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004736:	2184a783          	lw	a5,536(s1)
    8000473a:	2785                	addiw	a5,a5,1
    8000473c:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004740:	2985                	addiw	s3,s3,1
    80004742:	0905                	addi	s2,s2,1
    80004744:	fd3a93e3          	bne	s5,s3,8000470a <piperead+0x84>
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004748:	21c48513          	addi	a0,s1,540
    8000474c:	947fd0ef          	jal	80002092 <wakeup>
  release(&pi->lock);
    80004750:	8526                	mv	a0,s1
    80004752:	d6afc0ef          	jal	80000cbc <release>
    80004756:	7b02                	ld	s6,32(sp)
    80004758:	6be2                	ld	s7,24(sp)
    8000475a:	6c42                	ld	s8,16(sp)
  return i;
}
    8000475c:	854e                	mv	a0,s3
    8000475e:	60e6                	ld	ra,88(sp)
    80004760:	6446                	ld	s0,80(sp)
    80004762:	64a6                	ld	s1,72(sp)
    80004764:	6906                	ld	s2,64(sp)
    80004766:	79e2                	ld	s3,56(sp)
    80004768:	7a42                	ld	s4,48(sp)
    8000476a:	7aa2                	ld	s5,40(sp)
    8000476c:	6125                	addi	sp,sp,96
    8000476e:	8082                	ret
      if(i == 0)
    80004770:	fc099ce3          	bnez	s3,80004748 <piperead+0xc2>
        i = -1;
    80004774:	89aa                	mv	s3,a0
    80004776:	bfc9                	j	80004748 <piperead+0xc2>

0000000080004778 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    80004778:	1141                	addi	sp,sp,-16
    8000477a:	e406                	sd	ra,8(sp)
    8000477c:	e022                	sd	s0,0(sp)
    8000477e:	0800                	addi	s0,sp,16
    80004780:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004782:	0035151b          	slliw	a0,a0,0x3
    80004786:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80004788:	8b89                	andi	a5,a5,2
    8000478a:	c399                	beqz	a5,80004790 <flags2perm+0x18>
      perm |= PTE_W;
    8000478c:	00456513          	ori	a0,a0,4
    return perm;
}
    80004790:	60a2                	ld	ra,8(sp)
    80004792:	6402                	ld	s0,0(sp)
    80004794:	0141                	addi	sp,sp,16
    80004796:	8082                	ret

0000000080004798 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004798:	de010113          	addi	sp,sp,-544
    8000479c:	20113c23          	sd	ra,536(sp)
    800047a0:	20813823          	sd	s0,528(sp)
    800047a4:	20913423          	sd	s1,520(sp)
    800047a8:	21213023          	sd	s2,512(sp)
    800047ac:	1400                	addi	s0,sp,544
    800047ae:	892a                	mv	s2,a0
    800047b0:	dea43823          	sd	a0,-528(s0)
    800047b4:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800047b8:	a50fd0ef          	jal	80001a08 <myproc>
    800047bc:	84aa                	mv	s1,a0

  begin_op();
    800047be:	d6aff0ef          	jal	80003d28 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    800047c2:	854a                	mv	a0,s2
    800047c4:	b86ff0ef          	jal	80003b4a <namei>
    800047c8:	cd21                	beqz	a0,80004820 <kexec+0x88>
    800047ca:	fbd2                	sd	s4,496(sp)
    800047cc:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800047ce:	b4ffe0ef          	jal	8000331c <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800047d2:	04000713          	li	a4,64
    800047d6:	4681                	li	a3,0
    800047d8:	e5040613          	addi	a2,s0,-432
    800047dc:	4581                	li	a1,0
    800047de:	8552                	mv	a0,s4
    800047e0:	ecffe0ef          	jal	800036ae <readi>
    800047e4:	04000793          	li	a5,64
    800047e8:	00f51a63          	bne	a0,a5,800047fc <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    800047ec:	e5042703          	lw	a4,-432(s0)
    800047f0:	464c47b7          	lui	a5,0x464c4
    800047f4:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800047f8:	02f70863          	beq	a4,a5,80004828 <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    800047fc:	8552                	mv	a0,s4
    800047fe:	d2bfe0ef          	jal	80003528 <iunlockput>
    end_op();
    80004802:	d96ff0ef          	jal	80003d98 <end_op>
  }
  return -1;
    80004806:	557d                	li	a0,-1
    80004808:	7a5e                	ld	s4,496(sp)
}
    8000480a:	21813083          	ld	ra,536(sp)
    8000480e:	21013403          	ld	s0,528(sp)
    80004812:	20813483          	ld	s1,520(sp)
    80004816:	20013903          	ld	s2,512(sp)
    8000481a:	22010113          	addi	sp,sp,544
    8000481e:	8082                	ret
    end_op();
    80004820:	d78ff0ef          	jal	80003d98 <end_op>
    return -1;
    80004824:	557d                	li	a0,-1
    80004826:	b7d5                	j	8000480a <kexec+0x72>
    80004828:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    8000482a:	8526                	mv	a0,s1
    8000482c:	ae6fd0ef          	jal	80001b12 <proc_pagetable>
    80004830:	8b2a                	mv	s6,a0
    80004832:	26050f63          	beqz	a0,80004ab0 <kexec+0x318>
    80004836:	ffce                	sd	s3,504(sp)
    80004838:	f7d6                	sd	s5,488(sp)
    8000483a:	efde                	sd	s7,472(sp)
    8000483c:	ebe2                	sd	s8,464(sp)
    8000483e:	e7e6                	sd	s9,456(sp)
    80004840:	e3ea                	sd	s10,448(sp)
    80004842:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004844:	e8845783          	lhu	a5,-376(s0)
    80004848:	0e078963          	beqz	a5,8000493a <kexec+0x1a2>
    8000484c:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004850:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004852:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004854:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80004858:	6c85                	lui	s9,0x1
    8000485a:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    8000485e:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004862:	6a85                	lui	s5,0x1
    80004864:	a085                	j	800048c4 <kexec+0x12c>
      panic("loadseg: address should exist");
    80004866:	00003517          	auipc	a0,0x3
    8000486a:	d9a50513          	addi	a0,a0,-614 # 80007600 <etext+0x600>
    8000486e:	fb7fb0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    80004872:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004874:	874a                	mv	a4,s2
    80004876:	009b86bb          	addw	a3,s7,s1
    8000487a:	4581                	li	a1,0
    8000487c:	8552                	mv	a0,s4
    8000487e:	e31fe0ef          	jal	800036ae <readi>
    80004882:	22a91b63          	bne	s2,a0,80004ab8 <kexec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80004886:	009a84bb          	addw	s1,s5,s1
    8000488a:	0334f263          	bgeu	s1,s3,800048ae <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    8000488e:	02049593          	slli	a1,s1,0x20
    80004892:	9181                	srli	a1,a1,0x20
    80004894:	95e2                	add	a1,a1,s8
    80004896:	855a                	mv	a0,s6
    80004898:	f8efc0ef          	jal	80001026 <walkaddr>
    8000489c:	862a                	mv	a2,a0
    if(pa == 0)
    8000489e:	d561                	beqz	a0,80004866 <kexec+0xce>
    if(sz - i < PGSIZE)
    800048a0:	409987bb          	subw	a5,s3,s1
    800048a4:	893e                	mv	s2,a5
    800048a6:	fcfcf6e3          	bgeu	s9,a5,80004872 <kexec+0xda>
    800048aa:	8956                	mv	s2,s5
    800048ac:	b7d9                	j	80004872 <kexec+0xda>
    sz = sz1;
    800048ae:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800048b2:	2d05                	addiw	s10,s10,1
    800048b4:	e0843783          	ld	a5,-504(s0)
    800048b8:	0387869b          	addiw	a3,a5,56
    800048bc:	e8845783          	lhu	a5,-376(s0)
    800048c0:	06fd5e63          	bge	s10,a5,8000493c <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800048c4:	e0d43423          	sd	a3,-504(s0)
    800048c8:	876e                	mv	a4,s11
    800048ca:	e1840613          	addi	a2,s0,-488
    800048ce:	4581                	li	a1,0
    800048d0:	8552                	mv	a0,s4
    800048d2:	dddfe0ef          	jal	800036ae <readi>
    800048d6:	1db51f63          	bne	a0,s11,80004ab4 <kexec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    800048da:	e1842783          	lw	a5,-488(s0)
    800048de:	4705                	li	a4,1
    800048e0:	fce799e3          	bne	a5,a4,800048b2 <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    800048e4:	e4043483          	ld	s1,-448(s0)
    800048e8:	e3843783          	ld	a5,-456(s0)
    800048ec:	1ef4e463          	bltu	s1,a5,80004ad4 <kexec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    800048f0:	e2843783          	ld	a5,-472(s0)
    800048f4:	94be                	add	s1,s1,a5
    800048f6:	1ef4e263          	bltu	s1,a5,80004ada <kexec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    800048fa:	de843703          	ld	a4,-536(s0)
    800048fe:	8ff9                	and	a5,a5,a4
    80004900:	1e079063          	bnez	a5,80004ae0 <kexec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004904:	e1c42503          	lw	a0,-484(s0)
    80004908:	e71ff0ef          	jal	80004778 <flags2perm>
    8000490c:	86aa                	mv	a3,a0
    8000490e:	8626                	mv	a2,s1
    80004910:	85ca                	mv	a1,s2
    80004912:	855a                	mv	a0,s6
    80004914:	9e9fc0ef          	jal	800012fc <uvmalloc>
    80004918:	dea43c23          	sd	a0,-520(s0)
    8000491c:	1c050563          	beqz	a0,80004ae6 <kexec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004920:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004924:	00098863          	beqz	s3,80004934 <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004928:	e2843c03          	ld	s8,-472(s0)
    8000492c:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004930:	4481                	li	s1,0
    80004932:	bfb1                	j	8000488e <kexec+0xf6>
    sz = sz1;
    80004934:	df843903          	ld	s2,-520(s0)
    80004938:	bfad                	j	800048b2 <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000493a:	4901                	li	s2,0
  iunlockput(ip);
    8000493c:	8552                	mv	a0,s4
    8000493e:	bebfe0ef          	jal	80003528 <iunlockput>
  end_op();
    80004942:	c56ff0ef          	jal	80003d98 <end_op>
  p = myproc();
    80004946:	8c2fd0ef          	jal	80001a08 <myproc>
    8000494a:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    8000494c:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004950:	6985                	lui	s3,0x1
    80004952:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004954:	99ca                	add	s3,s3,s2
    80004956:	77fd                	lui	a5,0xfffff
    80004958:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    8000495c:	4691                	li	a3,4
    8000495e:	6609                	lui	a2,0x2
    80004960:	964e                	add	a2,a2,s3
    80004962:	85ce                	mv	a1,s3
    80004964:	855a                	mv	a0,s6
    80004966:	997fc0ef          	jal	800012fc <uvmalloc>
    8000496a:	8a2a                	mv	s4,a0
    8000496c:	e105                	bnez	a0,8000498c <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    8000496e:	85ce                	mv	a1,s3
    80004970:	855a                	mv	a0,s6
    80004972:	a24fd0ef          	jal	80001b96 <proc_freepagetable>
  return -1;
    80004976:	557d                	li	a0,-1
    80004978:	79fe                	ld	s3,504(sp)
    8000497a:	7a5e                	ld	s4,496(sp)
    8000497c:	7abe                	ld	s5,488(sp)
    8000497e:	7b1e                	ld	s6,480(sp)
    80004980:	6bfe                	ld	s7,472(sp)
    80004982:	6c5e                	ld	s8,464(sp)
    80004984:	6cbe                	ld	s9,456(sp)
    80004986:	6d1e                	ld	s10,448(sp)
    80004988:	7dfa                	ld	s11,440(sp)
    8000498a:	b541                	j	8000480a <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    8000498c:	75f9                	lui	a1,0xffffe
    8000498e:	95aa                	add	a1,a1,a0
    80004990:	855a                	mv	a0,s6
    80004992:	b3dfc0ef          	jal	800014ce <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004996:	800a0b93          	addi	s7,s4,-2048
    8000499a:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    8000499e:	e0043783          	ld	a5,-512(s0)
    800049a2:	6388                	ld	a0,0(a5)
  sp = sz;
    800049a4:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    800049a6:	4481                	li	s1,0
    ustack[argc] = sp;
    800049a8:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    800049ac:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    800049b0:	cd21                	beqz	a0,80004a08 <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    800049b2:	cd0fc0ef          	jal	80000e82 <strlen>
    800049b6:	0015079b          	addiw	a5,a0,1
    800049ba:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800049be:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    800049c2:	13796563          	bltu	s2,s7,80004aec <kexec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800049c6:	e0043d83          	ld	s11,-512(s0)
    800049ca:	000db983          	ld	s3,0(s11)
    800049ce:	854e                	mv	a0,s3
    800049d0:	cb2fc0ef          	jal	80000e82 <strlen>
    800049d4:	0015069b          	addiw	a3,a0,1
    800049d8:	864e                	mv	a2,s3
    800049da:	85ca                	mv	a1,s2
    800049dc:	855a                	mv	a0,s6
    800049de:	c77fc0ef          	jal	80001654 <copyout>
    800049e2:	10054763          	bltz	a0,80004af0 <kexec+0x358>
    ustack[argc] = sp;
    800049e6:	00349793          	slli	a5,s1,0x3
    800049ea:	97e6                	add	a5,a5,s9
    800049ec:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb9c8>
  for(argc = 0; argv[argc]; argc++) {
    800049f0:	0485                	addi	s1,s1,1
    800049f2:	008d8793          	addi	a5,s11,8
    800049f6:	e0f43023          	sd	a5,-512(s0)
    800049fa:	008db503          	ld	a0,8(s11)
    800049fe:	c509                	beqz	a0,80004a08 <kexec+0x270>
    if(argc >= MAXARG)
    80004a00:	fb8499e3          	bne	s1,s8,800049b2 <kexec+0x21a>
  sz = sz1;
    80004a04:	89d2                	mv	s3,s4
    80004a06:	b7a5                	j	8000496e <kexec+0x1d6>
  ustack[argc] = 0;
    80004a08:	00349793          	slli	a5,s1,0x3
    80004a0c:	f9078793          	addi	a5,a5,-112
    80004a10:	97a2                	add	a5,a5,s0
    80004a12:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004a16:	00349693          	slli	a3,s1,0x3
    80004a1a:	06a1                	addi	a3,a3,8
    80004a1c:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004a20:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004a24:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80004a26:	f57964e3          	bltu	s2,s7,8000496e <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004a2a:	e9040613          	addi	a2,s0,-368
    80004a2e:	85ca                	mv	a1,s2
    80004a30:	855a                	mv	a0,s6
    80004a32:	c23fc0ef          	jal	80001654 <copyout>
    80004a36:	f2054ce3          	bltz	a0,8000496e <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004a3a:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004a3e:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004a42:	df043783          	ld	a5,-528(s0)
    80004a46:	0007c703          	lbu	a4,0(a5)
    80004a4a:	cf11                	beqz	a4,80004a66 <kexec+0x2ce>
    80004a4c:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004a4e:	02f00693          	li	a3,47
    80004a52:	a029                	j	80004a5c <kexec+0x2c4>
  for(last=s=path; *s; s++)
    80004a54:	0785                	addi	a5,a5,1
    80004a56:	fff7c703          	lbu	a4,-1(a5)
    80004a5a:	c711                	beqz	a4,80004a66 <kexec+0x2ce>
    if(*s == '/')
    80004a5c:	fed71ce3          	bne	a4,a3,80004a54 <kexec+0x2bc>
      last = s+1;
    80004a60:	def43823          	sd	a5,-528(s0)
    80004a64:	bfc5                	j	80004a54 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004a66:	4641                	li	a2,16
    80004a68:	df043583          	ld	a1,-528(s0)
    80004a6c:	158a8513          	addi	a0,s5,344
    80004a70:	bdcfc0ef          	jal	80000e4c <safestrcpy>
  oldpagetable = p->pagetable;
    80004a74:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004a78:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004a7c:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004a80:	058ab783          	ld	a5,88(s5)
    80004a84:	e6843703          	ld	a4,-408(s0)
    80004a88:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004a8a:	058ab783          	ld	a5,88(s5)
    80004a8e:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004a92:	85ea                	mv	a1,s10
    80004a94:	902fd0ef          	jal	80001b96 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004a98:	0004851b          	sext.w	a0,s1
    80004a9c:	79fe                	ld	s3,504(sp)
    80004a9e:	7a5e                	ld	s4,496(sp)
    80004aa0:	7abe                	ld	s5,488(sp)
    80004aa2:	7b1e                	ld	s6,480(sp)
    80004aa4:	6bfe                	ld	s7,472(sp)
    80004aa6:	6c5e                	ld	s8,464(sp)
    80004aa8:	6cbe                	ld	s9,456(sp)
    80004aaa:	6d1e                	ld	s10,448(sp)
    80004aac:	7dfa                	ld	s11,440(sp)
    80004aae:	bbb1                	j	8000480a <kexec+0x72>
    80004ab0:	7b1e                	ld	s6,480(sp)
    80004ab2:	b3a9                	j	800047fc <kexec+0x64>
    80004ab4:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004ab8:	df843583          	ld	a1,-520(s0)
    80004abc:	855a                	mv	a0,s6
    80004abe:	8d8fd0ef          	jal	80001b96 <proc_freepagetable>
  if(ip){
    80004ac2:	79fe                	ld	s3,504(sp)
    80004ac4:	7abe                	ld	s5,488(sp)
    80004ac6:	7b1e                	ld	s6,480(sp)
    80004ac8:	6bfe                	ld	s7,472(sp)
    80004aca:	6c5e                	ld	s8,464(sp)
    80004acc:	6cbe                	ld	s9,456(sp)
    80004ace:	6d1e                	ld	s10,448(sp)
    80004ad0:	7dfa                	ld	s11,440(sp)
    80004ad2:	b32d                	j	800047fc <kexec+0x64>
    80004ad4:	df243c23          	sd	s2,-520(s0)
    80004ad8:	b7c5                	j	80004ab8 <kexec+0x320>
    80004ada:	df243c23          	sd	s2,-520(s0)
    80004ade:	bfe9                	j	80004ab8 <kexec+0x320>
    80004ae0:	df243c23          	sd	s2,-520(s0)
    80004ae4:	bfd1                	j	80004ab8 <kexec+0x320>
    80004ae6:	df243c23          	sd	s2,-520(s0)
    80004aea:	b7f9                	j	80004ab8 <kexec+0x320>
  sz = sz1;
    80004aec:	89d2                	mv	s3,s4
    80004aee:	b541                	j	8000496e <kexec+0x1d6>
    80004af0:	89d2                	mv	s3,s4
    80004af2:	bdb5                	j	8000496e <kexec+0x1d6>

0000000080004af4 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004af4:	7179                	addi	sp,sp,-48
    80004af6:	f406                	sd	ra,40(sp)
    80004af8:	f022                	sd	s0,32(sp)
    80004afa:	ec26                	sd	s1,24(sp)
    80004afc:	e84a                	sd	s2,16(sp)
    80004afe:	1800                	addi	s0,sp,48
    80004b00:	892e                	mv	s2,a1
    80004b02:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004b04:	fdc40593          	addi	a1,s0,-36
    80004b08:	e4bfd0ef          	jal	80002952 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004b0c:	fdc42703          	lw	a4,-36(s0)
    80004b10:	47bd                	li	a5,15
    80004b12:	02e7ea63          	bltu	a5,a4,80004b46 <argfd+0x52>
    80004b16:	ef3fc0ef          	jal	80001a08 <myproc>
    80004b1a:	fdc42703          	lw	a4,-36(s0)
    80004b1e:	00371793          	slli	a5,a4,0x3
    80004b22:	0d078793          	addi	a5,a5,208
    80004b26:	953e                	add	a0,a0,a5
    80004b28:	611c                	ld	a5,0(a0)
    80004b2a:	c385                	beqz	a5,80004b4a <argfd+0x56>
    return -1;
  if(pfd)
    80004b2c:	00090463          	beqz	s2,80004b34 <argfd+0x40>
    *pfd = fd;
    80004b30:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004b34:	4501                	li	a0,0
  if(pf)
    80004b36:	c091                	beqz	s1,80004b3a <argfd+0x46>
    *pf = f;
    80004b38:	e09c                	sd	a5,0(s1)
}
    80004b3a:	70a2                	ld	ra,40(sp)
    80004b3c:	7402                	ld	s0,32(sp)
    80004b3e:	64e2                	ld	s1,24(sp)
    80004b40:	6942                	ld	s2,16(sp)
    80004b42:	6145                	addi	sp,sp,48
    80004b44:	8082                	ret
    return -1;
    80004b46:	557d                	li	a0,-1
    80004b48:	bfcd                	j	80004b3a <argfd+0x46>
    80004b4a:	557d                	li	a0,-1
    80004b4c:	b7fd                	j	80004b3a <argfd+0x46>

0000000080004b4e <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004b4e:	1101                	addi	sp,sp,-32
    80004b50:	ec06                	sd	ra,24(sp)
    80004b52:	e822                	sd	s0,16(sp)
    80004b54:	e426                	sd	s1,8(sp)
    80004b56:	1000                	addi	s0,sp,32
    80004b58:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004b5a:	eaffc0ef          	jal	80001a08 <myproc>
    80004b5e:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004b60:	0d050793          	addi	a5,a0,208
    80004b64:	4501                	li	a0,0
    80004b66:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004b68:	6398                	ld	a4,0(a5)
    80004b6a:	cb19                	beqz	a4,80004b80 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004b6c:	2505                	addiw	a0,a0,1
    80004b6e:	07a1                	addi	a5,a5,8
    80004b70:	fed51ce3          	bne	a0,a3,80004b68 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004b74:	557d                	li	a0,-1
}
    80004b76:	60e2                	ld	ra,24(sp)
    80004b78:	6442                	ld	s0,16(sp)
    80004b7a:	64a2                	ld	s1,8(sp)
    80004b7c:	6105                	addi	sp,sp,32
    80004b7e:	8082                	ret
      p->ofile[fd] = f;
    80004b80:	00351793          	slli	a5,a0,0x3
    80004b84:	0d078793          	addi	a5,a5,208
    80004b88:	963e                	add	a2,a2,a5
    80004b8a:	e204                	sd	s1,0(a2)
      return fd;
    80004b8c:	b7ed                	j	80004b76 <fdalloc+0x28>

0000000080004b8e <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004b8e:	715d                	addi	sp,sp,-80
    80004b90:	e486                	sd	ra,72(sp)
    80004b92:	e0a2                	sd	s0,64(sp)
    80004b94:	fc26                	sd	s1,56(sp)
    80004b96:	f84a                	sd	s2,48(sp)
    80004b98:	f44e                	sd	s3,40(sp)
    80004b9a:	f052                	sd	s4,32(sp)
    80004b9c:	ec56                	sd	s5,24(sp)
    80004b9e:	e85a                	sd	s6,16(sp)
    80004ba0:	0880                	addi	s0,sp,80
    80004ba2:	892e                	mv	s2,a1
    80004ba4:	8a2e                	mv	s4,a1
    80004ba6:	8ab2                	mv	s5,a2
    80004ba8:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004baa:	fb040593          	addi	a1,s0,-80
    80004bae:	fb7fe0ef          	jal	80003b64 <nameiparent>
    80004bb2:	84aa                	mv	s1,a0
    80004bb4:	10050763          	beqz	a0,80004cc2 <create+0x134>
    return 0;

  ilock(dp);
    80004bb8:	f64fe0ef          	jal	8000331c <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004bbc:	4601                	li	a2,0
    80004bbe:	fb040593          	addi	a1,s0,-80
    80004bc2:	8526                	mv	a0,s1
    80004bc4:	cf3fe0ef          	jal	800038b6 <dirlookup>
    80004bc8:	89aa                	mv	s3,a0
    80004bca:	c131                	beqz	a0,80004c0e <create+0x80>
    iunlockput(dp);
    80004bcc:	8526                	mv	a0,s1
    80004bce:	95bfe0ef          	jal	80003528 <iunlockput>
    ilock(ip);
    80004bd2:	854e                	mv	a0,s3
    80004bd4:	f48fe0ef          	jal	8000331c <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004bd8:	4789                	li	a5,2
    80004bda:	02f91563          	bne	s2,a5,80004c04 <create+0x76>
    80004bde:	0449d783          	lhu	a5,68(s3)
    80004be2:	37f9                	addiw	a5,a5,-2
    80004be4:	17c2                	slli	a5,a5,0x30
    80004be6:	93c1                	srli	a5,a5,0x30
    80004be8:	4705                	li	a4,1
    80004bea:	00f76d63          	bltu	a4,a5,80004c04 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004bee:	854e                	mv	a0,s3
    80004bf0:	60a6                	ld	ra,72(sp)
    80004bf2:	6406                	ld	s0,64(sp)
    80004bf4:	74e2                	ld	s1,56(sp)
    80004bf6:	7942                	ld	s2,48(sp)
    80004bf8:	79a2                	ld	s3,40(sp)
    80004bfa:	7a02                	ld	s4,32(sp)
    80004bfc:	6ae2                	ld	s5,24(sp)
    80004bfe:	6b42                	ld	s6,16(sp)
    80004c00:	6161                	addi	sp,sp,80
    80004c02:	8082                	ret
    iunlockput(ip);
    80004c04:	854e                	mv	a0,s3
    80004c06:	923fe0ef          	jal	80003528 <iunlockput>
    return 0;
    80004c0a:	4981                	li	s3,0
    80004c0c:	b7cd                	j	80004bee <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004c0e:	85ca                	mv	a1,s2
    80004c10:	4088                	lw	a0,0(s1)
    80004c12:	d9afe0ef          	jal	800031ac <ialloc>
    80004c16:	892a                	mv	s2,a0
    80004c18:	cd15                	beqz	a0,80004c54 <create+0xc6>
  ilock(ip);
    80004c1a:	f02fe0ef          	jal	8000331c <ilock>
  ip->major = major;
    80004c1e:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004c22:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004c26:	4785                	li	a5,1
    80004c28:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004c2c:	854a                	mv	a0,s2
    80004c2e:	e3afe0ef          	jal	80003268 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004c32:	4705                	li	a4,1
    80004c34:	02ea0463          	beq	s4,a4,80004c5c <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004c38:	00492603          	lw	a2,4(s2)
    80004c3c:	fb040593          	addi	a1,s0,-80
    80004c40:	8526                	mv	a0,s1
    80004c42:	e5ffe0ef          	jal	80003aa0 <dirlink>
    80004c46:	06054263          	bltz	a0,80004caa <create+0x11c>
  iunlockput(dp);
    80004c4a:	8526                	mv	a0,s1
    80004c4c:	8ddfe0ef          	jal	80003528 <iunlockput>
  return ip;
    80004c50:	89ca                	mv	s3,s2
    80004c52:	bf71                	j	80004bee <create+0x60>
    iunlockput(dp);
    80004c54:	8526                	mv	a0,s1
    80004c56:	8d3fe0ef          	jal	80003528 <iunlockput>
    return 0;
    80004c5a:	bf51                	j	80004bee <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004c5c:	00492603          	lw	a2,4(s2)
    80004c60:	00003597          	auipc	a1,0x3
    80004c64:	9c058593          	addi	a1,a1,-1600 # 80007620 <etext+0x620>
    80004c68:	854a                	mv	a0,s2
    80004c6a:	e37fe0ef          	jal	80003aa0 <dirlink>
    80004c6e:	02054e63          	bltz	a0,80004caa <create+0x11c>
    80004c72:	40d0                	lw	a2,4(s1)
    80004c74:	00003597          	auipc	a1,0x3
    80004c78:	9b458593          	addi	a1,a1,-1612 # 80007628 <etext+0x628>
    80004c7c:	854a                	mv	a0,s2
    80004c7e:	e23fe0ef          	jal	80003aa0 <dirlink>
    80004c82:	02054463          	bltz	a0,80004caa <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004c86:	00492603          	lw	a2,4(s2)
    80004c8a:	fb040593          	addi	a1,s0,-80
    80004c8e:	8526                	mv	a0,s1
    80004c90:	e11fe0ef          	jal	80003aa0 <dirlink>
    80004c94:	00054b63          	bltz	a0,80004caa <create+0x11c>
    dp->nlink++;  // for ".."
    80004c98:	04a4d783          	lhu	a5,74(s1)
    80004c9c:	2785                	addiw	a5,a5,1
    80004c9e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004ca2:	8526                	mv	a0,s1
    80004ca4:	dc4fe0ef          	jal	80003268 <iupdate>
    80004ca8:	b74d                	j	80004c4a <create+0xbc>
  ip->nlink = 0;
    80004caa:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004cae:	854a                	mv	a0,s2
    80004cb0:	db8fe0ef          	jal	80003268 <iupdate>
  iunlockput(ip);
    80004cb4:	854a                	mv	a0,s2
    80004cb6:	873fe0ef          	jal	80003528 <iunlockput>
  iunlockput(dp);
    80004cba:	8526                	mv	a0,s1
    80004cbc:	86dfe0ef          	jal	80003528 <iunlockput>
  return 0;
    80004cc0:	b73d                	j	80004bee <create+0x60>
    return 0;
    80004cc2:	89aa                	mv	s3,a0
    80004cc4:	b72d                	j	80004bee <create+0x60>

0000000080004cc6 <sys_dup>:
{
    80004cc6:	7179                	addi	sp,sp,-48
    80004cc8:	f406                	sd	ra,40(sp)
    80004cca:	f022                	sd	s0,32(sp)
    80004ccc:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004cce:	fd840613          	addi	a2,s0,-40
    80004cd2:	4581                	li	a1,0
    80004cd4:	4501                	li	a0,0
    80004cd6:	e1fff0ef          	jal	80004af4 <argfd>
    return -1;
    80004cda:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004cdc:	02054363          	bltz	a0,80004d02 <sys_dup+0x3c>
    80004ce0:	ec26                	sd	s1,24(sp)
    80004ce2:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004ce4:	fd843483          	ld	s1,-40(s0)
    80004ce8:	8526                	mv	a0,s1
    80004cea:	e65ff0ef          	jal	80004b4e <fdalloc>
    80004cee:	892a                	mv	s2,a0
    return -1;
    80004cf0:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004cf2:	00054d63          	bltz	a0,80004d0c <sys_dup+0x46>
  filedup(f);
    80004cf6:	8526                	mv	a0,s1
    80004cf8:	c0eff0ef          	jal	80004106 <filedup>
  return fd;
    80004cfc:	87ca                	mv	a5,s2
    80004cfe:	64e2                	ld	s1,24(sp)
    80004d00:	6942                	ld	s2,16(sp)
}
    80004d02:	853e                	mv	a0,a5
    80004d04:	70a2                	ld	ra,40(sp)
    80004d06:	7402                	ld	s0,32(sp)
    80004d08:	6145                	addi	sp,sp,48
    80004d0a:	8082                	ret
    80004d0c:	64e2                	ld	s1,24(sp)
    80004d0e:	6942                	ld	s2,16(sp)
    80004d10:	bfcd                	j	80004d02 <sys_dup+0x3c>

0000000080004d12 <sys_read>:
{
    80004d12:	7179                	addi	sp,sp,-48
    80004d14:	f406                	sd	ra,40(sp)
    80004d16:	f022                	sd	s0,32(sp)
    80004d18:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d1a:	fd840593          	addi	a1,s0,-40
    80004d1e:	4505                	li	a0,1
    80004d20:	c4ffd0ef          	jal	8000296e <argaddr>
  argint(2, &n);
    80004d24:	fe440593          	addi	a1,s0,-28
    80004d28:	4509                	li	a0,2
    80004d2a:	c29fd0ef          	jal	80002952 <argint>
  if(argfd(0, 0, &f) < 0)
    80004d2e:	fe840613          	addi	a2,s0,-24
    80004d32:	4581                	li	a1,0
    80004d34:	4501                	li	a0,0
    80004d36:	dbfff0ef          	jal	80004af4 <argfd>
    80004d3a:	87aa                	mv	a5,a0
    return -1;
    80004d3c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d3e:	0007ca63          	bltz	a5,80004d52 <sys_read+0x40>
  return fileread(f, p, n);
    80004d42:	fe442603          	lw	a2,-28(s0)
    80004d46:	fd843583          	ld	a1,-40(s0)
    80004d4a:	fe843503          	ld	a0,-24(s0)
    80004d4e:	d22ff0ef          	jal	80004270 <fileread>
}
    80004d52:	70a2                	ld	ra,40(sp)
    80004d54:	7402                	ld	s0,32(sp)
    80004d56:	6145                	addi	sp,sp,48
    80004d58:	8082                	ret

0000000080004d5a <sys_write>:
{
    80004d5a:	7179                	addi	sp,sp,-48
    80004d5c:	f406                	sd	ra,40(sp)
    80004d5e:	f022                	sd	s0,32(sp)
    80004d60:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d62:	fd840593          	addi	a1,s0,-40
    80004d66:	4505                	li	a0,1
    80004d68:	c07fd0ef          	jal	8000296e <argaddr>
  argint(2, &n);
    80004d6c:	fe440593          	addi	a1,s0,-28
    80004d70:	4509                	li	a0,2
    80004d72:	be1fd0ef          	jal	80002952 <argint>
  if(argfd(0, 0, &f) < 0)
    80004d76:	fe840613          	addi	a2,s0,-24
    80004d7a:	4581                	li	a1,0
    80004d7c:	4501                	li	a0,0
    80004d7e:	d77ff0ef          	jal	80004af4 <argfd>
    80004d82:	87aa                	mv	a5,a0
    return -1;
    80004d84:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d86:	0007ca63          	bltz	a5,80004d9a <sys_write+0x40>
  return filewrite(f, p, n);
    80004d8a:	fe442603          	lw	a2,-28(s0)
    80004d8e:	fd843583          	ld	a1,-40(s0)
    80004d92:	fe843503          	ld	a0,-24(s0)
    80004d96:	d9eff0ef          	jal	80004334 <filewrite>
}
    80004d9a:	70a2                	ld	ra,40(sp)
    80004d9c:	7402                	ld	s0,32(sp)
    80004d9e:	6145                	addi	sp,sp,48
    80004da0:	8082                	ret

0000000080004da2 <sys_close>:
{
    80004da2:	1101                	addi	sp,sp,-32
    80004da4:	ec06                	sd	ra,24(sp)
    80004da6:	e822                	sd	s0,16(sp)
    80004da8:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004daa:	fe040613          	addi	a2,s0,-32
    80004dae:	fec40593          	addi	a1,s0,-20
    80004db2:	4501                	li	a0,0
    80004db4:	d41ff0ef          	jal	80004af4 <argfd>
    return -1;
    80004db8:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004dba:	02054163          	bltz	a0,80004ddc <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004dbe:	c4bfc0ef          	jal	80001a08 <myproc>
    80004dc2:	fec42783          	lw	a5,-20(s0)
    80004dc6:	078e                	slli	a5,a5,0x3
    80004dc8:	0d078793          	addi	a5,a5,208
    80004dcc:	953e                	add	a0,a0,a5
    80004dce:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004dd2:	fe043503          	ld	a0,-32(s0)
    80004dd6:	b76ff0ef          	jal	8000414c <fileclose>
  return 0;
    80004dda:	4781                	li	a5,0
}
    80004ddc:	853e                	mv	a0,a5
    80004dde:	60e2                	ld	ra,24(sp)
    80004de0:	6442                	ld	s0,16(sp)
    80004de2:	6105                	addi	sp,sp,32
    80004de4:	8082                	ret

0000000080004de6 <sys_fstat>:
{
    80004de6:	1101                	addi	sp,sp,-32
    80004de8:	ec06                	sd	ra,24(sp)
    80004dea:	e822                	sd	s0,16(sp)
    80004dec:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004dee:	fe040593          	addi	a1,s0,-32
    80004df2:	4505                	li	a0,1
    80004df4:	b7bfd0ef          	jal	8000296e <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004df8:	fe840613          	addi	a2,s0,-24
    80004dfc:	4581                	li	a1,0
    80004dfe:	4501                	li	a0,0
    80004e00:	cf5ff0ef          	jal	80004af4 <argfd>
    80004e04:	87aa                	mv	a5,a0
    return -1;
    80004e06:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004e08:	0007c863          	bltz	a5,80004e18 <sys_fstat+0x32>
  return filestat(f, st);
    80004e0c:	fe043583          	ld	a1,-32(s0)
    80004e10:	fe843503          	ld	a0,-24(s0)
    80004e14:	bfaff0ef          	jal	8000420e <filestat>
}
    80004e18:	60e2                	ld	ra,24(sp)
    80004e1a:	6442                	ld	s0,16(sp)
    80004e1c:	6105                	addi	sp,sp,32
    80004e1e:	8082                	ret

0000000080004e20 <sys_link>:
{
    80004e20:	7169                	addi	sp,sp,-304
    80004e22:	f606                	sd	ra,296(sp)
    80004e24:	f222                	sd	s0,288(sp)
    80004e26:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e28:	08000613          	li	a2,128
    80004e2c:	ed040593          	addi	a1,s0,-304
    80004e30:	4501                	li	a0,0
    80004e32:	b59fd0ef          	jal	8000298a <argstr>
    return -1;
    80004e36:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e38:	0c054e63          	bltz	a0,80004f14 <sys_link+0xf4>
    80004e3c:	08000613          	li	a2,128
    80004e40:	f5040593          	addi	a1,s0,-176
    80004e44:	4505                	li	a0,1
    80004e46:	b45fd0ef          	jal	8000298a <argstr>
    return -1;
    80004e4a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e4c:	0c054463          	bltz	a0,80004f14 <sys_link+0xf4>
    80004e50:	ee26                	sd	s1,280(sp)
  begin_op();
    80004e52:	ed7fe0ef          	jal	80003d28 <begin_op>
  if((ip = namei(old)) == 0){
    80004e56:	ed040513          	addi	a0,s0,-304
    80004e5a:	cf1fe0ef          	jal	80003b4a <namei>
    80004e5e:	84aa                	mv	s1,a0
    80004e60:	c53d                	beqz	a0,80004ece <sys_link+0xae>
  ilock(ip);
    80004e62:	cbafe0ef          	jal	8000331c <ilock>
  if(ip->type == T_DIR){
    80004e66:	04449703          	lh	a4,68(s1)
    80004e6a:	4785                	li	a5,1
    80004e6c:	06f70663          	beq	a4,a5,80004ed8 <sys_link+0xb8>
    80004e70:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004e72:	04a4d783          	lhu	a5,74(s1)
    80004e76:	2785                	addiw	a5,a5,1
    80004e78:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004e7c:	8526                	mv	a0,s1
    80004e7e:	beafe0ef          	jal	80003268 <iupdate>
  iunlock(ip);
    80004e82:	8526                	mv	a0,s1
    80004e84:	d46fe0ef          	jal	800033ca <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004e88:	fd040593          	addi	a1,s0,-48
    80004e8c:	f5040513          	addi	a0,s0,-176
    80004e90:	cd5fe0ef          	jal	80003b64 <nameiparent>
    80004e94:	892a                	mv	s2,a0
    80004e96:	cd21                	beqz	a0,80004eee <sys_link+0xce>
  ilock(dp);
    80004e98:	c84fe0ef          	jal	8000331c <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004e9c:	854a                	mv	a0,s2
    80004e9e:	00092703          	lw	a4,0(s2)
    80004ea2:	409c                	lw	a5,0(s1)
    80004ea4:	04f71263          	bne	a4,a5,80004ee8 <sys_link+0xc8>
    80004ea8:	40d0                	lw	a2,4(s1)
    80004eaa:	fd040593          	addi	a1,s0,-48
    80004eae:	bf3fe0ef          	jal	80003aa0 <dirlink>
    80004eb2:	02054b63          	bltz	a0,80004ee8 <sys_link+0xc8>
  iunlockput(dp);
    80004eb6:	854a                	mv	a0,s2
    80004eb8:	e70fe0ef          	jal	80003528 <iunlockput>
  iput(ip);
    80004ebc:	8526                	mv	a0,s1
    80004ebe:	de0fe0ef          	jal	8000349e <iput>
  end_op();
    80004ec2:	ed7fe0ef          	jal	80003d98 <end_op>
  return 0;
    80004ec6:	4781                	li	a5,0
    80004ec8:	64f2                	ld	s1,280(sp)
    80004eca:	6952                	ld	s2,272(sp)
    80004ecc:	a0a1                	j	80004f14 <sys_link+0xf4>
    end_op();
    80004ece:	ecbfe0ef          	jal	80003d98 <end_op>
    return -1;
    80004ed2:	57fd                	li	a5,-1
    80004ed4:	64f2                	ld	s1,280(sp)
    80004ed6:	a83d                	j	80004f14 <sys_link+0xf4>
    iunlockput(ip);
    80004ed8:	8526                	mv	a0,s1
    80004eda:	e4efe0ef          	jal	80003528 <iunlockput>
    end_op();
    80004ede:	ebbfe0ef          	jal	80003d98 <end_op>
    return -1;
    80004ee2:	57fd                	li	a5,-1
    80004ee4:	64f2                	ld	s1,280(sp)
    80004ee6:	a03d                	j	80004f14 <sys_link+0xf4>
    iunlockput(dp);
    80004ee8:	854a                	mv	a0,s2
    80004eea:	e3efe0ef          	jal	80003528 <iunlockput>
  ilock(ip);
    80004eee:	8526                	mv	a0,s1
    80004ef0:	c2cfe0ef          	jal	8000331c <ilock>
  ip->nlink--;
    80004ef4:	04a4d783          	lhu	a5,74(s1)
    80004ef8:	37fd                	addiw	a5,a5,-1
    80004efa:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004efe:	8526                	mv	a0,s1
    80004f00:	b68fe0ef          	jal	80003268 <iupdate>
  iunlockput(ip);
    80004f04:	8526                	mv	a0,s1
    80004f06:	e22fe0ef          	jal	80003528 <iunlockput>
  end_op();
    80004f0a:	e8ffe0ef          	jal	80003d98 <end_op>
  return -1;
    80004f0e:	57fd                	li	a5,-1
    80004f10:	64f2                	ld	s1,280(sp)
    80004f12:	6952                	ld	s2,272(sp)
}
    80004f14:	853e                	mv	a0,a5
    80004f16:	70b2                	ld	ra,296(sp)
    80004f18:	7412                	ld	s0,288(sp)
    80004f1a:	6155                	addi	sp,sp,304
    80004f1c:	8082                	ret

0000000080004f1e <sys_unlink>:
{
    80004f1e:	7151                	addi	sp,sp,-240
    80004f20:	f586                	sd	ra,232(sp)
    80004f22:	f1a2                	sd	s0,224(sp)
    80004f24:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004f26:	08000613          	li	a2,128
    80004f2a:	f3040593          	addi	a1,s0,-208
    80004f2e:	4501                	li	a0,0
    80004f30:	a5bfd0ef          	jal	8000298a <argstr>
    80004f34:	14054d63          	bltz	a0,8000508e <sys_unlink+0x170>
    80004f38:	eda6                	sd	s1,216(sp)
  begin_op();
    80004f3a:	deffe0ef          	jal	80003d28 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004f3e:	fb040593          	addi	a1,s0,-80
    80004f42:	f3040513          	addi	a0,s0,-208
    80004f46:	c1ffe0ef          	jal	80003b64 <nameiparent>
    80004f4a:	84aa                	mv	s1,a0
    80004f4c:	c955                	beqz	a0,80005000 <sys_unlink+0xe2>
  ilock(dp);
    80004f4e:	bcefe0ef          	jal	8000331c <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004f52:	00002597          	auipc	a1,0x2
    80004f56:	6ce58593          	addi	a1,a1,1742 # 80007620 <etext+0x620>
    80004f5a:	fb040513          	addi	a0,s0,-80
    80004f5e:	943fe0ef          	jal	800038a0 <namecmp>
    80004f62:	10050b63          	beqz	a0,80005078 <sys_unlink+0x15a>
    80004f66:	00002597          	auipc	a1,0x2
    80004f6a:	6c258593          	addi	a1,a1,1730 # 80007628 <etext+0x628>
    80004f6e:	fb040513          	addi	a0,s0,-80
    80004f72:	92ffe0ef          	jal	800038a0 <namecmp>
    80004f76:	10050163          	beqz	a0,80005078 <sys_unlink+0x15a>
    80004f7a:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004f7c:	f2c40613          	addi	a2,s0,-212
    80004f80:	fb040593          	addi	a1,s0,-80
    80004f84:	8526                	mv	a0,s1
    80004f86:	931fe0ef          	jal	800038b6 <dirlookup>
    80004f8a:	892a                	mv	s2,a0
    80004f8c:	0e050563          	beqz	a0,80005076 <sys_unlink+0x158>
    80004f90:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004f92:	b8afe0ef          	jal	8000331c <ilock>
  if(ip->nlink < 1)
    80004f96:	04a91783          	lh	a5,74(s2)
    80004f9a:	06f05863          	blez	a5,8000500a <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004f9e:	04491703          	lh	a4,68(s2)
    80004fa2:	4785                	li	a5,1
    80004fa4:	06f70963          	beq	a4,a5,80005016 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004fa8:	fc040993          	addi	s3,s0,-64
    80004fac:	4641                	li	a2,16
    80004fae:	4581                	li	a1,0
    80004fb0:	854e                	mv	a0,s3
    80004fb2:	d47fb0ef          	jal	80000cf8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004fb6:	4741                	li	a4,16
    80004fb8:	f2c42683          	lw	a3,-212(s0)
    80004fbc:	864e                	mv	a2,s3
    80004fbe:	4581                	li	a1,0
    80004fc0:	8526                	mv	a0,s1
    80004fc2:	fdefe0ef          	jal	800037a0 <writei>
    80004fc6:	47c1                	li	a5,16
    80004fc8:	08f51863          	bne	a0,a5,80005058 <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004fcc:	04491703          	lh	a4,68(s2)
    80004fd0:	4785                	li	a5,1
    80004fd2:	08f70963          	beq	a4,a5,80005064 <sys_unlink+0x146>
  iunlockput(dp);
    80004fd6:	8526                	mv	a0,s1
    80004fd8:	d50fe0ef          	jal	80003528 <iunlockput>
  ip->nlink--;
    80004fdc:	04a95783          	lhu	a5,74(s2)
    80004fe0:	37fd                	addiw	a5,a5,-1
    80004fe2:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004fe6:	854a                	mv	a0,s2
    80004fe8:	a80fe0ef          	jal	80003268 <iupdate>
  iunlockput(ip);
    80004fec:	854a                	mv	a0,s2
    80004fee:	d3afe0ef          	jal	80003528 <iunlockput>
  end_op();
    80004ff2:	da7fe0ef          	jal	80003d98 <end_op>
  return 0;
    80004ff6:	4501                	li	a0,0
    80004ff8:	64ee                	ld	s1,216(sp)
    80004ffa:	694e                	ld	s2,208(sp)
    80004ffc:	69ae                	ld	s3,200(sp)
    80004ffe:	a061                	j	80005086 <sys_unlink+0x168>
    end_op();
    80005000:	d99fe0ef          	jal	80003d98 <end_op>
    return -1;
    80005004:	557d                	li	a0,-1
    80005006:	64ee                	ld	s1,216(sp)
    80005008:	a8bd                	j	80005086 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000500a:	00002517          	auipc	a0,0x2
    8000500e:	62650513          	addi	a0,a0,1574 # 80007630 <etext+0x630>
    80005012:	813fb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005016:	04c92703          	lw	a4,76(s2)
    8000501a:	02000793          	li	a5,32
    8000501e:	f8e7f5e3          	bgeu	a5,a4,80004fa8 <sys_unlink+0x8a>
    80005022:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005024:	4741                	li	a4,16
    80005026:	86ce                	mv	a3,s3
    80005028:	f1840613          	addi	a2,s0,-232
    8000502c:	4581                	li	a1,0
    8000502e:	854a                	mv	a0,s2
    80005030:	e7efe0ef          	jal	800036ae <readi>
    80005034:	47c1                	li	a5,16
    80005036:	00f51b63          	bne	a0,a5,8000504c <sys_unlink+0x12e>
    if(de.inum != 0)
    8000503a:	f1845783          	lhu	a5,-232(s0)
    8000503e:	ebb1                	bnez	a5,80005092 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005040:	29c1                	addiw	s3,s3,16
    80005042:	04c92783          	lw	a5,76(s2)
    80005046:	fcf9efe3          	bltu	s3,a5,80005024 <sys_unlink+0x106>
    8000504a:	bfb9                	j	80004fa8 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000504c:	00002517          	auipc	a0,0x2
    80005050:	5fc50513          	addi	a0,a0,1532 # 80007648 <etext+0x648>
    80005054:	fd0fb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    80005058:	00002517          	auipc	a0,0x2
    8000505c:	60850513          	addi	a0,a0,1544 # 80007660 <etext+0x660>
    80005060:	fc4fb0ef          	jal	80000824 <panic>
    dp->nlink--;
    80005064:	04a4d783          	lhu	a5,74(s1)
    80005068:	37fd                	addiw	a5,a5,-1
    8000506a:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000506e:	8526                	mv	a0,s1
    80005070:	9f8fe0ef          	jal	80003268 <iupdate>
    80005074:	b78d                	j	80004fd6 <sys_unlink+0xb8>
    80005076:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005078:	8526                	mv	a0,s1
    8000507a:	caefe0ef          	jal	80003528 <iunlockput>
  end_op();
    8000507e:	d1bfe0ef          	jal	80003d98 <end_op>
  return -1;
    80005082:	557d                	li	a0,-1
    80005084:	64ee                	ld	s1,216(sp)
}
    80005086:	70ae                	ld	ra,232(sp)
    80005088:	740e                	ld	s0,224(sp)
    8000508a:	616d                	addi	sp,sp,240
    8000508c:	8082                	ret
    return -1;
    8000508e:	557d                	li	a0,-1
    80005090:	bfdd                	j	80005086 <sys_unlink+0x168>
    iunlockput(ip);
    80005092:	854a                	mv	a0,s2
    80005094:	c94fe0ef          	jal	80003528 <iunlockput>
    goto bad;
    80005098:	694e                	ld	s2,208(sp)
    8000509a:	69ae                	ld	s3,200(sp)
    8000509c:	bff1                	j	80005078 <sys_unlink+0x15a>

000000008000509e <sys_open>:

uint64
sys_open(void)
{
    8000509e:	7131                	addi	sp,sp,-192
    800050a0:	fd06                	sd	ra,184(sp)
    800050a2:	f922                	sd	s0,176(sp)
    800050a4:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800050a6:	f4c40593          	addi	a1,s0,-180
    800050aa:	4505                	li	a0,1
    800050ac:	8a7fd0ef          	jal	80002952 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800050b0:	08000613          	li	a2,128
    800050b4:	f5040593          	addi	a1,s0,-176
    800050b8:	4501                	li	a0,0
    800050ba:	8d1fd0ef          	jal	8000298a <argstr>
    800050be:	87aa                	mv	a5,a0
    return -1;
    800050c0:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800050c2:	0a07c363          	bltz	a5,80005168 <sys_open+0xca>
    800050c6:	f526                	sd	s1,168(sp)

  begin_op();
    800050c8:	c61fe0ef          	jal	80003d28 <begin_op>

  if(omode & O_CREATE){
    800050cc:	f4c42783          	lw	a5,-180(s0)
    800050d0:	2007f793          	andi	a5,a5,512
    800050d4:	c3dd                	beqz	a5,8000517a <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    800050d6:	4681                	li	a3,0
    800050d8:	4601                	li	a2,0
    800050da:	4589                	li	a1,2
    800050dc:	f5040513          	addi	a0,s0,-176
    800050e0:	aafff0ef          	jal	80004b8e <create>
    800050e4:	84aa                	mv	s1,a0
    if(ip == 0){
    800050e6:	c549                	beqz	a0,80005170 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800050e8:	04449703          	lh	a4,68(s1)
    800050ec:	478d                	li	a5,3
    800050ee:	00f71763          	bne	a4,a5,800050fc <sys_open+0x5e>
    800050f2:	0464d703          	lhu	a4,70(s1)
    800050f6:	47a5                	li	a5,9
    800050f8:	0ae7ee63          	bltu	a5,a4,800051b4 <sys_open+0x116>
    800050fc:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800050fe:	fabfe0ef          	jal	800040a8 <filealloc>
    80005102:	892a                	mv	s2,a0
    80005104:	c561                	beqz	a0,800051cc <sys_open+0x12e>
    80005106:	ed4e                	sd	s3,152(sp)
    80005108:	a47ff0ef          	jal	80004b4e <fdalloc>
    8000510c:	89aa                	mv	s3,a0
    8000510e:	0a054b63          	bltz	a0,800051c4 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005112:	04449703          	lh	a4,68(s1)
    80005116:	478d                	li	a5,3
    80005118:	0cf70363          	beq	a4,a5,800051de <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000511c:	4789                	li	a5,2
    8000511e:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005122:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005126:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000512a:	f4c42783          	lw	a5,-180(s0)
    8000512e:	0017f713          	andi	a4,a5,1
    80005132:	00174713          	xori	a4,a4,1
    80005136:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000513a:	0037f713          	andi	a4,a5,3
    8000513e:	00e03733          	snez	a4,a4
    80005142:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005146:	4007f793          	andi	a5,a5,1024
    8000514a:	c791                	beqz	a5,80005156 <sys_open+0xb8>
    8000514c:	04449703          	lh	a4,68(s1)
    80005150:	4789                	li	a5,2
    80005152:	08f70d63          	beq	a4,a5,800051ec <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    80005156:	8526                	mv	a0,s1
    80005158:	a72fe0ef          	jal	800033ca <iunlock>
  end_op();
    8000515c:	c3dfe0ef          	jal	80003d98 <end_op>

  return fd;
    80005160:	854e                	mv	a0,s3
    80005162:	74aa                	ld	s1,168(sp)
    80005164:	790a                	ld	s2,160(sp)
    80005166:	69ea                	ld	s3,152(sp)
}
    80005168:	70ea                	ld	ra,184(sp)
    8000516a:	744a                	ld	s0,176(sp)
    8000516c:	6129                	addi	sp,sp,192
    8000516e:	8082                	ret
      end_op();
    80005170:	c29fe0ef          	jal	80003d98 <end_op>
      return -1;
    80005174:	557d                	li	a0,-1
    80005176:	74aa                	ld	s1,168(sp)
    80005178:	bfc5                	j	80005168 <sys_open+0xca>
    if((ip = namei(path)) == 0){
    8000517a:	f5040513          	addi	a0,s0,-176
    8000517e:	9cdfe0ef          	jal	80003b4a <namei>
    80005182:	84aa                	mv	s1,a0
    80005184:	c11d                	beqz	a0,800051aa <sys_open+0x10c>
    ilock(ip);
    80005186:	996fe0ef          	jal	8000331c <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000518a:	04449703          	lh	a4,68(s1)
    8000518e:	4785                	li	a5,1
    80005190:	f4f71ce3          	bne	a4,a5,800050e8 <sys_open+0x4a>
    80005194:	f4c42783          	lw	a5,-180(s0)
    80005198:	d3b5                	beqz	a5,800050fc <sys_open+0x5e>
      iunlockput(ip);
    8000519a:	8526                	mv	a0,s1
    8000519c:	b8cfe0ef          	jal	80003528 <iunlockput>
      end_op();
    800051a0:	bf9fe0ef          	jal	80003d98 <end_op>
      return -1;
    800051a4:	557d                	li	a0,-1
    800051a6:	74aa                	ld	s1,168(sp)
    800051a8:	b7c1                	j	80005168 <sys_open+0xca>
      end_op();
    800051aa:	beffe0ef          	jal	80003d98 <end_op>
      return -1;
    800051ae:	557d                	li	a0,-1
    800051b0:	74aa                	ld	s1,168(sp)
    800051b2:	bf5d                	j	80005168 <sys_open+0xca>
    iunlockput(ip);
    800051b4:	8526                	mv	a0,s1
    800051b6:	b72fe0ef          	jal	80003528 <iunlockput>
    end_op();
    800051ba:	bdffe0ef          	jal	80003d98 <end_op>
    return -1;
    800051be:	557d                	li	a0,-1
    800051c0:	74aa                	ld	s1,168(sp)
    800051c2:	b75d                	j	80005168 <sys_open+0xca>
      fileclose(f);
    800051c4:	854a                	mv	a0,s2
    800051c6:	f87fe0ef          	jal	8000414c <fileclose>
    800051ca:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800051cc:	8526                	mv	a0,s1
    800051ce:	b5afe0ef          	jal	80003528 <iunlockput>
    end_op();
    800051d2:	bc7fe0ef          	jal	80003d98 <end_op>
    return -1;
    800051d6:	557d                	li	a0,-1
    800051d8:	74aa                	ld	s1,168(sp)
    800051da:	790a                	ld	s2,160(sp)
    800051dc:	b771                	j	80005168 <sys_open+0xca>
    f->type = FD_DEVICE;
    800051de:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    800051e2:	04649783          	lh	a5,70(s1)
    800051e6:	02f91223          	sh	a5,36(s2)
    800051ea:	bf35                	j	80005126 <sys_open+0x88>
    itrunc(ip);
    800051ec:	8526                	mv	a0,s1
    800051ee:	a1cfe0ef          	jal	8000340a <itrunc>
    800051f2:	b795                	j	80005156 <sys_open+0xb8>

00000000800051f4 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800051f4:	7175                	addi	sp,sp,-144
    800051f6:	e506                	sd	ra,136(sp)
    800051f8:	e122                	sd	s0,128(sp)
    800051fa:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800051fc:	b2dfe0ef          	jal	80003d28 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005200:	08000613          	li	a2,128
    80005204:	f7040593          	addi	a1,s0,-144
    80005208:	4501                	li	a0,0
    8000520a:	f80fd0ef          	jal	8000298a <argstr>
    8000520e:	02054363          	bltz	a0,80005234 <sys_mkdir+0x40>
    80005212:	4681                	li	a3,0
    80005214:	4601                	li	a2,0
    80005216:	4585                	li	a1,1
    80005218:	f7040513          	addi	a0,s0,-144
    8000521c:	973ff0ef          	jal	80004b8e <create>
    80005220:	c911                	beqz	a0,80005234 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005222:	b06fe0ef          	jal	80003528 <iunlockput>
  end_op();
    80005226:	b73fe0ef          	jal	80003d98 <end_op>
  return 0;
    8000522a:	4501                	li	a0,0
}
    8000522c:	60aa                	ld	ra,136(sp)
    8000522e:	640a                	ld	s0,128(sp)
    80005230:	6149                	addi	sp,sp,144
    80005232:	8082                	ret
    end_op();
    80005234:	b65fe0ef          	jal	80003d98 <end_op>
    return -1;
    80005238:	557d                	li	a0,-1
    8000523a:	bfcd                	j	8000522c <sys_mkdir+0x38>

000000008000523c <sys_mknod>:

uint64
sys_mknod(void)
{
    8000523c:	7135                	addi	sp,sp,-160
    8000523e:	ed06                	sd	ra,152(sp)
    80005240:	e922                	sd	s0,144(sp)
    80005242:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005244:	ae5fe0ef          	jal	80003d28 <begin_op>
  argint(1, &major);
    80005248:	f6c40593          	addi	a1,s0,-148
    8000524c:	4505                	li	a0,1
    8000524e:	f04fd0ef          	jal	80002952 <argint>
  argint(2, &minor);
    80005252:	f6840593          	addi	a1,s0,-152
    80005256:	4509                	li	a0,2
    80005258:	efafd0ef          	jal	80002952 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000525c:	08000613          	li	a2,128
    80005260:	f7040593          	addi	a1,s0,-144
    80005264:	4501                	li	a0,0
    80005266:	f24fd0ef          	jal	8000298a <argstr>
    8000526a:	02054563          	bltz	a0,80005294 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000526e:	f6841683          	lh	a3,-152(s0)
    80005272:	f6c41603          	lh	a2,-148(s0)
    80005276:	458d                	li	a1,3
    80005278:	f7040513          	addi	a0,s0,-144
    8000527c:	913ff0ef          	jal	80004b8e <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005280:	c911                	beqz	a0,80005294 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005282:	aa6fe0ef          	jal	80003528 <iunlockput>
  end_op();
    80005286:	b13fe0ef          	jal	80003d98 <end_op>
  return 0;
    8000528a:	4501                	li	a0,0
}
    8000528c:	60ea                	ld	ra,152(sp)
    8000528e:	644a                	ld	s0,144(sp)
    80005290:	610d                	addi	sp,sp,160
    80005292:	8082                	ret
    end_op();
    80005294:	b05fe0ef          	jal	80003d98 <end_op>
    return -1;
    80005298:	557d                	li	a0,-1
    8000529a:	bfcd                	j	8000528c <sys_mknod+0x50>

000000008000529c <sys_chdir>:

uint64
sys_chdir(void)
{
    8000529c:	7135                	addi	sp,sp,-160
    8000529e:	ed06                	sd	ra,152(sp)
    800052a0:	e922                	sd	s0,144(sp)
    800052a2:	e14a                	sd	s2,128(sp)
    800052a4:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800052a6:	f62fc0ef          	jal	80001a08 <myproc>
    800052aa:	892a                	mv	s2,a0
  
  begin_op();
    800052ac:	a7dfe0ef          	jal	80003d28 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800052b0:	08000613          	li	a2,128
    800052b4:	f6040593          	addi	a1,s0,-160
    800052b8:	4501                	li	a0,0
    800052ba:	ed0fd0ef          	jal	8000298a <argstr>
    800052be:	04054363          	bltz	a0,80005304 <sys_chdir+0x68>
    800052c2:	e526                	sd	s1,136(sp)
    800052c4:	f6040513          	addi	a0,s0,-160
    800052c8:	883fe0ef          	jal	80003b4a <namei>
    800052cc:	84aa                	mv	s1,a0
    800052ce:	c915                	beqz	a0,80005302 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800052d0:	84cfe0ef          	jal	8000331c <ilock>
  if(ip->type != T_DIR){
    800052d4:	04449703          	lh	a4,68(s1)
    800052d8:	4785                	li	a5,1
    800052da:	02f71963          	bne	a4,a5,8000530c <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800052de:	8526                	mv	a0,s1
    800052e0:	8eafe0ef          	jal	800033ca <iunlock>
  iput(p->cwd);
    800052e4:	15093503          	ld	a0,336(s2)
    800052e8:	9b6fe0ef          	jal	8000349e <iput>
  end_op();
    800052ec:	aadfe0ef          	jal	80003d98 <end_op>
  p->cwd = ip;
    800052f0:	14993823          	sd	s1,336(s2)
  return 0;
    800052f4:	4501                	li	a0,0
    800052f6:	64aa                	ld	s1,136(sp)
}
    800052f8:	60ea                	ld	ra,152(sp)
    800052fa:	644a                	ld	s0,144(sp)
    800052fc:	690a                	ld	s2,128(sp)
    800052fe:	610d                	addi	sp,sp,160
    80005300:	8082                	ret
    80005302:	64aa                	ld	s1,136(sp)
    end_op();
    80005304:	a95fe0ef          	jal	80003d98 <end_op>
    return -1;
    80005308:	557d                	li	a0,-1
    8000530a:	b7fd                	j	800052f8 <sys_chdir+0x5c>
    iunlockput(ip);
    8000530c:	8526                	mv	a0,s1
    8000530e:	a1afe0ef          	jal	80003528 <iunlockput>
    end_op();
    80005312:	a87fe0ef          	jal	80003d98 <end_op>
    return -1;
    80005316:	557d                	li	a0,-1
    80005318:	64aa                	ld	s1,136(sp)
    8000531a:	bff9                	j	800052f8 <sys_chdir+0x5c>

000000008000531c <sys_exec>:

uint64
sys_exec(void)
{
    8000531c:	7105                	addi	sp,sp,-480
    8000531e:	ef86                	sd	ra,472(sp)
    80005320:	eba2                	sd	s0,464(sp)
    80005322:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005324:	e2840593          	addi	a1,s0,-472
    80005328:	4505                	li	a0,1
    8000532a:	e44fd0ef          	jal	8000296e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000532e:	08000613          	li	a2,128
    80005332:	f3040593          	addi	a1,s0,-208
    80005336:	4501                	li	a0,0
    80005338:	e52fd0ef          	jal	8000298a <argstr>
    8000533c:	87aa                	mv	a5,a0
    return -1;
    8000533e:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005340:	0e07c063          	bltz	a5,80005420 <sys_exec+0x104>
    80005344:	e7a6                	sd	s1,456(sp)
    80005346:	e3ca                	sd	s2,448(sp)
    80005348:	ff4e                	sd	s3,440(sp)
    8000534a:	fb52                	sd	s4,432(sp)
    8000534c:	f756                	sd	s5,424(sp)
    8000534e:	f35a                	sd	s6,416(sp)
    80005350:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005352:	e3040a13          	addi	s4,s0,-464
    80005356:	10000613          	li	a2,256
    8000535a:	4581                	li	a1,0
    8000535c:	8552                	mv	a0,s4
    8000535e:	99bfb0ef          	jal	80000cf8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005362:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80005364:	89d2                	mv	s3,s4
    80005366:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005368:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000536c:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    8000536e:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005372:	00391513          	slli	a0,s2,0x3
    80005376:	85d6                	mv	a1,s5
    80005378:	e2843783          	ld	a5,-472(s0)
    8000537c:	953e                	add	a0,a0,a5
    8000537e:	d4afd0ef          	jal	800028c8 <fetchaddr>
    80005382:	02054663          	bltz	a0,800053ae <sys_exec+0x92>
    if(uarg == 0){
    80005386:	e2043783          	ld	a5,-480(s0)
    8000538a:	c7a1                	beqz	a5,800053d2 <sys_exec+0xb6>
    argv[i] = kalloc();
    8000538c:	fb8fb0ef          	jal	80000b44 <kalloc>
    80005390:	85aa                	mv	a1,a0
    80005392:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005396:	cd01                	beqz	a0,800053ae <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005398:	865a                	mv	a2,s6
    8000539a:	e2043503          	ld	a0,-480(s0)
    8000539e:	d74fd0ef          	jal	80002912 <fetchstr>
    800053a2:	00054663          	bltz	a0,800053ae <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800053a6:	0905                	addi	s2,s2,1
    800053a8:	09a1                	addi	s3,s3,8
    800053aa:	fd7914e3          	bne	s2,s7,80005372 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053ae:	100a0a13          	addi	s4,s4,256
    800053b2:	6088                	ld	a0,0(s1)
    800053b4:	cd31                	beqz	a0,80005410 <sys_exec+0xf4>
    kfree(argv[i]);
    800053b6:	ea6fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053ba:	04a1                	addi	s1,s1,8
    800053bc:	ff449be3          	bne	s1,s4,800053b2 <sys_exec+0x96>
  return -1;
    800053c0:	557d                	li	a0,-1
    800053c2:	64be                	ld	s1,456(sp)
    800053c4:	691e                	ld	s2,448(sp)
    800053c6:	79fa                	ld	s3,440(sp)
    800053c8:	7a5a                	ld	s4,432(sp)
    800053ca:	7aba                	ld	s5,424(sp)
    800053cc:	7b1a                	ld	s6,416(sp)
    800053ce:	6bfa                	ld	s7,408(sp)
    800053d0:	a881                	j	80005420 <sys_exec+0x104>
      argv[i] = 0;
    800053d2:	0009079b          	sext.w	a5,s2
    800053d6:	e3040593          	addi	a1,s0,-464
    800053da:	078e                	slli	a5,a5,0x3
    800053dc:	97ae                	add	a5,a5,a1
    800053de:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    800053e2:	f3040513          	addi	a0,s0,-208
    800053e6:	bb2ff0ef          	jal	80004798 <kexec>
    800053ea:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053ec:	100a0a13          	addi	s4,s4,256
    800053f0:	6088                	ld	a0,0(s1)
    800053f2:	c511                	beqz	a0,800053fe <sys_exec+0xe2>
    kfree(argv[i]);
    800053f4:	e68fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053f8:	04a1                	addi	s1,s1,8
    800053fa:	ff449be3          	bne	s1,s4,800053f0 <sys_exec+0xd4>
  return ret;
    800053fe:	854a                	mv	a0,s2
    80005400:	64be                	ld	s1,456(sp)
    80005402:	691e                	ld	s2,448(sp)
    80005404:	79fa                	ld	s3,440(sp)
    80005406:	7a5a                	ld	s4,432(sp)
    80005408:	7aba                	ld	s5,424(sp)
    8000540a:	7b1a                	ld	s6,416(sp)
    8000540c:	6bfa                	ld	s7,408(sp)
    8000540e:	a809                	j	80005420 <sys_exec+0x104>
  return -1;
    80005410:	557d                	li	a0,-1
    80005412:	64be                	ld	s1,456(sp)
    80005414:	691e                	ld	s2,448(sp)
    80005416:	79fa                	ld	s3,440(sp)
    80005418:	7a5a                	ld	s4,432(sp)
    8000541a:	7aba                	ld	s5,424(sp)
    8000541c:	7b1a                	ld	s6,416(sp)
    8000541e:	6bfa                	ld	s7,408(sp)
}
    80005420:	60fe                	ld	ra,472(sp)
    80005422:	645e                	ld	s0,464(sp)
    80005424:	613d                	addi	sp,sp,480
    80005426:	8082                	ret

0000000080005428 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005428:	7139                	addi	sp,sp,-64
    8000542a:	fc06                	sd	ra,56(sp)
    8000542c:	f822                	sd	s0,48(sp)
    8000542e:	f426                	sd	s1,40(sp)
    80005430:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005432:	dd6fc0ef          	jal	80001a08 <myproc>
    80005436:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005438:	fd840593          	addi	a1,s0,-40
    8000543c:	4501                	li	a0,0
    8000543e:	d30fd0ef          	jal	8000296e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005442:	fc840593          	addi	a1,s0,-56
    80005446:	fd040513          	addi	a0,s0,-48
    8000544a:	81eff0ef          	jal	80004468 <pipealloc>
    return -1;
    8000544e:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005450:	0a054763          	bltz	a0,800054fe <sys_pipe+0xd6>
  fd0 = -1;
    80005454:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005458:	fd043503          	ld	a0,-48(s0)
    8000545c:	ef2ff0ef          	jal	80004b4e <fdalloc>
    80005460:	fca42223          	sw	a0,-60(s0)
    80005464:	08054463          	bltz	a0,800054ec <sys_pipe+0xc4>
    80005468:	fc843503          	ld	a0,-56(s0)
    8000546c:	ee2ff0ef          	jal	80004b4e <fdalloc>
    80005470:	fca42023          	sw	a0,-64(s0)
    80005474:	06054263          	bltz	a0,800054d8 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005478:	4691                	li	a3,4
    8000547a:	fc440613          	addi	a2,s0,-60
    8000547e:	fd843583          	ld	a1,-40(s0)
    80005482:	68a8                	ld	a0,80(s1)
    80005484:	9d0fc0ef          	jal	80001654 <copyout>
    80005488:	00054e63          	bltz	a0,800054a4 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    8000548c:	4691                	li	a3,4
    8000548e:	fc040613          	addi	a2,s0,-64
    80005492:	fd843583          	ld	a1,-40(s0)
    80005496:	95b6                	add	a1,a1,a3
    80005498:	68a8                	ld	a0,80(s1)
    8000549a:	9bafc0ef          	jal	80001654 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000549e:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800054a0:	04055f63          	bgez	a0,800054fe <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800054a4:	fc442783          	lw	a5,-60(s0)
    800054a8:	078e                	slli	a5,a5,0x3
    800054aa:	0d078793          	addi	a5,a5,208
    800054ae:	97a6                	add	a5,a5,s1
    800054b0:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800054b4:	fc042783          	lw	a5,-64(s0)
    800054b8:	078e                	slli	a5,a5,0x3
    800054ba:	0d078793          	addi	a5,a5,208
    800054be:	97a6                	add	a5,a5,s1
    800054c0:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800054c4:	fd043503          	ld	a0,-48(s0)
    800054c8:	c85fe0ef          	jal	8000414c <fileclose>
    fileclose(wf);
    800054cc:	fc843503          	ld	a0,-56(s0)
    800054d0:	c7dfe0ef          	jal	8000414c <fileclose>
    return -1;
    800054d4:	57fd                	li	a5,-1
    800054d6:	a025                	j	800054fe <sys_pipe+0xd6>
    if(fd0 >= 0)
    800054d8:	fc442783          	lw	a5,-60(s0)
    800054dc:	0007c863          	bltz	a5,800054ec <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    800054e0:	078e                	slli	a5,a5,0x3
    800054e2:	0d078793          	addi	a5,a5,208
    800054e6:	97a6                	add	a5,a5,s1
    800054e8:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800054ec:	fd043503          	ld	a0,-48(s0)
    800054f0:	c5dfe0ef          	jal	8000414c <fileclose>
    fileclose(wf);
    800054f4:	fc843503          	ld	a0,-56(s0)
    800054f8:	c55fe0ef          	jal	8000414c <fileclose>
    return -1;
    800054fc:	57fd                	li	a5,-1
}
    800054fe:	853e                	mv	a0,a5
    80005500:	70e2                	ld	ra,56(sp)
    80005502:	7442                	ld	s0,48(sp)
    80005504:	74a2                	ld	s1,40(sp)
    80005506:	6121                	addi	sp,sp,64
    80005508:	8082                	ret
    8000550a:	0000                	unimp
    8000550c:	0000                	unimp
	...

0000000080005510 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005510:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005512:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005514:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005516:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005518:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000551a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000551c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000551e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005520:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005522:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005524:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005526:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005528:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000552a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000552c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000552e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005530:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005532:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005534:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005536:	aa0fd0ef          	jal	800027d6 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000553a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000553c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000553e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005540:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005542:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005544:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005546:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005548:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000554a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000554c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000554e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005550:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005552:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005554:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005556:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005558:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000555a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000555c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000555e:	10200073          	sret
    80005562:	00000013          	nop
    80005566:	00000013          	nop
    8000556a:	00000013          	nop

000000008000556e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000556e:	1141                	addi	sp,sp,-16
    80005570:	e406                	sd	ra,8(sp)
    80005572:	e022                	sd	s0,0(sp)
    80005574:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005576:	0c000737          	lui	a4,0xc000
    8000557a:	4785                	li	a5,1
    8000557c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000557e:	c35c                	sw	a5,4(a4)
}
    80005580:	60a2                	ld	ra,8(sp)
    80005582:	6402                	ld	s0,0(sp)
    80005584:	0141                	addi	sp,sp,16
    80005586:	8082                	ret

0000000080005588 <plicinithart>:

void
plicinithart(void)
{
    80005588:	1141                	addi	sp,sp,-16
    8000558a:	e406                	sd	ra,8(sp)
    8000558c:	e022                	sd	s0,0(sp)
    8000558e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005590:	c44fc0ef          	jal	800019d4 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005594:	0085171b          	slliw	a4,a0,0x8
    80005598:	0c0027b7          	lui	a5,0xc002
    8000559c:	97ba                	add	a5,a5,a4
    8000559e:	40200713          	li	a4,1026
    800055a2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800055a6:	00d5151b          	slliw	a0,a0,0xd
    800055aa:	0c2017b7          	lui	a5,0xc201
    800055ae:	97aa                	add	a5,a5,a0
    800055b0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800055b4:	60a2                	ld	ra,8(sp)
    800055b6:	6402                	ld	s0,0(sp)
    800055b8:	0141                	addi	sp,sp,16
    800055ba:	8082                	ret

00000000800055bc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800055bc:	1141                	addi	sp,sp,-16
    800055be:	e406                	sd	ra,8(sp)
    800055c0:	e022                	sd	s0,0(sp)
    800055c2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800055c4:	c10fc0ef          	jal	800019d4 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800055c8:	00d5151b          	slliw	a0,a0,0xd
    800055cc:	0c2017b7          	lui	a5,0xc201
    800055d0:	97aa                	add	a5,a5,a0
  return irq;
}
    800055d2:	43c8                	lw	a0,4(a5)
    800055d4:	60a2                	ld	ra,8(sp)
    800055d6:	6402                	ld	s0,0(sp)
    800055d8:	0141                	addi	sp,sp,16
    800055da:	8082                	ret

00000000800055dc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800055dc:	1101                	addi	sp,sp,-32
    800055de:	ec06                	sd	ra,24(sp)
    800055e0:	e822                	sd	s0,16(sp)
    800055e2:	e426                	sd	s1,8(sp)
    800055e4:	1000                	addi	s0,sp,32
    800055e6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800055e8:	becfc0ef          	jal	800019d4 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800055ec:	00d5179b          	slliw	a5,a0,0xd
    800055f0:	0c201737          	lui	a4,0xc201
    800055f4:	97ba                	add	a5,a5,a4
    800055f6:	c3c4                	sw	s1,4(a5)
}
    800055f8:	60e2                	ld	ra,24(sp)
    800055fa:	6442                	ld	s0,16(sp)
    800055fc:	64a2                	ld	s1,8(sp)
    800055fe:	6105                	addi	sp,sp,32
    80005600:	8082                	ret

0000000080005602 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005602:	1141                	addi	sp,sp,-16
    80005604:	e406                	sd	ra,8(sp)
    80005606:	e022                	sd	s0,0(sp)
    80005608:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000560a:	479d                	li	a5,7
    8000560c:	04a7ca63          	blt	a5,a0,80005660 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005610:	0001e797          	auipc	a5,0x1e
    80005614:	ee878793          	addi	a5,a5,-280 # 800234f8 <disk>
    80005618:	97aa                	add	a5,a5,a0
    8000561a:	0187c783          	lbu	a5,24(a5)
    8000561e:	e7b9                	bnez	a5,8000566c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005620:	00451693          	slli	a3,a0,0x4
    80005624:	0001e797          	auipc	a5,0x1e
    80005628:	ed478793          	addi	a5,a5,-300 # 800234f8 <disk>
    8000562c:	6398                	ld	a4,0(a5)
    8000562e:	9736                	add	a4,a4,a3
    80005630:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005634:	6398                	ld	a4,0(a5)
    80005636:	9736                	add	a4,a4,a3
    80005638:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000563c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005640:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005644:	97aa                	add	a5,a5,a0
    80005646:	4705                	li	a4,1
    80005648:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000564c:	0001e517          	auipc	a0,0x1e
    80005650:	ec450513          	addi	a0,a0,-316 # 80023510 <disk+0x18>
    80005654:	a3ffc0ef          	jal	80002092 <wakeup>
}
    80005658:	60a2                	ld	ra,8(sp)
    8000565a:	6402                	ld	s0,0(sp)
    8000565c:	0141                	addi	sp,sp,16
    8000565e:	8082                	ret
    panic("free_desc 1");
    80005660:	00002517          	auipc	a0,0x2
    80005664:	01050513          	addi	a0,a0,16 # 80007670 <etext+0x670>
    80005668:	9bcfb0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    8000566c:	00002517          	auipc	a0,0x2
    80005670:	01450513          	addi	a0,a0,20 # 80007680 <etext+0x680>
    80005674:	9b0fb0ef          	jal	80000824 <panic>

0000000080005678 <virtio_disk_init>:
{
    80005678:	1101                	addi	sp,sp,-32
    8000567a:	ec06                	sd	ra,24(sp)
    8000567c:	e822                	sd	s0,16(sp)
    8000567e:	e426                	sd	s1,8(sp)
    80005680:	e04a                	sd	s2,0(sp)
    80005682:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005684:	00002597          	auipc	a1,0x2
    80005688:	00c58593          	addi	a1,a1,12 # 80007690 <etext+0x690>
    8000568c:	0001e517          	auipc	a0,0x1e
    80005690:	f9450513          	addi	a0,a0,-108 # 80023620 <disk+0x128>
    80005694:	d0afb0ef          	jal	80000b9e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005698:	100017b7          	lui	a5,0x10001
    8000569c:	4398                	lw	a4,0(a5)
    8000569e:	2701                	sext.w	a4,a4
    800056a0:	747277b7          	lui	a5,0x74727
    800056a4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800056a8:	14f71863          	bne	a4,a5,800057f8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800056ac:	100017b7          	lui	a5,0x10001
    800056b0:	43dc                	lw	a5,4(a5)
    800056b2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800056b4:	4709                	li	a4,2
    800056b6:	14e79163          	bne	a5,a4,800057f8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800056ba:	100017b7          	lui	a5,0x10001
    800056be:	479c                	lw	a5,8(a5)
    800056c0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800056c2:	12e79b63          	bne	a5,a4,800057f8 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800056c6:	100017b7          	lui	a5,0x10001
    800056ca:	47d8                	lw	a4,12(a5)
    800056cc:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800056ce:	554d47b7          	lui	a5,0x554d4
    800056d2:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800056d6:	12f71163          	bne	a4,a5,800057f8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    800056da:	100017b7          	lui	a5,0x10001
    800056de:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800056e2:	4705                	li	a4,1
    800056e4:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800056e6:	470d                	li	a4,3
    800056e8:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800056ea:	10001737          	lui	a4,0x10001
    800056ee:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800056f0:	c7ffe6b7          	lui	a3,0xc7ffe
    800056f4:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdb127>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800056f8:	8f75                	and	a4,a4,a3
    800056fa:	100016b7          	lui	a3,0x10001
    800056fe:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005700:	472d                	li	a4,11
    80005702:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005704:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005708:	439c                	lw	a5,0(a5)
    8000570a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000570e:	8ba1                	andi	a5,a5,8
    80005710:	0e078a63          	beqz	a5,80005804 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005714:	100017b7          	lui	a5,0x10001
    80005718:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000571c:	43fc                	lw	a5,68(a5)
    8000571e:	2781                	sext.w	a5,a5
    80005720:	0e079863          	bnez	a5,80005810 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005724:	100017b7          	lui	a5,0x10001
    80005728:	5bdc                	lw	a5,52(a5)
    8000572a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000572c:	0e078863          	beqz	a5,8000581c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005730:	471d                	li	a4,7
    80005732:	0ef77b63          	bgeu	a4,a5,80005828 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005736:	c0efb0ef          	jal	80000b44 <kalloc>
    8000573a:	0001e497          	auipc	s1,0x1e
    8000573e:	dbe48493          	addi	s1,s1,-578 # 800234f8 <disk>
    80005742:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005744:	c00fb0ef          	jal	80000b44 <kalloc>
    80005748:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000574a:	bfafb0ef          	jal	80000b44 <kalloc>
    8000574e:	87aa                	mv	a5,a0
    80005750:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005752:	6088                	ld	a0,0(s1)
    80005754:	0e050063          	beqz	a0,80005834 <virtio_disk_init+0x1bc>
    80005758:	0001e717          	auipc	a4,0x1e
    8000575c:	da873703          	ld	a4,-600(a4) # 80023500 <disk+0x8>
    80005760:	cb71                	beqz	a4,80005834 <virtio_disk_init+0x1bc>
    80005762:	cbe9                	beqz	a5,80005834 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80005764:	6605                	lui	a2,0x1
    80005766:	4581                	li	a1,0
    80005768:	d90fb0ef          	jal	80000cf8 <memset>
  memset(disk.avail, 0, PGSIZE);
    8000576c:	0001e497          	auipc	s1,0x1e
    80005770:	d8c48493          	addi	s1,s1,-628 # 800234f8 <disk>
    80005774:	6605                	lui	a2,0x1
    80005776:	4581                	li	a1,0
    80005778:	6488                	ld	a0,8(s1)
    8000577a:	d7efb0ef          	jal	80000cf8 <memset>
  memset(disk.used, 0, PGSIZE);
    8000577e:	6605                	lui	a2,0x1
    80005780:	4581                	li	a1,0
    80005782:	6888                	ld	a0,16(s1)
    80005784:	d74fb0ef          	jal	80000cf8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005788:	100017b7          	lui	a5,0x10001
    8000578c:	4721                	li	a4,8
    8000578e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005790:	4098                	lw	a4,0(s1)
    80005792:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005796:	40d8                	lw	a4,4(s1)
    80005798:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000579c:	649c                	ld	a5,8(s1)
    8000579e:	0007869b          	sext.w	a3,a5
    800057a2:	10001737          	lui	a4,0x10001
    800057a6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800057aa:	9781                	srai	a5,a5,0x20
    800057ac:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800057b0:	689c                	ld	a5,16(s1)
    800057b2:	0007869b          	sext.w	a3,a5
    800057b6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800057ba:	9781                	srai	a5,a5,0x20
    800057bc:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800057c0:	4785                	li	a5,1
    800057c2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800057c4:	00f48c23          	sb	a5,24(s1)
    800057c8:	00f48ca3          	sb	a5,25(s1)
    800057cc:	00f48d23          	sb	a5,26(s1)
    800057d0:	00f48da3          	sb	a5,27(s1)
    800057d4:	00f48e23          	sb	a5,28(s1)
    800057d8:	00f48ea3          	sb	a5,29(s1)
    800057dc:	00f48f23          	sb	a5,30(s1)
    800057e0:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800057e4:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800057e8:	07272823          	sw	s2,112(a4)
}
    800057ec:	60e2                	ld	ra,24(sp)
    800057ee:	6442                	ld	s0,16(sp)
    800057f0:	64a2                	ld	s1,8(sp)
    800057f2:	6902                	ld	s2,0(sp)
    800057f4:	6105                	addi	sp,sp,32
    800057f6:	8082                	ret
    panic("could not find virtio disk");
    800057f8:	00002517          	auipc	a0,0x2
    800057fc:	ea850513          	addi	a0,a0,-344 # 800076a0 <etext+0x6a0>
    80005800:	824fb0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005804:	00002517          	auipc	a0,0x2
    80005808:	ebc50513          	addi	a0,a0,-324 # 800076c0 <etext+0x6c0>
    8000580c:	818fb0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    80005810:	00002517          	auipc	a0,0x2
    80005814:	ed050513          	addi	a0,a0,-304 # 800076e0 <etext+0x6e0>
    80005818:	80cfb0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    8000581c:	00002517          	auipc	a0,0x2
    80005820:	ee450513          	addi	a0,a0,-284 # 80007700 <etext+0x700>
    80005824:	800fb0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    80005828:	00002517          	auipc	a0,0x2
    8000582c:	ef850513          	addi	a0,a0,-264 # 80007720 <etext+0x720>
    80005830:	ff5fa0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    80005834:	00002517          	auipc	a0,0x2
    80005838:	f0c50513          	addi	a0,a0,-244 # 80007740 <etext+0x740>
    8000583c:	fe9fa0ef          	jal	80000824 <panic>

0000000080005840 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005840:	711d                	addi	sp,sp,-96
    80005842:	ec86                	sd	ra,88(sp)
    80005844:	e8a2                	sd	s0,80(sp)
    80005846:	e4a6                	sd	s1,72(sp)
    80005848:	e0ca                	sd	s2,64(sp)
    8000584a:	fc4e                	sd	s3,56(sp)
    8000584c:	f852                	sd	s4,48(sp)
    8000584e:	f456                	sd	s5,40(sp)
    80005850:	f05a                	sd	s6,32(sp)
    80005852:	ec5e                	sd	s7,24(sp)
    80005854:	e862                	sd	s8,16(sp)
    80005856:	1080                	addi	s0,sp,96
    80005858:	89aa                	mv	s3,a0
    8000585a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000585c:	00c52b83          	lw	s7,12(a0)
    80005860:	001b9b9b          	slliw	s7,s7,0x1
    80005864:	1b82                	slli	s7,s7,0x20
    80005866:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000586a:	0001e517          	auipc	a0,0x1e
    8000586e:	db650513          	addi	a0,a0,-586 # 80023620 <disk+0x128>
    80005872:	bb6fb0ef          	jal	80000c28 <acquire>
  for(int i = 0; i < NUM; i++){
    80005876:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005878:	0001ea97          	auipc	s5,0x1e
    8000587c:	c80a8a93          	addi	s5,s5,-896 # 800234f8 <disk>
  for(int i = 0; i < 3; i++){
    80005880:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005882:	5c7d                	li	s8,-1
    80005884:	a095                	j	800058e8 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80005886:	00fa8733          	add	a4,s5,a5
    8000588a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    8000588e:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005890:	0207c563          	bltz	a5,800058ba <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80005894:	2905                	addiw	s2,s2,1
    80005896:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005898:	05490c63          	beq	s2,s4,800058f0 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    8000589c:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    8000589e:	0001e717          	auipc	a4,0x1e
    800058a2:	c5a70713          	addi	a4,a4,-934 # 800234f8 <disk>
    800058a6:	4781                	li	a5,0
    if(disk.free[i]){
    800058a8:	01874683          	lbu	a3,24(a4)
    800058ac:	fee9                	bnez	a3,80005886 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    800058ae:	2785                	addiw	a5,a5,1
    800058b0:	0705                	addi	a4,a4,1
    800058b2:	fe979be3          	bne	a5,s1,800058a8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800058b6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    800058ba:	01205d63          	blez	s2,800058d4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800058be:	fa042503          	lw	a0,-96(s0)
    800058c2:	d41ff0ef          	jal	80005602 <free_desc>
      for(int j = 0; j < i; j++)
    800058c6:	4785                	li	a5,1
    800058c8:	0127d663          	bge	a5,s2,800058d4 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800058cc:	fa442503          	lw	a0,-92(s0)
    800058d0:	d33ff0ef          	jal	80005602 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800058d4:	0001e597          	auipc	a1,0x1e
    800058d8:	d4c58593          	addi	a1,a1,-692 # 80023620 <disk+0x128>
    800058dc:	0001e517          	auipc	a0,0x1e
    800058e0:	c3450513          	addi	a0,a0,-972 # 80023510 <disk+0x18>
    800058e4:	f62fc0ef          	jal	80002046 <sleep>
  for(int i = 0; i < 3; i++){
    800058e8:	fa040613          	addi	a2,s0,-96
    800058ec:	4901                	li	s2,0
    800058ee:	b77d                	j	8000589c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800058f0:	fa042503          	lw	a0,-96(s0)
    800058f4:	00451693          	slli	a3,a0,0x4

  if(write)
    800058f8:	0001e797          	auipc	a5,0x1e
    800058fc:	c0078793          	addi	a5,a5,-1024 # 800234f8 <disk>
    80005900:	00451713          	slli	a4,a0,0x4
    80005904:	0a070713          	addi	a4,a4,160
    80005908:	973e                	add	a4,a4,a5
    8000590a:	01603633          	snez	a2,s6
    8000590e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005910:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005914:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005918:	6398                	ld	a4,0(a5)
    8000591a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000591c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005920:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005922:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005924:	6390                	ld	a2,0(a5)
    80005926:	00d60833          	add	a6,a2,a3
    8000592a:	4741                	li	a4,16
    8000592c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005930:	4585                	li	a1,1
    80005932:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005936:	fa442703          	lw	a4,-92(s0)
    8000593a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000593e:	0712                	slli	a4,a4,0x4
    80005940:	963a                	add	a2,a2,a4
    80005942:	05898813          	addi	a6,s3,88
    80005946:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    8000594a:	0007b883          	ld	a7,0(a5)
    8000594e:	9746                	add	a4,a4,a7
    80005950:	40000613          	li	a2,1024
    80005954:	c710                	sw	a2,8(a4)
  if(write)
    80005956:	001b3613          	seqz	a2,s6
    8000595a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000595e:	8e4d                	or	a2,a2,a1
    80005960:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005964:	fa842603          	lw	a2,-88(s0)
    80005968:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000596c:	00451813          	slli	a6,a0,0x4
    80005970:	02080813          	addi	a6,a6,32
    80005974:	983e                	add	a6,a6,a5
    80005976:	577d                	li	a4,-1
    80005978:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000597c:	0612                	slli	a2,a2,0x4
    8000597e:	98b2                	add	a7,a7,a2
    80005980:	03068713          	addi	a4,a3,48
    80005984:	973e                	add	a4,a4,a5
    80005986:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    8000598a:	6398                	ld	a4,0(a5)
    8000598c:	9732                	add	a4,a4,a2
    8000598e:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005990:	4689                	li	a3,2
    80005992:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005996:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000599a:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    8000599e:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800059a2:	6794                	ld	a3,8(a5)
    800059a4:	0026d703          	lhu	a4,2(a3)
    800059a8:	8b1d                	andi	a4,a4,7
    800059aa:	0706                	slli	a4,a4,0x1
    800059ac:	96ba                	add	a3,a3,a4
    800059ae:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800059b2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800059b6:	6798                	ld	a4,8(a5)
    800059b8:	00275783          	lhu	a5,2(a4)
    800059bc:	2785                	addiw	a5,a5,1
    800059be:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800059c2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800059c6:	100017b7          	lui	a5,0x10001
    800059ca:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800059ce:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    800059d2:	0001e917          	auipc	s2,0x1e
    800059d6:	c4e90913          	addi	s2,s2,-946 # 80023620 <disk+0x128>
  while(b->disk == 1) {
    800059da:	84ae                	mv	s1,a1
    800059dc:	00b79a63          	bne	a5,a1,800059f0 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    800059e0:	85ca                	mv	a1,s2
    800059e2:	854e                	mv	a0,s3
    800059e4:	e62fc0ef          	jal	80002046 <sleep>
  while(b->disk == 1) {
    800059e8:	0049a783          	lw	a5,4(s3)
    800059ec:	fe978ae3          	beq	a5,s1,800059e0 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    800059f0:	fa042903          	lw	s2,-96(s0)
    800059f4:	00491713          	slli	a4,s2,0x4
    800059f8:	02070713          	addi	a4,a4,32
    800059fc:	0001e797          	auipc	a5,0x1e
    80005a00:	afc78793          	addi	a5,a5,-1284 # 800234f8 <disk>
    80005a04:	97ba                	add	a5,a5,a4
    80005a06:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005a0a:	0001e997          	auipc	s3,0x1e
    80005a0e:	aee98993          	addi	s3,s3,-1298 # 800234f8 <disk>
    80005a12:	00491713          	slli	a4,s2,0x4
    80005a16:	0009b783          	ld	a5,0(s3)
    80005a1a:	97ba                	add	a5,a5,a4
    80005a1c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005a20:	854a                	mv	a0,s2
    80005a22:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005a26:	bddff0ef          	jal	80005602 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005a2a:	8885                	andi	s1,s1,1
    80005a2c:	f0fd                	bnez	s1,80005a12 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005a2e:	0001e517          	auipc	a0,0x1e
    80005a32:	bf250513          	addi	a0,a0,-1038 # 80023620 <disk+0x128>
    80005a36:	a86fb0ef          	jal	80000cbc <release>
}
    80005a3a:	60e6                	ld	ra,88(sp)
    80005a3c:	6446                	ld	s0,80(sp)
    80005a3e:	64a6                	ld	s1,72(sp)
    80005a40:	6906                	ld	s2,64(sp)
    80005a42:	79e2                	ld	s3,56(sp)
    80005a44:	7a42                	ld	s4,48(sp)
    80005a46:	7aa2                	ld	s5,40(sp)
    80005a48:	7b02                	ld	s6,32(sp)
    80005a4a:	6be2                	ld	s7,24(sp)
    80005a4c:	6c42                	ld	s8,16(sp)
    80005a4e:	6125                	addi	sp,sp,96
    80005a50:	8082                	ret

0000000080005a52 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005a52:	1101                	addi	sp,sp,-32
    80005a54:	ec06                	sd	ra,24(sp)
    80005a56:	e822                	sd	s0,16(sp)
    80005a58:	e426                	sd	s1,8(sp)
    80005a5a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005a5c:	0001e497          	auipc	s1,0x1e
    80005a60:	a9c48493          	addi	s1,s1,-1380 # 800234f8 <disk>
    80005a64:	0001e517          	auipc	a0,0x1e
    80005a68:	bbc50513          	addi	a0,a0,-1092 # 80023620 <disk+0x128>
    80005a6c:	9bcfb0ef          	jal	80000c28 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005a70:	100017b7          	lui	a5,0x10001
    80005a74:	53bc                	lw	a5,96(a5)
    80005a76:	8b8d                	andi	a5,a5,3
    80005a78:	10001737          	lui	a4,0x10001
    80005a7c:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005a7e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005a82:	689c                	ld	a5,16(s1)
    80005a84:	0204d703          	lhu	a4,32(s1)
    80005a88:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005a8c:	04f70863          	beq	a4,a5,80005adc <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80005a90:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005a94:	6898                	ld	a4,16(s1)
    80005a96:	0204d783          	lhu	a5,32(s1)
    80005a9a:	8b9d                	andi	a5,a5,7
    80005a9c:	078e                	slli	a5,a5,0x3
    80005a9e:	97ba                	add	a5,a5,a4
    80005aa0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005aa2:	00479713          	slli	a4,a5,0x4
    80005aa6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005aaa:	9726                	add	a4,a4,s1
    80005aac:	01074703          	lbu	a4,16(a4)
    80005ab0:	e329                	bnez	a4,80005af2 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005ab2:	0792                	slli	a5,a5,0x4
    80005ab4:	02078793          	addi	a5,a5,32
    80005ab8:	97a6                	add	a5,a5,s1
    80005aba:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005abc:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005ac0:	dd2fc0ef          	jal	80002092 <wakeup>

    disk.used_idx += 1;
    80005ac4:	0204d783          	lhu	a5,32(s1)
    80005ac8:	2785                	addiw	a5,a5,1
    80005aca:	17c2                	slli	a5,a5,0x30
    80005acc:	93c1                	srli	a5,a5,0x30
    80005ace:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005ad2:	6898                	ld	a4,16(s1)
    80005ad4:	00275703          	lhu	a4,2(a4)
    80005ad8:	faf71ce3          	bne	a4,a5,80005a90 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005adc:	0001e517          	auipc	a0,0x1e
    80005ae0:	b4450513          	addi	a0,a0,-1212 # 80023620 <disk+0x128>
    80005ae4:	9d8fb0ef          	jal	80000cbc <release>
}
    80005ae8:	60e2                	ld	ra,24(sp)
    80005aea:	6442                	ld	s0,16(sp)
    80005aec:	64a2                	ld	s1,8(sp)
    80005aee:	6105                	addi	sp,sp,32
    80005af0:	8082                	ret
      panic("virtio_disk_intr status");
    80005af2:	00002517          	auipc	a0,0x2
    80005af6:	c6650513          	addi	a0,a0,-922 # 80007758 <etext+0x758>
    80005afa:	d2bfa0ef          	jal	80000824 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
