// xv6 user space headers that need to be included.
#include "kernel/types.h" 
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    startLogging(); //Turn on the kernel logging so that kernel prints Logging Started and any nice messages.

    int pid = fork(); //Duplicate the current process and return 0 in the child and child PID in parent.
    if (pid == 0) { 
        int mypid = getpid(); // Fetch the child PID
        // nice(10)
        nice(mypid, 10); // System call with the pid and inc = 10. So nice value incremented by 10.

        volatile int calc = 0; // Prevent loop optimization 
        for (int i = 0 ; i < 100000; i++) // This loop enforces that the process continues to run. There is around 1 trillion iterations and it simply increments calc with i. Keep the CPU busy
        {
            for (int j = 0 ; j < 10000; j++)
            {
                calc += i;
            }
        }
        exit(0); // Terminate the child with exit.
    }
    else {
        wait(0); // Blocks until any child finishes.
        stopLogging(); //Flip the kernel condition flag off and print the "Logging Stopped"
    }
    exit(0); // Terminate the parent process.
}