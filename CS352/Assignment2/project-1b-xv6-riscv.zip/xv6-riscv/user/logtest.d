user/logtest.o: user/logtest.c kernel/types.h kernel/stat.h user/user.h
